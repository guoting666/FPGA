// R22: neutral-preserving hue banks; original R21 AWB and tone curve retained.
// V36 bilinear Bayer reconstruction and saved color controls. The 32->16
// DDR reader emits captured quads high-word first: [G,B] / [R,G].
// V36 demosaic consumes the low byte first, matching the network FIFO
// ENDIANESS=1 phase (BGGR). Do not swap these bytes a second time.
module v36_color_pair(input clk,rst_n,input in_vs,in_hs,in_de,input [1:0] color_bank,output [1:0] color_bank_applied,
 input [15:0] raw_pair,output out_vs,out_hs,out_de,output [47:0] rgb_pair,output [127:0] awb_status);
function [7:0] black;
 input [7:0] v;begin black=v>16 ? v-16 : 0;end
endfunction
wire d_vs,d_hs,d_de,d_valid;wire [47:0] d_rgb;
debayer_top_2to1 demosaic(.in_pclk(clk),.in_rstn(rst_n),
 .raw_vs_i(in_vs),.raw_hs_i(in_hs),.raw_de_i(in_de),.raw_valid_i(in_de),
 .raw_datax4_i({black(raw_pair[15:8]),black(raw_pair[7:0])}),
 .r_gain(16'h0100),.g_gain(16'h0100),.b_gain(16'h0100),
 .rgb_vs_o(d_vs),.rgb_hs_o(d_hs),.rgb_de_o(d_de),.rgb_valid_o(d_valid),.rgb_datax2_o(d_rgb));
v36_isp_rgb_pair isp(.color_bank(color_bank),.color_bank_applied(color_bank_applied),.clk(clk),.rst_n(rst_n),.d_vs(d_vs),.d_hs(d_hs),.d_de(d_de),.d_rgb(d_rgb),.out_vs(out_vs),.out_hs(out_hs),.out_de(out_de),.rgb_pair(rgb_pair),.awb_status(awb_status));
endmodule
module v36_isp_rgb_pair(input clk,rst_n,input d_vs,d_hs,d_de,input [47:0] d_rgb,input [1:0] color_bank,output [1:0] color_bank_applied,output reg out_vs,out_hs,out_de,output reg [47:0] rgb_pair,output [127:0] awb_status);
// R22: VIO output r_gain[1:0] selects one of four fixed CCM banks.
// Synchronize the control, accept only a stable command at the input VS,
// and commit the CCM at its own VS after the gamma pipeline is blank.
// This keeps old-frame pixels and new-frame metadata on the same bank.
reg [1:0] bank_meta,bank_sync,bank_stable,bank_requested,bank_active;
reg [7:0] bank_output_tag;
reg d_vs_previous,g_vs_previous;
wire g_vs,g_hs,g_de,g_valid;wire [15:0] g_r,g_g,g_b;
wire [127:0] awb_native_status;
assign color_bank_applied=bank_output_tag[7:6];
// AWB1 extension version 2: reserved bits [14:13] report the applied bank.
// Actual automatic gains, counters and flags retain their original meaning.
assign awb_status={awb_native_status[127:16],1'b0,bank_output_tag[7:6],awb_native_status[12:8],8'd2};
always @(posedge clk)begin
 if(!rst_n)begin
  bank_meta<=0;bank_sync<=0;bank_stable<=0;bank_requested<=0;bank_active<=0;
  d_vs_previous<=0;g_vs_previous<=0;bank_output_tag<=0;
 end else begin
  bank_meta<=color_bank;bank_sync<=bank_meta;bank_stable<=bank_sync;
  // Match the two CCM, one saturation and one output register stages.
  bank_output_tag<={bank_output_tag[5:0],bank_active};
  d_vs_previous<=d_vs;g_vs_previous<=g_vs;
  if(d_vs&&!d_vs_previous&&bank_sync==bank_stable)bank_requested<=bank_sync;
  if(g_vs&&!g_vs_previous)bank_active<=bank_requested;
 end
end

wire [15:0] selected_r,selected_g,selected_b;
awb_gray_world_2px #(.GRAY_GATE(1)) awb(.clk(clk),.rstn(rst_n),.enable(1'b1),.hold(1'b0),.vs(d_vs),.de(d_de),
 .r({d_rgb[31:24],d_rgb[7:0]}),.g({d_rgb[39:32],d_rgb[15:8]}),.b({d_rgb[47:40],d_rgb[23:16]}),
 .manual_r(16'd22423),.manual_g(16'd16384),.manual_b(16'd33956),
 .gain_r(selected_r),.gain_g(selected_g),.gain_b(selected_b),.status(awb_native_status));
wire w_vs,w_hs,w_de,w_valid;wire [17:0] w_r,w_g,w_b;
wb_gain_3ch wb(.i_pclk(clk),.i_arstn(rst_n),.i_vs(d_vs),.i_hs(d_hs),.i_de(d_de),.i_valid(d_de),
 .i_r({d_rgb[31:24],d_rgb[7:0]}),.i_g({d_rgb[39:32],d_rgb[15:8]}),.i_b({d_rgb[47:40],d_rgb[23:16]}),
 .wb_r_gain(selected_r),.wb_g_gain(selected_g),.wb_b_gain(selected_b),
 .o_vs(w_vs),.o_hs(w_hs),.o_de(w_de),.o_valid(w_valid),.o_r(w_r),.o_g(w_g),.o_b(w_b));
gamma_lut_v1 gamma_lut(.cfg_gamma_enable(1'b1),.i_pclk(clk),.i_arstn(rst_n),
 .i_vs(w_vs),.i_hs(w_hs),.i_de(w_de),.i_valid(w_valid),.i_r(w_r),.i_g(w_g),.i_b(w_b),
 .o_vs(g_vs),.o_hs(g_hs),.o_de(g_de),.o_valid(g_valid),.o_r(g_r),.o_g(g_g),.o_b(g_b));
wire c_vs,c_hs,c_de,c_valid;wire [47:0] c_rgb;
wire signed [15:0] bank_RR = bank_active==2'd0 ? 16'sd13589 : bank_active==2'd1 ? 16'sd12208 : bank_active==2'd2 ? 16'sd10352 : 16'sd14435;
wire signed [15:0] bank_RG = bank_active==2'd0 ? 16'sd10359 : bank_active==2'd1 ? 16'sd9365 : bank_active==2'd2 ? 16'sd8881 : 16'sd11821;
wire signed [15:0] bank_RB = bank_active==2'd0 ? -16'sd4550 : bank_active==2'd1 ? -16'sd2182 : bank_active==2'd2 ? 16'sd157 : -16'sd6845;
wire signed [15:0] bank_GR = bank_active==2'd0 ? -16'sd3104 : bank_active==2'd1 ? -16'sd1557 : bank_active==2'd2 ? 16'sd115 : -16'sd4456;
wire signed [15:0] bank_GG = bank_active==2'd0 ? 16'sd28588 : bank_active==2'd1 ? 16'sd28288 : bank_active==2'd2 ? 16'sd27671 : 16'sd28560;
wire signed [15:0] bank_GB = bank_active==2'd0 ? -16'sd5859 : bank_active==2'd1 ? -16'sd7112 : bank_active==2'd2 ? -16'sd8178 : -16'sd4476;
wire signed [15:0] bank_BR = bank_active==2'd0 ? -16'sd8206 : bank_active==2'd1 ? -16'sd12538 : bank_active==2'd2 ? -16'sd16262 : -16'sd3458;
wire signed [15:0] bank_BG = bank_active==2'd0 ? 16'sd10531 : bank_active==2'd1 ? 16'sd14726 : bank_active==2'd2 ? 16'sd19199 : 16'sd6795;
wire signed [15:0] bank_BB = bank_active==2'd0 ? 16'sd17127 : bank_active==2'd1 ? 16'sd17316 : bank_active==2'd2 ? 16'sd16623 : 16'sd16064;
rgb_ccm ccm(.i_pclk(clk),.i_arstn(rst_n),.P_BYPASS(1'b0),
 .cfg_RR(bank_RR),.cfg_RG(bank_RG),.cfg_RB(bank_RB),
 .cfg_GR(bank_GR),.cfg_GG(bank_GG),.cfg_GB(bank_GB),
 .cfg_BR(bank_BR),.cfg_BG(bank_BG),.cfg_BB(bank_BB),
 .i_vs(g_vs),.i_hs(g_hs),.i_de(g_de),.i_valid(g_valid),
 .i_datax2({g_b[15:8],g_g[15:8],g_r[15:8],g_b[7:0],g_g[7:0],g_r[7:0]}),
 .o_vs(c_vs),.o_hs(c_hs),.o_de(c_de),.o_valid(c_valid),.o_datax2(c_rgb));
wire s_vs,s_hs,s_de,s_valid;wire [47:0] s_rgb;
rgb_saturate #(.P_RED_SHIFT(0)) saturation(.i_pclk(clk),.i_arstn(rst_n),.P_BYPASS(1'b0),
 .cfg_sat_hi(16'd40960),.cfg_sat_lo(16'd40960),.i_vs(c_vs),.i_hs(c_hs),.i_de(c_de),.i_valid(c_valid),.i_datax2(c_rgb),
 .o_vs(s_vs),.o_hs(s_hs),.o_de(s_de),.o_valid(s_valid),.o_datax2(s_rgb));
// Register the final saturate arithmetic before crossing to the 2x pixel clock.
always @(posedge clk)begin
 if(!rst_n)begin out_vs<=0;out_hs<=0;out_de<=0;rgb_pair<=0;end
 else begin out_vs<=s_vs;out_hs<=s_hs;out_de<=s_de;rgb_pair<=s_rgb;end
end
endmodule
