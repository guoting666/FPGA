"""Adapt all clay digits and toy-car negatives with MNIST/HWD/font replay.

Manually labelled crops come from the user's development video. Same-video
regression remains training-related; public test splits never enter training.
"""
import os
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL','2')
from pathlib import Path
import sys,json,time,hashlib,argparse
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from digit_common import normalize_digit
from train_digits import negative
from finetune_print import TRAIN_FONTS,glyph
from finetune_hard import augmented
from tube_digits import tubular

def main():
 p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);p.add_argument('--epochs',type=int,default=8);p.add_argument('--initial-checkpoint',type=Path);p.add_argument('--exclude-overlays',action='store_true');a=p.parse_args()
 import tensorflow as tf
 tf.config.threading.set_intra_op_parallelism_threads(4);tf.config.threading.set_inter_op_parallelism_threads(2);tf.keras.utils.set_random_seed(2534);cv2.setNumThreads(1);rng=np.random.default_rng(2534)
 out=ROOT/'model/digits';meta=json.loads((out/'metadata.json').read_text(encoding='utf8'))
 mn=np.load(a.data/'mnist.npz',allow_pickle=False);ms=np.load(out/'split_indices.npz',allow_pickle=False);ids=rng.choice(ms['train'],25000,replace=False)
 m=np.stack([normalize_digit(im) for im in mn['x_train'][ids]])
 hwd=np.load(a.data/'HWD/Images28.npy',allow_pickle=False);info=np.load(a.data/'HWD/WriterInfo.npy',allow_pickle=False);hs=np.load(out/'hwd_split_indices.npz',allow_pickle=False);h=np.stack([normalize_digit(np.clip(255-im,0,255).astype(np.uint8)) for im in hwd])
 tubes=np.stack([tubular(rng,i%10) for i in range(8000)]);fonts=np.stack([glyph(rng,str(i%10),TRAIN_FONTS[int(rng.integers(len(TRAIN_FONTS)))]) for i in range(8000)])
 neg=np.stack([negative(rng) if i%2 else glyph(rng,str(rng.choice(list('AHKMNRTXZ+*=/BCDEFGPQSU'))),TRAIN_FONTS[int(rng.integers(len(TRAIN_FONTS)))]) for i in range(8000)])
 src=ROOT/'tests/fixtures/clay_all';provenance=json.loads((src/'source.json').read_text(encoding='utf8'));samples=[s for s in provenance['samples'] if not (a.exclude_overlays and s['file'].startswith('overlay_'))];patches=[cv2.imread(str(src/s['file']),0) for s in samples]
 hard=np.stack([augmented(rng,patches[i%len(samples)]) for i in range(21000)]);hy=np.array([samples[i%len(samples)]['label'] for i in range(len(hard))])
 # Replay previous reported 1/9 templates as well as all newly labelled digits.
 older=[cv2.imread(str(ROOT/'tests/fixtures/clay'/n),0) for n in ['hard_one_foreground.png','hard_nine_foreground.png']]
 replay=np.stack([augmented(rng,older[i%2]) for i in range(2000)])
 vt=np.stack([tubular(rng,i%10) for i in range(1500)]);vf=np.stack([glyph(rng,str(i%10),TRAIN_FONTS[int(rng.integers(len(TRAIN_FONTS)))]) for i in range(1500)]);vn=np.stack([negative(rng) for _ in range(1000)])
 x=np.concatenate([m,h[hs['train']],tubes,fonts,neg,hard,replay]);y=np.concatenate([mn['y_train'][ids],info[hs['train'],0],np.arange(len(tubes))%10,np.arange(len(fonts))%10,np.full(len(neg),10),hy,np.tile([1,9],1000)])
 vx=np.concatenate([h[hs['validation']],vt,vf,vn]);vy=np.concatenate([info[hs['validation'],0],np.arange(len(vt))%10,np.arange(len(vf))%10,np.full(len(vn),10)])
 model=tf.keras.models.load_model(a.initial_checkpoint or out/'hard_best.keras');model.compile(optimizer=tf.keras.optimizers.Adam(.0001 if a.initial_checkpoint else .00015),loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),metrics=['accuracy'])
 started=time.time();history=[]
 class Progress(tf.keras.callbacks.Callback):
  def on_epoch_end(self,epoch,logs=None):
   row=dict(epoch=epoch+1,seconds=time.time()-started,**{k:float(v) for k,v in logs.items()});history.append(row);(ROOT/'reports/clay_all_training_history.json').write_text(json.dumps(history,indent=2));print(json.dumps(row),flush=True)
 model.fit(x[...,None].astype(np.float32)/255,y,validation_data=(vx[...,None].astype(np.float32)/255,vy),epochs=a.epochs,batch_size=256,verbose=0,callbacks=[Progress(),tf.keras.callbacks.ModelCheckpoint(str(out/'clay_all_best.keras'),monitor='val_loss',save_best_only=True),tf.keras.callbacks.ReduceLROnPlateau(monitor='val_loss',patience=2,factor=.5)])
 model=tf.keras.models.load_model(out/'clay_all_best.keras');conv=tf.lite.TFLiteConverter.from_keras_model(model);conv.optimizations=[tf.lite.Optimize.DEFAULT];blob=conv.convert();(out/'digit_cnn.tflite').write_bytes(blob)
 meta.update(sha256=hashlib.sha256(blob).hexdigest(),source=meta['source']+' + ten labelled clay digits and four toy-car rejects with replay',clay_all_finetune=dict(examples=len(x),epochs=a.epochs,source_foregrounds=len(samples),foreground_digit_labels=list(range(10)),reject_foregrounds=4,augmented_hard_examples=len(hard),previous_one_nine_replay=len(replay),validation=len(vx),seconds=time.time()-started,source_provenance='tests/fixtures/clay_all/source.json',user_video_crops_used_for_training=True,video_is_independent_test=False,checkpoint='minimum validation loss on original HWD validation writers and fresh generated samples; video is not checkpoint validation data'))
 (out/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf8');print('CLAY_ALL_TRAINING_COMPLETE',meta['sha256'],flush=True)
if __name__=='__main__':main()
