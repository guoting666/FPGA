// Backpressured 1920x1080 -> 640x360 nearest-neighbour RAW8 reduction.
// V36 DDR layout: chronological pair 0/1 is first, low byte is even pixel.
// Preserve samples x=0,3,6,9... with the actual low-byte-first output FIFO.
module raw8_decimate3 #(
    parameter SOURCE_WIDTH=1920, SOURCE_HEIGHT=1080
)(
    input clk, rst_n, enable,
    input [15:0] in_data, input in_valid, output in_ready,
    output [15:0] out_data, output out_valid, input out_ready,
    output reg done
);
reg [10:0] word_x, row_y;
reg [1:0] x_phase, y_phase;
reg [7:0] first_pixel;
wire emit_word = y_phase==0 && x_phase==1;
assign in_ready = enable && !done && (!emit_word || out_ready);
assign out_valid = enable && !done && in_valid && emit_word;
assign out_data = {in_data[15:8],first_pixel};
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        word_x<=0; row_y<=0; x_phase<=0; y_phase<=0;
        first_pixel<=0; done<=0;
    end else if(in_valid && in_ready) begin
        if(y_phase==0 && x_phase==0) first_pixel<=in_data[7:0];
        if(word_x==SOURCE_WIDTH/2-1) begin
            word_x<=0; x_phase<=0;
            if(row_y==SOURCE_HEIGHT-1) done<=1;
            else begin row_y<=row_y+1'b1; y_phase<=y_phase==2 ? 0 : y_phase+1'b1; end
        end else begin
            word_x<=word_x+1'b1; x_phase<=x_phase==2 ? 0 : x_phase+1'b1;
        end
    end
end
endmodule
