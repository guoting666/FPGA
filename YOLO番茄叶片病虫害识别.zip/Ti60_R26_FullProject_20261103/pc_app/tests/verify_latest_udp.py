"""Real localhost datagrams: a paused reader resumes at the newest full image."""
from pathlib import Path
import sys,socket,struct,json
import numpy as np
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R))
from udp_video import UDPReceiver,packetize,RGB888,HEADER,OSD_EXTENSION
from hdmi_feedback import decode_polygons
board=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);board.bind(('127.0.0.2',0));port=board.getsockname()[1];board.settimeout(1)
recv=UDPReceiver(dict(bind_ip='127.0.0.1',source_ip='127.0.0.2',port=port,delivery='stream'))
def send(fid,value,partial=False):
 im=np.full((40,80,3),value,np.uint8);packets=list(packetize(im,fid,RGB888))
 for p in packets[:1] if partial else packets:
  h=list(HEADER.unpack_from(p));h[1]=2;h[3]=40
  p=HEADER.pack(*h)+OSD_EXTENSION.pack(fid-1,1,9,b'T6O2')+p[28:]
  board.sendto(p,('127.0.0.1',port))
try:
 # All twelve frames are buffered while no receiver read runs.
 for fid in range(1,13):send(fid,fid)
 send(13,13,True)
 im=recv.read();assert recv.assembler.last_id==12 and np.all(im==12)
 assert recv.skipped_previews==11 and recv.assembler.stats['complete_frames']==12
 assert 13 in recv.assembler.pending,'Keep the newer incomplete frame for its remaining chunks'
 recv.send_results(12,80,40,[]);data,_=board.recvfrom(2048);assert decode_polygons(data)==(12,[])
 send(13,13);im=recv.read();assert recv.assembler.last_id==13 and np.all(im==13)
 assert recv.assembler.stats['invalid_packets']==0
 report=dict(passed=True,queued_complete_frames=12,newest_complete_selected=True,partial_next_preserved=True,feedback_uses_selected_wire_id=True,skipped_previews=recv.skipped_previews,scope='Real localhost UDP, independent of physical board')
 (R/'reports/latest_udp_verification.json').write_text(json.dumps(report,indent=2),encoding='utf8');print('LATEST_UDP_PASS',flush=True)
finally:recv.close();board.close()
