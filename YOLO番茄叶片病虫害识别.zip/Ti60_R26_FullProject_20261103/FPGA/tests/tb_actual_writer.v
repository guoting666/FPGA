`timescale 1ns/1ps
module tb_actual_writer;
reg axi=0,cam=0,rst=0,iv=1,ide=0;always #5 axi=~axi;always #9.259 cam=~cam;
localparam W=96,H=32,BEATS=W*H/8,BYTES=BEATS*16;
integer f,y,x,p,kk;
reg[31:0]vin=0;reg prev_vs=1;wire frame_start=iv&&!prev_vs;
always @(posedge cam)prev_vs<=iv;
wire capture,publish,ready,send,fault,display_ready,net_reserved;
reg busy=0,reader_done=0,send_seen=0;integer net_delay=0;
wire[31:0]wb,pb,nb,active,committed,netstarts;
wire[2:0]state,stage;wire[1:0]writes;reg[1:0]hdmi=0;
wire[31:0]awaddr;wire[7:0]awlen;wire awv,wv,wl,br;wire[127:0]wd;
reg awr=0,wr=0,bv=0;reg[15:0]pending_b=0;
wire done;reg[1:0]ds=0,is=0;
wire idle=pending_b==0&&!awv&&!wv;
always @(posedge cam)begin ds<={ds[0],done};is<={is[0],idle};end
ge_video_engine #(.BOOT_CYCLES(12000),.SETTLE_CYCLES(20),.NETWORK_INTERVAL_CYCLES(40000),.WATCHDOG_CYCLES(1000000)) engine(
 .capture_clk(cam),.axi_clk(axi),.rst_n(rst),.frame_start(frame_start),.write_done_toggle(ds[1]),.writer_idle(is[1]),
 .sender_busy(busy),.reader_done(reader_done),.hdmi_read_bank(hdmi),.hdmi_protected(4'b1<<hdmi),
 .capture_en(capture),.frame_publish(publish),.capture_ready(ready),.send_toggle(send),.fault(fault),.fault_stage(stage),
 .debug_state(state),.debug_writes(writes),.write_base(wb),.published_base(pb),.network_base(nb),
 .display_ready(display_ready),.network_reserved(net_reserved),.published_count(committed),.network_count(netstarts));
ge_write_commit #(.FRAME_BYTES(BYTES)) commit(.clk(axi),.rst_n(rst),.awaddr(awaddr),.awlen(awlen),
 .awvalid(awv),.awready(awr),.wvalid(wv),.wready(wr),.wlast(wl),.done_toggle(done));
frame_buffer #(.I_VID_WIDTH(32),.O_VID_WIDTH(16),.AXI_DATA_WIDTH(128),.AXI_ADDR_WIDTH(32),.WR_FIFO_DEPTH(64),.RD_FIFO_DEPTH(64),
 .START_ADDR(0),.BURST_LEN(7),.FB_NUM(1),.GATE_WRITES(1),.EXTERNAL_FRAME_BASE(1),.HDMI_CLEAN_STREAM(1),
 .MAX_VID_WIDTH(W),.MAX_VID_HIGHT(H),.O_FRAME_WIDTH(W),.O_FRAME_HEIGHT(H)) fb(
 .axi_clk(axi),.rst_n(rst),.i_clk(cam),.i_vs(iv),.i_de(ide),.vin(vin),.o_clk(cam),.capture_write_en(capture),
 .external_write_base(wb),.external_read_base(pb),.active_read_base(active),.fifo_rd_period(1'b0),.m_axis_tready(1'b0),
 .awaddr(awaddr),.awlen(awlen),.awvalid(awv),.awready(awr),.wdata(wd),.wvalid(wv),.wlast(wl),.wready(wr),
 .bid(6'b0),.bvalid(bv),.bready(br),.arready(1'b0),.rid(6'b0),.rdata(128'b0),.rlast(1'b0),.rvalid(1'b0),.rresp(2'b0));
function[7:0]pix(input integer f,p);pix=(f*31+p*7+(p/256)*13)&255;endfunction
reg[127:0]memory[0:1535];integer bank_words[0:3],bank_frame[0:3];
integer cycle=0,remaining=0,address=0,bank=0,offset=0,bi=0,j,qhead=0,qtail=0,awcount=0,wcount=0,fifo_words=0;
integer dues[0:1023];integer commits_seen=0,legacy_count=17,legacy_premature=0,physical_frames=0;
reg done_previous=0;
always @(negedge axi)begin awr=rst&&cycle%11!=0;wr=rst&&cycle%7!=0;bv=qtail!=qhead&&cycle>=dues[qhead%1024];end
always @(posedge axi)if(rst)begin
 cycle=cycle+1;
 if(f>=12&&f<=15&&fb.u_ddr_buffer.u_ddr_wr_buffer.pos_sync)$display("writer START t=%0t f=%0d base=%h cap=%b state=%0d",$time,f,wb,capture,state);
 if(awv&&awr)begin
  awcount=awcount+1;
  if(remaining!=0)$fatal(1,"write address overlapped previous data");
  remaining=awlen+1;address=awaddr;bank=address>>21;offset=(address&2097151)/16;
  if(bank!=wb[22:21])$fatal(1,"physical bank=%0d grant=%0d offset=%0d state=%0d cap=%b committed=%0d source_f=%0d vs=%b de=%b start_base=%h frame_start=%b fifo=%0d",bank,wb[22:21],offset,state,capture,committed,f,iv,ide,fb.u_ddr_buffer.u_ddr_wr_buffer.start_addr_r,fb.frame_start,fb.u_ddr_buffer.u_ddr_wr_buffer.wr_fifo_rdusedw);
  if(display_ready&&bank==hdmi)$fatal(1,"physical write collided with HDMI");
  if(net_reserved&&bank==nb[22:21])$fatal(1,"physical write collided with network");
  if(offset==0)begin bank_words[bank]=0;bank_frame[bank]=-1;end
  pending_b=pending_b+1;
 end
 if(wv&&wr)begin
  wcount=wcount+1;
  if(remaining==0)$fatal(1,"unsolicited write data");
  if(bank_frame[bank]<0)bank_frame[bank]=(wd[127:120]*223)&255;
  for(j=0;j<16;j=j+1)if(wd[127-j*8-:8]!==pix(bank_frame[bank],offset*16+j))
   $fatal(1,"actual FIFO writer origin/content mismatch bank=%0d offset=%0d byte=%0d got=%h expected=%h",bank,offset,j,wd[127-j*8-:8],pix(bank_frame[bank],offset*16+j));
  memory[bank*BEATS+offset]=wd;bank_words[bank]=bank_words[bank]+1;
  remaining=remaining-1;offset=offset+1;
  if(wl!=(remaining==0))$fatal(1,"WLAST mismatch");
  if(wl)begin dues[qtail%1024]=cycle+30+(qtail%17);qtail=qtail+1;end
  legacy_count=(legacy_count+1)%BEATS;
  if(legacy_count==0&&bank_words[bank]!=BEATS)legacy_premature=legacy_premature+1;
 end
 if(bv&&br)begin pending_b=pending_b-1;qhead=qhead+1;end
 if(done!=done_previous)begin
  done_previous=done;
  if(bank_words[bank]!=BEATS)$fatal(1,"completion before a full physical frame");
  physical_frames=physical_frames+1;
 end
end
always @(posedge axi)begin
 if(send!=send_seen)begin send_seen<=send;busy<=1;reader_done<=0;net_delay<=10000;end
 else if(net_delay!=0)net_delay<=net_delay-1;
 else begin busy<=0;reader_done<=1;end
 if(cycle%1700==0)hdmi<=pb[22:21];
end
always @(negedge cam)if(rst)begin
 if(fb.wr_fifo_wren&&capture)fifo_words=fifo_words+1;
 if(fault)$fatal(1,"camera watchdog state=%0d stage=%0d",state,stage);
 if(publish)begin
  bi=wb[22:21];
  if(bank_words[bi]!=BEATS||!idle)$fatal(1,"published incomplete or uncommitted frame %0d words %0d",bi,bank_words[bi]);
  if(bi==hdmi)$fatal(1,"published writer was modifying displayed frame");
  commits_seen=commits_seen+1;
 end
end
always @(posedge cam)if(rst&&f>=12&&f<=15&&(frame_start||fb.frame_start))
 $display("source VS t=%0t f=%0d ctrl_start=%b fb_start=%b polarity=%b wb=%h cap=%b state=%0d",$time,f,frame_start,fb.frame_start,fb.u_vid_rx_align.u_frame_info_det.negtive_sync,wb,capture,state);
initial begin
 for(kk=0;kk<4;kk=kk+1)begin bank_words[kk]=0;bank_frame[kk]=-1;end
 repeat(20)@(negedge cam);rst=1;
 for(f=1;f<=65;f=f+1)begin
  @(posedge cam);iv<=1;ide=0;repeat(32)@(negedge cam);@(posedge cam);iv<=0;repeat(16)@(negedge cam);
  for(y=0;y<H;y=y+1)begin
   for(x=0;x<W/2;x=x+1)begin
    p=y*W*2+x*4;vin={pix(f,p),pix(f,p+1),pix(f,p+2),pix(f,p+3)};ide=1;@(negedge cam);
   end
   ide=0;repeat(16)@(negedge cam);
  end
 end
 @(posedge cam);iv<=1;ide=0;repeat(500)@(negedge cam);
 if(commits_seen<20||legacy_premature<10||physical_frames<20)$fatal(1,"insufficient coverage commits=%0d physical=%0d old_counter_early=%0d aw=%0d w=%0d fifo=%0d state=%0d writes=%0d frame_len=%0d fifo_count=%0d wr_state=%0d",commits_seen,physical_frames,legacy_premature,awcount,wcount,fifo_words,state,writes,fb.ddr_frame_len,fb.u_ddr_buffer.u_ddr_wr_buffer.wr_fifo_rdusedw,fb.u_ddr_buffer.u_ddr_wr_buffer.state);
 $display("PASS actual camera aligner, packing, DC_FIFO and DDR writer: commits=%0d physical_frames=%0d; deliberately offset old counter would end %0d captures early",commits_seen,physical_frames,legacy_premature);$finish;
end
initial begin #5000000;$fatal(1,"timeout");end
initial begin #10000;
 if((^fb.u_ddr_buffer.u_ddr_wr_buffer.wr_fifo_rdusedw)===1'bx)
  $fatal(1,"FIFO unknown: reset=%b wr_rst=%b rd_rst=%b wp=%b rp=%b full=%b empty=%b clk=%b",fb.fifo_rst,
   fb.u_ddr_buffer.u_ddr_wr_buffer.u_wr_fifo.WrClkRst,fb.u_ddr_buffer.u_ddr_wr_buffer.u_wr_fifo.RdClkRst,
   fb.u_ddr_buffer.u_ddr_wr_buffer.u_wr_fifo.FifoWrAddr,fb.u_ddr_buffer.u_ddr_wr_buffer.u_wr_fifo.FifoRdAddr,
   fb.u_ddr_buffer.u_ddr_wr_buffer.u_wr_fifo.WrFull,fb.u_ddr_buffer.u_ddr_wr_buffer.u_wr_fifo.RdEmpty,
   fb.u_ddr_buffer.u_ddr_wr_buffer.wr_fifo_wrclk);
end
endmodule
