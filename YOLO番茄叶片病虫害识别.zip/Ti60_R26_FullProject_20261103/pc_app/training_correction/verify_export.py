from pathlib import Path
import sys,json,torch,cv2,numpy as np
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'app'))
from tomato import prepare_crop
from train_leaf_refiner import crop_input
from torchvision.models import mobilenet_v3_large
cv2.setNumThreads(1);torch.set_num_threads(1)
checkpoint=R/('leaf_refiner_selected.pt' if '--feedback' in sys.argv else 'leaf_refiner_best.pt')
onnx=R/'app/model/tomato/leaf_refiner.onnx' if '--feedback' in sys.argv else R/'leaf_refiner.onnx'
net=mobilenet_v3_large(weights=None);net.classifier[-1]=torch.nn.Linear(1280,9);net.load_state_dict(torch.load(checkpoint,map_location='cpu',weights_only=False)['state_dict']);net.eval()
cvnet=cv2.dnn.readNetFromONNX(str(onnx));rng=np.random.default_rng(10);items=[]
with torch.inference_mode():
 for n in [1,2,7,16,3]:
  image=rng.integers(0,256,(300,400,3),dtype=np.uint8);box=[20.5,10.7,350.8,270.3]
  x=prepare_crop(image,box);assert np.array_equal(x,crop_input(image,box))
  batch=np.stack([x for _ in range(n)]);ref=net(torch.from_numpy(batch)).numpy();cvnet.setInput(batch);out=cvnet.forward()
  assert out.shape==(n,9) and np.allclose(out,ref,rtol=.002,atol=.002),(n,out.shape,np.max(abs(out-ref)))
  items.append(dict(batch=n,max_logit_error=float(np.max(abs(out-ref)))))
(R/'app/reports/refiner_export_parity.json').write_text(json.dumps(dict(passed=True,checks=items,training_runtime_preprocess_equal=True),indent=2),encoding='utf8');print('REFINER_EXPORT_PARITY_PASS',items,flush=True)
