from pathlib import Path
import sys,json,tempfile,hashlib
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from tomato import TomatoDetector,select_candidates,pipeline_identity
from detector import Detector
cv2.setNumThreads(1)
def item(c,box,local=.8,bg=.01):
 q=[.001]*9;q[c]=1-bg-.007;q[8]=bg;p=[.001]*8;p[c]=.9
 return dict(xyxy=box,localization_confidence=local,class_probabilities=q,proposal_probabilities=p)
a=item(0,[10.,10.,100.,100.]);b=item(1,[11.,11.,101.,101.]);separate=item(5,[120.,20.,190.,100.])
assert len(select_candidates([a,b],.25,.03,0,.6,.5,.5))==1
assert len(select_candidates([a,separate],.25,.03,0,.6,.5,.5))==2
assert not select_candidates([item(0,[1,1,100,100],bg=.9)],.25,.03,0,.6,.5,.5)
assert not select_candidates([item(0,[1,1,100,100],local=.01)],.25,.03,0,.6,.5,.5)
assert not select_candidates([a],.25,.03,0,.6,.5,.5,False,[.999]*8)
json.dumps(select_candidates([a,separate],.25,.03,0,.6,.5,.5))
det=Detector();model=det.tomato;assert model.state()['ready'];meta=json.loads((ROOT/'model/tomato/metadata.json').read_text(encoding='utf8'));assert model.sha256==pipeline_identity(meta)
cases=[]
for c,minimum in [(1,2),(0,1),(3,1),(5,3)]:
 image=cv2.imread(str(ROOT/'samples'/f'tomato_example_{c}.jpg'));pred,timing=model.predict(image,meta['default_confidence'])
 assert len(pred)>=minimum and all(p['disease_id']==c for p in pred),(c,pred)
 assert all(p['confidence']>=max(meta['default_confidence'],meta['class_thresholds'][c]) for p in pred)
 json.dumps(pred);cv2.imwrite(str(ROOT/'reports'/f'correction_case_{c}.jpg'),det.annotate(image,pred))
 cases.append(dict(expected=c,detected=len(pred),wrong_class=0,confidence=[p['confidence'] for p in pred],predictions=pred,timing=timing))
assert not model.predict(np.full((240,320,3),114,np.uint8),meta['default_confidence'])[0]
with tempfile.TemporaryDirectory(prefix='leaf_metadata_') as tmp:
 folder=Path(tmp)
 for name in ['tomato_yolov8n.onnx','leaf_refiner.onnx','metadata.json']:
  (folder/name).write_bytes((ROOT/'model/tomato'/name).read_bytes())
 wrong=dict(meta,class_thresholds=[.1]*8);(folder/'metadata.json').write_text(json.dumps(wrong),encoding='utf8');assert not TomatoDetector(folder).state()['ready']
 wrong=dict(meta,refiner_sha256='0'*64);(folder/'metadata.json').write_text(json.dumps(wrong),encoding='utf8');assert not TomatoDetector(folder).state()['ready']
report=dict(passed=True,checks=['Single leaf cross-class duplicates suppressed; separate leaves preserved','Learned background, low localization and per-class thresholds reject candidates','Four user-confirmed source regressions have expected classes; no competing disease labels','Blank negative does not become a leaf','Pipeline settings and classifier hash mismatch cannot enable model'],cases=cases,pipeline_sha256=model.sha256,scope='Four source groups were used for correction training. These are regression results, not independent accuracy. Full other-source comparison reported separately.',physical_board_tested=False)
(ROOT/'reports/refined_leaf_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print('REFINED_LEAF_PASS',flush=True)
