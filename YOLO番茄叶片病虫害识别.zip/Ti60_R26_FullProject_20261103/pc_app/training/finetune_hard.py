"""Adapt to two manually labelled video crops with balanced replay.

The source video is a debugging regression, never an independent accuracy test.
HWD and MNIST test IDs remain excluded from fitting and checkpoint selection.
"""
import os
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL','2')
from pathlib import Path
import sys,json,time,hashlib,argparse
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from digit_common import normalize_digit
from train_digits import negative
from finetune_print import TRAIN_FONTS,glyph
from tube_digits import tubular

def augmented(rng,source):
 # Caption edges and segmentation can shorten a terminal by a few pixels.
 # Learn small, bounded crop variation instead of changing the class at runtime.
 if rng.random()<.5:
  bottom=int(rng.uniform(0,.10)*source.shape[0]);side=int(rng.uniform(0,.04)*source.shape[1])
  source=source[:max(1,source.shape[0]-bottom),side:max(side+1,source.shape[1]-side)]
 patch=cv2.resize(normalize_digit(source),(96,96),interpolation=cv2.INTER_CUBIC)
 mat=cv2.getRotationMatrix2D((48,48),float(rng.uniform(-12,12)),float(rng.uniform(.85,1.15)))
 mat[0,1]+=float(rng.uniform(-.09,.09));mat[0,2]+=float(rng.uniform(-4,4));mat[1,2]+=float(rng.uniform(-4,4))
 patch=cv2.warpAffine(patch,mat,(96,96))
 if rng.random()<.35:patch=cv2.erode(patch,np.ones((2,2),np.uint8)) if rng.random()<.5 else cv2.dilate(patch,np.ones((2,2),np.uint8))
 if rng.random()<.35:patch=cv2.GaussianBlur(patch,(3,3),float(rng.uniform(.4,1)))
 return normalize_digit(patch)

def main():
 p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);p.add_argument('--epochs',type=int,default=7);a=p.parse_args()
 import tensorflow as tf
 tf.config.threading.set_intra_op_parallelism_threads(4);tf.config.threading.set_inter_op_parallelism_threads(2);tf.keras.utils.set_random_seed(2524);cv2.setNumThreads(1);rng=np.random.default_rng(2524)
 out=ROOT/'model/digits';meta=json.loads((out/'metadata.json').read_text(encoding='utf8'))
 mn=np.load(a.data/'mnist.npz',allow_pickle=False);ms=np.load(out/'split_indices.npz',allow_pickle=False);ids=rng.choice(ms['train'],24000,replace=False)
 m=np.stack([normalize_digit(im) for im in mn['x_train'][ids]])
 hwd=np.load(a.data/'HWD/Images28.npy',allow_pickle=False);info=np.load(a.data/'HWD/WriterInfo.npy',allow_pickle=False);hs=np.load(out/'hwd_split_indices.npz',allow_pickle=False)
 h=np.stack([normalize_digit(np.clip(255-im,0,255).astype(np.uint8)) for im in hwd])
 tubes=np.stack([tubular(rng,i%10) for i in range(12000)]);fonts=np.stack([glyph(rng,str(i%10),TRAIN_FONTS[int(rng.integers(len(TRAIN_FONTS)))]) for i in range(10000)])
 neg=np.stack([negative(rng) if i%2 else glyph(rng,str(rng.choice(list('AHKMNRTXZ+*=/BCDEFGPQSU'))),TRAIN_FONTS[int(rng.integers(len(TRAIN_FONTS)))]) for i in range(10000)])
 source=ROOT/'tests/fixtures/clay';one=cv2.imread(str(source/'hard_one_foreground.png'),0);nine=cv2.imread(str(source/'hard_nine_foreground.png'),0)
 hard=np.stack([augmented(rng,one if i%2==0 else nine) for i in range(6000)]);hy=np.tile([1,9],3000)
 vt=np.stack([tubular(rng,i%10) for i in range(1500)]);vf=np.stack([glyph(rng,str(i%10),TRAIN_FONTS[int(rng.integers(len(TRAIN_FONTS)))]) for i in range(1500)]);vn=np.stack([negative(rng) for _ in range(1000)])
 x=np.concatenate([m,h[hs['train']],tubes,fonts,neg,hard]);y=np.concatenate([mn['y_train'][ids],info[hs['train'],0],np.arange(len(tubes))%10,np.arange(len(fonts))%10,np.full(len(neg),10),hy])
 vx=np.concatenate([h[hs['validation']],vt,vf,vn]);vy=np.concatenate([info[hs['validation'],0],np.arange(len(vt))%10,np.arange(len(vf))%10,np.full(len(vn),10)])
 model=tf.keras.models.load_model(out/'tube_best.keras');model.compile(optimizer=tf.keras.optimizers.Adam(.00012),loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),metrics=['accuracy'])
 started=time.time();history=[]
 class Progress(tf.keras.callbacks.Callback):
  def on_epoch_end(self,epoch,logs=None):
   row=dict(epoch=epoch+1,seconds=time.time()-started,**{k:float(v) for k,v in logs.items()});history.append(row);(ROOT/'reports/hard_training_history.json').write_text(json.dumps(history,indent=2));print(json.dumps(row),flush=True)
 model.fit(x[...,None].astype(np.float32)/255,y,validation_data=(vx[...,None].astype(np.float32)/255,vy),epochs=a.epochs,batch_size=256,verbose=0,callbacks=[Progress(),tf.keras.callbacks.ModelCheckpoint(str(out/'hard_best.keras'),monitor='val_loss',save_best_only=True),tf.keras.callbacks.ReduceLROnPlateau(monitor='val_loss',patience=2,factor=.5)])
 model=tf.keras.models.load_model(out/'hard_best.keras');conv=tf.lite.TFLiteConverter.from_keras_model(model);conv.optimizations=[tf.lite.Optimize.DEFAULT];blob=conv.convert();(out/'digit_cnn.tflite').write_bytes(blob)
 base_source=meta['source'].split(' + two manually labelled clay')[0]
 meta.update(sha256=hashlib.sha256(blob).hexdigest(),source=base_source+' + two manually labelled clay 1/9 foregrounds with replay',hard_finetune=dict(examples=len(x),epochs=a.epochs,source_foregrounds=2,foreground_labels=[1,9],augmented_hard_examples=len(hard),augmentation='affine, blur, stroke width and bounded terminal/side crop variation',validation=len(vx),seconds=time.time()-started,source_provenance='tests/fixtures/clay/source.json',user_video_crops_used_for_training=True,video_is_independent_test=False,checkpoint='minimum validation loss on original HWD validation writers and fresh generated samples; source video is not checkpoint validation data'))
 (out/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf8');print('HARD_TRAINING_COMPLETE',meta['sha256'],flush=True)
if __name__=='__main__':main()
