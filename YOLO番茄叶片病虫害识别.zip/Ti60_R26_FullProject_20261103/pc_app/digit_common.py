"""Shared foreground normalization for training and digit proposals."""
import cv2
import numpy as np

def normalize_digit(foreground):
    foreground=np.asarray(foreground,np.uint8)
    ys,xs=np.where(foreground>24)
    result=np.zeros((32,32),np.uint8)
    if not len(xs):return result
    patch=foreground[ys.min():ys.max()+1,xs.min():xs.max()+1]
    scale=24/max(patch.shape)
    h,w=max(1,round(patch.shape[0]*scale)),max(1,round(patch.shape[1]*scale))
    patch=cv2.resize(patch,(w,h),interpolation=cv2.INTER_AREA if scale<1 else cv2.INTER_LINEAR)
    y,x=(32-h)//2,(32-w)//2;result[y:y+h,x:x+w]=patch
    moments=cv2.moments(result)
    if moments['m00']:
        dx=np.clip(15.5-moments['m10']/moments['m00'],-3,3)
        dy=np.clip(15.5-moments['m01']/moments['m00'],-3,3)
        result=cv2.warpAffine(result,np.float32([[1,0,dx],[0,1,dy]]),(32,32))
    return result
