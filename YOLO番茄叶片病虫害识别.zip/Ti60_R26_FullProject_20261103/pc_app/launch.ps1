param([switch]$Check, [switch]$NoBrowser, [int]$Port = 18792)
$ErrorActionPreference = 'Stop'
$env:PYTHONIOENCODING = 'utf-8'
Set-Location -LiteralPath $PSScriptRoot
$probe = Join-Path $PSScriptRoot 'runtime_probe.py'
if (-not $Check) {
    $existing = $null
    try { $existing = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/state" -TimeoutSec 2 } catch {}
    if ($existing -and $existing.app_id -eq 'Ti60_Ethernet_ShapeDigitsTomato_R11') {
        Write-Host "Already running: http://127.0.0.1:$Port"
        if (-not $NoBrowser) { Start-Process "http://127.0.0.1:$Port" }
        exit 0
    }
}
$runtimePath = $null
$candidates = @()
if ($env:SHAPEYOLO_PYTHON) { $candidates += $env:SHAPEYOLO_PYTHON }
$candidates += (Join-Path $PSScriptRoot '.venv\Scripts\python.exe')
$localConfig = Join-Path $PSScriptRoot 'runtime.local.json'
if (Test-Path -LiteralPath $localConfig) {
    $candidates += (Get-Content -LiteralPath $localConfig -Raw | ConvertFrom-Json).python
}
foreach ($candidate in $candidates) {
    if ($candidate -and (Test-Path -LiteralPath $candidate)) {
        & $candidate $probe available
        if ($LASTEXITCODE -eq 0) { $runtimePath = $candidate; break }
    }
}
if (-not $runtimePath) {
    Write-Host 'Setting up a local Python environment. Internet is needed only for dependency installation.'
    $launcher = Get-Command py -ErrorAction SilentlyContinue
    if ($launcher) {
        & $launcher.Source -3.11 $probe version
        if ($LASTEXITCODE -ne 0) { throw 'Install Python 3.11 x64 from python.org, then run again.' }
        & $launcher.Source -3.11 -m venv (Join-Path $PSScriptRoot '.venv')
    } else {
        $launcher = Get-Command python -ErrorAction SilentlyContinue
        if (-not $launcher) { throw 'Install Python 3.11 x64 from python.org, then run again.' }
        & $launcher.Source $probe version
        if ($LASTEXITCODE -ne 0) { throw 'Python 3.11 x64 is required.' }
        & $launcher.Source -m venv (Join-Path $PSScriptRoot '.venv')
    }
    if ($LASTEXITCODE -ne 0) { throw 'Could not create the local Python environment.' }
    $runtimePath = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
    & $runtimePath -m pip install -r (Join-Path $PSScriptRoot 'requirements.txt')
    if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Check your network and rerun.' }
}
Write-Host "Python: $runtimePath"
if ($Check) {
    & $runtimePath $probe model
} else {
    $appArgs = @((Join-Path $PSScriptRoot 'app.py'), '--port', "$Port")
    if ($NoBrowser) { $appArgs += '--no-browser' }
    & $runtimePath @appArgs
}
if ($LASTEXITCODE -ne 0) { throw "Program exited with code $LASTEXITCODE" }
