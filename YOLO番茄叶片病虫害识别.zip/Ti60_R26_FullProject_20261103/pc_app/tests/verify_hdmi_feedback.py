"""V2 transport and feedback on isolated 127/8 endpoints, never the board."""
from pathlib import Path
import sys,json,struct,socket,threading,time,tempfile
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from hdmi_feedback import encode_results,decode_results,decode_polygons
from udp_video import HEADER,OSD_EXTENSION,packetize,Reassembler,UDPReceiver,RGB888
from v36_color import decode_bayer,CFG
from app import Application
from detector import Detector

def v2(packet,info=(7,3,1)):
 f=list(HEADER.unpack_from(packet));f[1]=2;f[3]=40
 return HEADER.pack(*f)+OSD_EXTENSION.pack(*info,b'T6O2')+packet[28:]

def main():
 checks=[];cv2.setNumThreads(1)
 def passed(s):checks.append(s);print('PASS',s,flush=True)
 preds=[dict(class_id=i,xyxy=[i*3,4,i*3+20,30],confidence=None if i<3 else .99) for i in range(13)]
 fid,records=decode_results(encode_results(0xffffffff,640,360,preds));assert fid==0xffffffff and len(records)==13 and records[0]['xyxy']==[0,12,60,90]
 assert [r['class_id'] for r in records]==list(range(13)) and [r['confidence'] for r in records[:3]]==[0,0,0]
 assert len(decode_results(encode_results(1,640,360,preds*3))[1])==16
 passed('all 13 shape/digit labels independently preserved, 3x HDMI mapping, contour scores not made into neural probabilities, 16-box bound')
 empty=encode_results(1,640,360,[]);assert decode_results(empty)==(1,[]) and len(empty)==18
 bad=bytearray(empty);bad[-1]^=1
 try:decode_results(bad)
 except ValueError:pass
 else:raise AssertionError('corrupt checksum accepted')
 assert not decode_results(encode_results(1,640,360,[dict(class_id=0,xyxy=[float('nan'),0,5,5]),dict(class_id=99,xyxy=[0,0,5,5])]))[1]
 passed('explicit empty results clear HDMI; malformed coordinates, class and payload checksum are rejected')
 im=np.full((80,240,3),100,np.uint8);packets=[v2(p) for p in packetize(im,8,6)];a=Reassembler()
 for p in reversed(packets):frame=a.feed(p)
 assert a.last_id==8 and a.last_version==2 and a.last_feedback==(7,3,1) and a.stats['complete_frames']==1
 a=Reassembler();a.feed(packets[0]);changed=bytearray(packets[1]);changed[33]=4;a.feed(changed);assert a.stats['invalid_packets']==1 and not a.pending
 passed('V2 metadata is frozen across chunks; shuffled frames reassemble and conflicting feedback invalidates a partial frame')
 for bad in [v2(next(packetize(im,9,6)),(7,17,1)),v2(next(packetize(im,9,6)),(7,1,32))]:
  a=Reassembler();assert a.feed(bad) is None and a.stats['invalid_packets']==1
 passed('oversized applied count and unsupported feedback flags rejected before decode')
 # The fake board binds a different loopback address at the same UDP port.
 board=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);board.bind(('127.0.0.2',0));port=board.getsockname()[1];board.settimeout(2)
 recv=UDPReceiver(dict(bind_ip='127.0.0.1',source_ip='127.0.0.2',port=port,delivery='stream'))
 try:
  raw_packets=[v2(p) for p in packetize(im,9,6)]
  for p in raw_packets:board.sendto(p,('127.0.0.1',port))
  result=None
  for _ in raw_packets:
   result=recv.read()
   if result is not None:break
  expected=decode_bayer(np.full((80,240),100,np.uint8),cv2.COLOR_BayerBGGR2BGR);assert np.array_equal(result,expected)
  recv.send_results(9,240,80,preds);data,peer=board.recvfrom(2048);assert decode_results(data)[0]==9 and peer==('127.0.0.1',port)
  assert recv.state()['hdmi_feedback']['sent']==1
  for p in packetize(im,10,6):board.sendto(v2(p,(9,3,9)),('127.0.0.1',port))
  while recv.assembler.last_id!=10:recv.read()
  recv.send_results(10,240,80,preds);data,peer=board.recvfrom(2048)
  assert decode_polygons(data)[0]==10 and len(decode_polygons(data)[1])==13
 finally:recv.close();board.close()
 passed('real UDP V2 RAW8 uses V36 color and returns checksummed result to the actual source interface/port')
 # Full inference feedback must carry the captured transport frame, never the
 # newer receiver counter that may advance while inference runs.
 detector=Detector();image=cv2.imdecode(np.fromfile(str(ROOT/'samples/图形与数字示例.png'),np.uint8),1)
 board=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);board.bind(('127.0.0.2',0));port=board.getsockname()[1];board.settimeout(.15)
 with tempfile.TemporaryDirectory(prefix='hdmi_results_') as tmp:
  app=Application(detector,tmp)
  try:
   app.start(dict(kind='udp',bind_ip='127.0.0.1',source_ip='127.0.0.2',port=port,targets='both',skip=1))
   deadline=time.monotonic()+5
   while app.session.receiver is None and time.monotonic()<deadline:time.sleep(.01)
   sent_ids=set();got=[]
   for fid in range(20,25):
    sent_ids.add(fid)
    for i,p in enumerate(packetize(image,fid,RGB888)):
     board.sendto(v2(p),('127.0.0.1',port))
     if i%16==15:time.sleep(.001)
    time.sleep(.08)
   deadline=time.monotonic()+4
   while time.monotonic()<deadline:
    try:data,_=board.recvfrom(2048)
    except socket.timeout:continue
    f,rows=decode_results(data);assert f in sent_ids
    got.append((f,rows))
    if len(rows)==13:break
   assert any(len(r)==13 for f,r in got),[(f,len(r)) for f,r in got]
   with app.session.condition:out=dict(app.session.output)
   assert out['udp_frame_id'] in sent_ids and len(out['predictions'])==13
  finally:app.stop();board.close()
 passed('actual V2 UDP -> current shape/digit model -> all 13 feedback boxes; capture retains correct wire frame id across inference')
 report=dict(passed=True,count=len(checks),checks=checks,digit_model_sha256=detector.digits.sha256,scope='Software and real localhost UDP endpoints only; does not prove physical HDMI output',config=CFG)
 (ROOT/'reports/hdmi_feedback_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print('HDMI_FEEDBACK_SOFTWARE_PASS',flush=True)
if __name__=='__main__':main()
