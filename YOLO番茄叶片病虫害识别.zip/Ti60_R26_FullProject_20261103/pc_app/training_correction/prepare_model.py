from pathlib import Path
import sys,json,hashlib,shutil
R=Path(__file__).resolve().parent;A=R/'app';sys.path.insert(0,str(A))
from tomato import pipeline_identity
result=json.loads((R/'refiner_training_result.json').read_text());assert result['training_complete']
folder=A/'model/tomato';shutil.copy2(R/'leaf_refiner.onnx',folder/'leaf_refiner.onnx')
m=json.loads((folder/'metadata.json').read_text(encoding='utf8'));m.update(pipeline='leaf-refiner-v2',refiner_sha256=result['onnx_sha256'],refiner_classes=9,proposal_confidence=.03,classification_margin=0.,crop_margin=.08,leaf_nms_iou=.6,proposal_nms_iou=.65,max_proposals=48,fusion_alpha=.5,background_threshold=.5,test_metrics=None,default_confidence=.25,refiner_validation_crop_metrics=result['validation'],confidence_meaning='Leaf category fusion score with learned background rejection; localization score recorded separately')
m['pipeline_sha256']=pipeline_identity(m);(folder/'metadata.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf8');print('REFINER_MODEL_STAGED',m['pipeline_sha256'])
