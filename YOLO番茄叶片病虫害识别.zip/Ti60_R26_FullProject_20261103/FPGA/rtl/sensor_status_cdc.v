// Coherent 256-bit status mailbox. Source holds the complete bundle until
// the returned acknowledgement; the destination reads only after two toggle
// synchronizer stages. No per-bit sampling of changing gain registers.
module sensor_status_cdc(
 input source_clk,source_rst_n,input [255:0] source_status,input source_toggle,
 input dest_clk,dest_rst_n,output reg [255:0] dest_status
);
reg [255:0] mailbox;
reg request,acknowledge,vs_d;
(* ASYNC_REG="TRUE" *) reg [1:0] ack_sync,req_sync;
always @(posedge source_clk or negedge source_rst_n)begin
 if(!source_rst_n)begin mailbox<=0;request<=0;vs_d<=0;ack_sync<=0;end
 else begin
  vs_d<=source_toggle;ack_sync<={ack_sync[0],acknowledge};
  if(source_toggle != vs_d && request==ack_sync[1])begin mailbox<=source_status;request<=~request;end
 end
end
always @(posedge dest_clk or negedge dest_rst_n)begin
 if(!dest_rst_n)begin req_sync<=0;acknowledge<=0;dest_status<=256'd0;end
 else begin
  req_sync<={req_sync[0],request};
  if(req_sync[1]!=acknowledge)begin dest_status<=mailbox;acknowledge<=req_sync[1];end
 end
end
endmodule
