"""Bounded acknowledgement/retry of the newest HDMI result only."""
import threading
import time
from collections import OrderedDict
from hdmi_feedback import encode_results, encode_polygons


class HDMIDelivery:
    def __init__(self, transmit, clock=time.monotonic, retry_interval=.075, max_attempts=3, deadline=.45):
        self.transmit, self.clock = transmit, clock
        self.retry_interval, self.max_attempts, self.deadline = retry_interval, max_attempts, deadline
        self.lock = threading.RLock()
        self.pending = None
        self.recent = OrderedDict()
        self.sent = self.errors = self.retries = self.acknowledged = self.unacknowledged = 0
        self.superseded = 0
        self.last_sent_frame = self.last_acked_frame = None
        self.last_sent_count = self.last_acked_count = 0
        self.unsupported_count = 0

    def _send(self, now):
        item = self.pending
        if item['attempts']:
            self.retries += 1
        item['attempts'] += 1
        item['due'] = now + self.retry_interval
        try:
            self.transmit(item['packet'])
            self.sent += 1
            self.last_sent_frame, self.last_sent_count = item['frame_id'], item['count']
        except OSError:
            self.errors += 1

    def submit(self, frame_id, width, height, predictions, version, feedback):
        if version not in (2,3,4) or frame_id is None:
            return
        tomato = bool(feedback and feedback[2] & 16)
        selected = [p for p in predictions if type(p.get('class_id')) is int and
                    (0 <= p['class_id'] < 13 or (tomato and 13 <= p['class_id'] <= 20))]
        encode = encode_polygons if feedback and feedback[2] & 8 else encode_results
        packet = encode(frame_id, width, height, selected)
        with self.lock:
            if self.pending:
                self.superseded += 1
            self.unsupported_count = len(predictions) - len(selected)
            now = self.clock()
            self.pending = dict(frame_id=frame_id, count=packet[5], packet=packet,
                                created=now, due=now, attempts=0)
            self.recent[frame_id] = dict(count=packet[5], acknowledged=False)
            while len(self.recent) > 16:
                self.recent.popitem(last=False)
            self._send(now)

    def observe(self, feedback):
        if not feedback:
            return
        frame_id, count, flags = feedback
        with self.lock:
            item = self.pending
            recent = self.recent.get(frame_id)
            # Count=0 is a valid explicit clear. Expired is never an ACK for a
            # nonempty result, even if the board repeats its previous frame ID.
            if recent and flags & 1 and not flags & 4 and count == recent['count']:
                if not recent['acknowledged']:
                    self.acknowledged += 1
                    recent['acknowledged'] = True
                    self.last_acked_frame, self.last_acked_count = frame_id, count
                if item and frame_id == item['frame_id']:
                    self.pending = None

    def pump(self):
        with self.lock:
            item = self.pending
            if item is None:
                return
            now = self.clock()
            if now - item['created'] >= self.deadline:
                self.unacknowledged += 1
                self.pending = None
            elif now >= item['due'] and item['attempts'] < self.max_attempts:
                self._send(now)

    def state(self):
        with self.lock:
            item = self.pending
            return dict(sent=self.sent, errors=self.errors, retries=self.retries,
                        acknowledged=self.acknowledged, unacknowledged=self.unacknowledged,
                        superseded=self.superseded, last_sent_frame=self.last_sent_frame,
                        last_sent_count=self.last_sent_count, last_acked_frame=self.last_acked_frame,
                        last_acked_count=self.last_acked_count, unsupported_count=self.unsupported_count,
                        pending_frame=item['frame_id'] if item else None,
                        pending_age_ms=round((self.clock()-item['created'])*1000) if item else None,
                        max_attempts=self.max_attempts, retry_interval_ms=round(self.retry_interval*1000))
