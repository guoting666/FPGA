"""Regression for user-provided gold numerals, independent overlapping tasks."""
from pathlib import Path
import sys,json
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from detector import Detector
from geometry import ShapePipeline

def main():
 cv2.setNumThreads(1);d=Detector();im=cv2.imread(str(ROOT/'tests/fixtures/gold_digits_user.png'));checks=[];results=[]
 def passed(name):checks.append(name);print('PASS',name,flush=True)
 for size in [1.,.75,.5]:
  frame=cv2.resize(im,None,fx=size,fy=size,interpolation=cv2.INTER_AREA)
  p,t=ShapePipeline(d).predict(frame,.96,targets='both')
  digits=[x for x in p if x.get('group')=='digit'];assert sorted(x['digit'] for x in digits)==list('0123456789'),(size,p)
  # Semantic arrangement is manually known, not inferred from model outputs.
  rows=[sorted([x for x in digits if (x['xyxy'][1]+x['xyxy'][3])/2 < frame.shape[0]*.52],key=lambda p:p['xyxy'][0]),sorted([x for x in digits if (x['xyxy'][1]+x['xyxy'][3])/2 >= frame.shape[0]*.52],key=lambda p:p['xyxy'][0])]
  assert [''.join(x['digit'] for x in row) for row in rows]==['01234','56789']
  triangle=[x for x in p if x['class_id']==0];four=next(x for x in digits if x['digit']=='4')
  assert any(x['xyxy'][0]>four['xyxy'][0] and x['xyxy'][2]<four['xyxy'][2] and x['xyxy'][1]>four['xyxy'][1] and x['xyxy'][3]<four['xyxy'][3] for x in triangle),triangle
  results.append(dict(scale=size,predictions=p,timing=t))
 passed('all ten gold digits have correct row/column labels at three scales; triangle inside digit 4 also remains')
 p,_=ShapePipeline(d).predict(im,.96,targets='digits');assert sorted(x['class_id'] for x in p)==list(range(3,13))
 passed('digit-only mode excludes shape contours without changing digit labels')
 p,_=ShapePipeline(d).predict(im,.96,targets='shapes');assert any(x['class_id']==0 for x in p) and not any(x['class_id']>=3 for x in p)
 passed('shape-only mode retains inner triangle and excludes digits')
 pipe=ShapePipeline(d);assert not pipe.predict(im,.96,targets='both',stable=True)[0]
 assert len([x for x in pipe.predict(im,.96,targets='both',stable=True)[0] if x['class_id']>=3])==10
 assert not pipe.predict(np.full_like(im,230),.96,targets='both',stable=True)[0]
 passed('combined gold-digit video confirmation and immediate clearing when removed')
 report=dict(passed=True,count=len(checks),checks=checks,digit_model_sha256=d.digits.sha256,scope='User-supplied debugging regression, not an independent benchmark. Image never used in model training.',before=dict(digits_detected=0,triangles=1),results=results,board_tested=False)
 (ROOT/'reports/gold_regression.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 # Standard annotation of the same input and full combined pipeline.
 p,t=ShapePipeline(d).predict(im,.96,targets='both');cv2.imwrite(str(ROOT/'reports/gold_digits_fixed.jpg'),d.annotate(im,p))
if __name__=='__main__':main()
