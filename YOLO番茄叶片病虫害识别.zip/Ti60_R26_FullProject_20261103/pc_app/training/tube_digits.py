"""Procedural round-ended strokes for thick, bent and clay-like digits.

No crops or tracing of the user's video are used as training images. Control
points below describe generic digit strokes and are independently perturbed.
"""
import cv2,numpy as np
from digit_common import normalize_digit

PATHS={
 1:[[(28,26),(45,16),(53,20),(50,38),(42,61),(37,81)]],
 2:[[(26,25),(37,16),(56,16),(68,25),(63,38),(47,49),(31,62),(26,77),(45,81),(68,79)]],
 3:[[(27,22),(45,15),(63,22),(60,36),(43,45),(62,52),(66,67),(53,80),(30,76)]],
 4:[[(56,17),(25,59),(72,59)],[(58,17),(58,83)]],
 5:[[(68,18),(31,18),(29,43),(47,41),(63,48),(65,66),(52,80),(29,76)]],
 6:[[(62,17),(44,15),(29,34),(25,58),(31,76),(48,82),(64,70),(63,51),(47,45),(29,55)]],
 7:[[(24,17),(69,17),(55,38),(44,61),(37,82)]],
 8:[[(48,13),(28,22),(31,39),(61,57),(65,74),(48,84),(27,74),(30,55),(61,37),(65,22),(48,13)]],
 9:[[(63,37),(63,21),(47,14),(30,22),(27,39),(43,48),(61,40),(61,59),(50,80),(34,83)]]}

def smooth(points):
 p=np.asarray(points,np.float32);p=np.concatenate([p[:1],p,p[-1:]],axis=0);parts=[]
 for i in range(len(p)-3):
  a,b,c,d=p[i:i+4];t=np.linspace(0,1,12)[:,None]
  parts.append(.5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t))
 return np.concatenate(parts).round().astype(np.int32)

def tubular(rng,digit):
 raw=np.zeros((100,100),np.uint8);thick=int(rng.integers(9,21))
 if digit==0:
  cv2.ellipse(raw,(49,49),(int(rng.integers(17,25)),32),float(rng.uniform(-7,7)),0,360,255,thick,cv2.LINE_AA)
 else:
  jitter=rng.normal(0,2.4,(2,));paths=PATHS[digit]
  for path in paths:
   points=np.asarray(path,float)+rng.normal(0,1.7,(len(path),2))+jitter
   # A straight-sided 4/7 is kept angular; other strokes bend smoothly.
   line=points.round().astype(np.int32) if digit in (4,7) else smooth(points)
   cv2.polylines(raw,[line],False,255,thick,cv2.LINE_AA)
   for point in (line[0],line[-1]):cv2.circle(raw,tuple(point),thick//2,255,-1,cv2.LINE_AA)
 if rng.random()<.35:
  xx,yy=np.meshgrid(np.arange(100),np.arange(100));shade=.75+.25*np.sin(xx/rng.uniform(12,30)+yy/30)
  raw=(raw*shade).astype(np.uint8)
 if rng.random()<.25:raw=cv2.GaussianBlur(raw,(3,3),.7)
 return normalize_digit(raw)
