`define AXI_EN  

module video_gen_top #(
    parameter SYMBOL_WIDTH = 'd10,
	  parameter SYMBOL_NUM	= 'd3,
    parameter PAR_PIXEL_NUM = 'd1,
    parameter MAX_WIDTH       = 1920,
    parameter MAX_HEIGTH      = 1080,
    parameter FRAME_WIDTH     = 1920,
    parameter FRAME_HEIGHT    = 1080,

    parameter	H_FRONT_PORCH 	= 13'd20, 
    parameter	H_SYNC 			    = 13'd20, 
    parameter	H_VALID 		    = 13'd1920, 
    parameter	H_BACK_PORCH 	  = 13'd20,
    parameter	V_FRONT_PORCH 	= 13'd5, 
    parameter	V_SYNC 			    = 13'd5, 
    parameter	V_VALID 		    = 13'd10, 
    parameter	V_BACK_PORCH 	  = 13'd20,
    parameter VSYNC_POL       = 1'b1,
    parameter HSYNC_POL       = 1'b1,

    parameter DATA_WIDTH = SYMBOL_WIDTH*SYMBOL_NUM*PAR_PIXEL_NUM,
    parameter H_WIDTH = $clog2(MAX_WIDTH),
    parameter C_WIDTH = $clog2(MAX_HEIGTH)

)(
    input wire axi_clk,
    input wire rst_n,
    input wire mode,
        
    input wire [H_WIDTH-1:0] src_width,
    input wire [C_WIDTH-1:0] src_height,
    // AXI Stream 发送接口

    `ifdef AXI_EN 
    output wire [DATA_WIDTH-1:0] m_axis_tdata,
    output wire                  m_axis_tvalid,
    input wire                   m_axis_tready,
    output wire                  m_axis_tuser,
    output wire                  m_axis_tlast
    `else 
    output		 	[DATA_WIDTH-1:0] 			vout ,
	  output		wire										o_hs,
	  output		wire										o_vs,
	  output		wire										o_de
    `endif
);


  wire [23:0] gen_m_axis_tdata ;
  wire gen_m_axis_tvalid;
  wire gen_m_axis_tready;
  wire gen_m_axis_tuser ;
  wire gen_m_axis_tlast ;
`ifndef AXI_EN
     wire [DATA_WIDTH-1:0] m_axis_tdata;
     wire                  m_axis_tvalid;
     wire                  m_axis_tready;
     wire                  m_axis_tuser;
     wire                  m_axis_tlast;
 `endif
    // 实例化待测模块
video_gen # (
    .SYMBOL_WIDTH(SYMBOL_WIDTH),
    .SYMBOL_NUM(SYMBOL_NUM),
    .PAR_PIXEL_NUM(PAR_PIXEL_NUM),
    .MAX_WIDTH(MAX_WIDTH),
    .MAX_HEIGTH(MAX_HEIGTH)
  )
  video_gen_inst (
    .clk(axi_clk),
    .rst_n(rst_n),
    .mode(mode),
    .src_width(src_width),
    .src_height(src_height),
    .m_axis_tdata (gen_m_axis_tdata ),
    .m_axis_tvalid(gen_m_axis_tvalid),
    .m_axis_tready(gen_m_axis_tready),
    .m_axis_tuser (gen_m_axis_tuser ),
    .m_axis_tlast (gen_m_axis_tlast )
  );

    axis_dly # (
    .DATA_WIDTH(DATA_WIDTH),
    .DELAY_CYCLES(1)
  )
  axis_dly_inst (
    .clk(axi_clk),
    .rst_n(rst_n),
    .s_axis_tdata (gen_m_axis_tdata),
    .s_axis_tvalid(gen_m_axis_tvalid),
    .s_axis_tready(gen_m_axis_tready),
    .s_axis_tlast (gen_m_axis_tlast),
    .s_axis_tuser (gen_m_axis_tuser),
    .m_axis_tdata (m_axis_tdata),
    .m_axis_tvalid(m_axis_tvalid),
    .m_axis_tready(m_axis_tready),
    .m_axis_tlast (m_axis_tlast),
    .m_axis_tuser (m_axis_tuser)
  );
`ifndef AXI_EN
localparam FIFO_DIPTH = 32;
   cvo_axi # (
    .SYMBOL_WIDTH(SYMBOL_WIDTH),
    .SYMBOL_NUM (SYMBOL_NUM),
    .PIXEL_NUM  (PAR_PIXEL_NUM),
    .HSYNC_POL  (HSYNC_POL),
    .VSYNC_POL  (VSYNC_POL),
    .FIFO_DEPTH (FIFO_DIPTH),
    .MAX_H_VALID(H_WIDTH),
    .MAX_V_VALID(MAX_HEIGTH),
    .FIFO_ALMOST_FULL(16)
  )
  cvo_axi_inst (
    .rst_n(rst_n),
    .fifo_rd_period(fifo_rd_period),
    .fifo_rd_underflow(fifo_rd_underflow),
    .s_axi_clk(axi_clk),
    .s_axis_tdata (m_axis_tdata),
    .s_axis_tvalid(m_axis_tvalid),
    .s_axis_tready(m_axis_tready),
    .s_axis_tlast (m_axis_tlast),
    .s_axis_tuser (m_axis_tuser),
    .H_FRONT_PORCH(H_FRONT_PORCH),
    .H_SYNC(H_SYNC),
    .H_VALID(H_VALID),
    .H_BACK_PORCH(H_BACK_PORCH),
    .V_FRONT_PORCH(V_FRONT_PORCH),
    .V_SYNC(V_SYNC),
    .V_VALID(V_VALID),
    .V_BACK_PORCH(V_BACK_PORCH),
    .o_clk(axi_clk ),
    .vout(vout),
    .o_hs(o_hs),
    .o_vs(o_vs),
    .o_de(o_de)
  );

`endif
endmodule
