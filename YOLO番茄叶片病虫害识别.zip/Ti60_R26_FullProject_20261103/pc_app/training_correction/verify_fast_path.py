from pathlib import Path
import sys,json,time
import cv2,numpy as np
R=Path(__file__).resolve().parent;B=R.parent/'tomato_feature';A=R/'app';sys.path.insert(0,str(A))
from tomato import TomatoDetector
cv2.setNumThreads(1);model=TomatoDetector();old=json.loads((A/'reports/remaining_99_predictions.json').read_text(encoding='utf8'));records=json.loads((B/'split_audit.json').read_text(encoding='utf8'))['records'];mapping={Path(r['path']).name:r for r in records if r['split']=='test'};times=[];proposals=[]
for i,row in enumerate(old):
 image=cv2.imread(str(B/'data/grouped_dataset'/mapping[row['file']]['path']));pred,t=model.predict(image,model.state()['default_confidence']);reference=row['new'];assert len(pred)==len(reference),(row['file'],len(pred),len(reference));pending=reference[:]
 for p in pred:
  matches=[(j,q) for j,q in enumerate(pending) if q['class_id']==p['class_id'] and abs(q['confidence']-p['confidence'])<.0001 and np.max(np.abs(np.array(p['xyxy'])-q['xyxy']))<.01];assert matches,(row['file'],p,pending);pending.pop(matches[0][0])
 times.append(t['tomato_total_ms']);proposals.append(t['proposals'])
 if i%25==0:print('FAST_PATH_EQUIVALENCE',i+1,99,flush=True)
report=dict(passed=True,images=99,all_labels_boxes_scores_preserved=True,scope='Only skips classifier calls for proposals the selected localization threshold would later reject; no model/threshold fitting',median_ms=float(np.median(times[1:])),p95_ms=float(np.percentile(times[1:],95)),mean_proposals=float(np.mean(proposals)),max_proposals=max(proposals))
(A/'reports/fast_path_verification.json').write_text(json.dumps(report,indent=2),encoding='utf8');comparison=json.loads((A/'reports/remaining_99_comparison.json').read_text(encoding='utf8'));comparison['timing']['before_optimization_new_median_ms']=comparison['timing']['new_median_ms'];comparison['timing']['new_median_ms']=report['median_ms'];(A/'reports/remaining_99_comparison.json').write_text(json.dumps(comparison,ensure_ascii=False,indent=2),encoding='utf8');print('FAST_PATH_PASS',json.dumps(report),flush=True)
