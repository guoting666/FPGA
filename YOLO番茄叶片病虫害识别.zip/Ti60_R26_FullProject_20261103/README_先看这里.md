# Ti60 R26 完整工程

这是 2026-11-03 现场验收通过的 R26 快照，用户确认“分层消失，移动也更稳”。
色彩保留已接受档位 3，AWB 开启。实测新画面约 15 FPS、HDMI 扫描约 60 Hz、网传约 7.5 FPS。

## 包含内容

- `FPGA/ti60f225_oob.xml`：可直接由 Efinity 打开的完整工程，包含 RTL、IP、引脚与时序约束、初始化表和调试配置。
- `firmware/Ti60_R26_WriteStart_J5.bit`：已验收的位流；与 `FPGA/outflow/ti60f225_oob.bit` 内容相同。
- `pc_app/`：完整网页程序、当前色彩配置、形状/数字/番茄病叶模型、训练脚本、测试、示例和许可证。
- `validation/`：编译、时序、实际写地址零碰撞、零欠载、150 帧 RAW 检查及用户验收记录。
- `PACKAGE_MANIFEST.json`、`verify_package.py`：每个打包文件的 SHA256 和完整性检查。

不打包编译缓存、Python 虚拟环境、历史网页上传/采样缓存；模型和运行所需文件均已包含。

## 使用现成位流

1. 摄像头接 J5，板卡为 Ti60F225 / I3；连接电源、下载 USB、HDMI 和网线。
2. 使用 Efinity Programmer，选择下载器 B 接口，以 JTAG/SRAM 模式加载 `firmware/Ti60_R26_WriteStart_J5.bit`。本包没有自动下载动作，现场验收时未写 Flash。
3. 电脑有线网卡设置 `192.168.0.3`，掩码 `255.255.255.0`；板卡固定为 `192.168.0.2`，UDP 端口 `8080`。
4. 双击根目录 `启动网页.cmd`，访问 `http://127.0.0.1:18792/`。网页选择“网络直连 / UDP”，按 `pc_app/R26_网络设置.json` 的参数启动；图像源地址为 `192.168.0.2`。

`pc_app/launch.ps1` 优先使用环境变量 SHAPEYOLO_PYTHON、目录内 .venv 或可用的 runtime.local.json。另一台电脑上的旧路径不存在时会自动跳过；需要安装 Python 3.11 x64，首次创建环境时从 requirements.txt 安装依赖，需要联网。Efinity 和 Python 安装程序不包含在压缩包中。

双击 `检查模型.cmd` 可检查本机依赖和三个识别模型；此检查不连接板卡。换目录或另一台电脑使用时，程序和模型相对当前目录加载。原 PC 程序的 R8/R11 文件夹标记与历史报告保留，当前 FPGA 版本以本说明和 PACKAGE_MANIFEST.json 中的 R26 为准。

## 修改并重新编译

使用 Efinity 2026.1.132，打开 `FPGA/ti60f225_oob.xml`。建议解压到较短路径，例如 `C:\FPGA\Ti60_R26`。
也可进入 FPGA 目录运行：

```powershell
py -3.11 .\build_offline.py --efinity-root 'F:\FPGA'
```

将安装目录参数改为本机 Efinity 路径。该脚本只进行 map/interface/pnr/pgm 位流生成，不下载板卡。重新编译后时序和实板效果需对应新位流重新验证。

## 完整性检查

```powershell
py -3.11 .\verify_package.py
```

验收位流 SHA256：`7c1e6be372b87fa9ae2f8298efcf7d29cdd0f1be1381762788906a3c0cfad9c1`。
validation 中的原始日志保留了生成时的工作路径，仅作验证记录；运行程序不依赖那些历史路径。
