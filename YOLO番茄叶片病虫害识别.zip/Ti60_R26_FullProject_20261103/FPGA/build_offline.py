"""Offline Efinity compilation only. Never calls a programmer or accesses JTAG."""
from pathlib import Path
import subprocess, sys, json, hashlib, time
import argparse
parser=argparse.ArgumentParser()
parser.add_argument('--efinity-root',type=Path,default=Path('F:/FPGA'))
args=parser.parse_args()
bat=args.efinity_root/'bin/efx_run.bat'
if not bat.is_file(): parser.error('Efinity installation not found; pass --efinity-root')
p=Path(__file__).resolve().parent
r={'hardware_tested':False,'board_programmed':False,'started_unix':time.time(),'stages':[]}
r['source_sha256']={str(f.relative_to(p)).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest() for f in list((p/'rtl').rglob('*'))+list((p/'ip').rglob('*'))+list(p.glob('*.xml'))+list(p.glob('*.sdc'))+list(p.glob('*.mem'))+list(p.glob('*.memh'))+list(p.glob('*.v'))+list(p.glob('debug*.json'))+list(p.glob('v36*.json')) if f.is_file()}
for flow in ['map','interface','pnr','pgm']:
 print('START',flow,flush=True)
 with (p/(flow+'.log')).open('w',encoding='utf8') as f:
  try:
   # Keep batch quoting inside a batch file; Windows argv escaping would
   # otherwise pass literal backslashes before embedded quote characters.
   stage=p/'_build_stage.cmd'
   stage.write_text('@echo off\ncall "'+str(bat.resolve())+'" ti60f225_oob.xml --flow '+flow+'\nexit /b %ERRORLEVEL%\n',encoding='utf8')
   proc=subprocess.run(['cmd.exe','/d','/c',stage.name],cwd=p,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
   code=proc.returncode
  except subprocess.TimeoutExpired: code=-1
 log=(p/(flow+'.log')).read_text(encoding='utf8',errors='replace')
 ok=code==0 and flow+' :\tPASS' in log
 if flow=='map' and ok:
  import re
  warnings=(p/'outflow/ti60f225_oob.warn.log').read_text(encoding='utf8')
  bad=[line for line in warnings.splitlines() if 'does not have a driver' in line and re.search(r"net '(live_|diag_|capture_en|net_frame_read|osd_|.*feedback)",line)]
  (p/'reports').mkdir(exist_ok=True)
  (p/'reports/signal_driver_audit.json').write_text(json.dumps({'passed':not bad,'disconnected_new_signals':bad},indent=2))
  if bad: print('Disconnected new signals: '+str(bad),flush=True); ok=False

 r['stages'].append({'stage':flow,'returncode':code,'pass':ok})
 (p/'build_result.json').write_text(json.dumps(r,indent=2),encoding='utf8')
 print('END',flow,code,'PASS' if ok else 'FAIL',flush=True)
 if not ok:
  print(log[-5000:],flush=True);sys.exit(2)
b=p/'outflow/ti60f225_oob.bit'
r['bit_sha256']=hashlib.sha256(b.read_bytes()).hexdigest()
r['finished_unix']=time.time()
(p/'build_result.json').write_text(json.dumps(r,indent=2),encoding='utf8')
print(json.dumps(r,indent=2),flush=True)
