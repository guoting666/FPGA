// Streaming feedback parser: one header and one record in registers. Avoids
// a multiported packet RAM/mux tree. Mailbox is read only after a valid toggle.
module osd_result_rx #(parameter MAX_BOXES=16, MAX_RESULT_AGE=6)(
 input clk,rst_n,input rec_valid,input [15:0] rec_length,input [7:0] ram_data,
 output [10:0] ram_addr,input [31:0] current_frame_id,
 output reg [MAX_BOXES*128-1:0] boxes,output reg [4:0] box_count,
 output reg [31:0] result_frame_id,output reg request_toggle,
 input acknowledge_toggle,input display_expired,
 output reg [31:0] applied_frame_id,output [4:0] applied_count,
 output [15:0] feedback_flags,output reg [31:0] rejected_packets);
localparam IDLE=0,ADDR=1,WAIT_RAM=2,READ=3,CHECK=4,PUBLISH=6;
reg [2:0] state;reg rec_d,waiting_commit,have_applied,have_seen,bad_record;
reg [1:0] ack_sync,expired_sync;reg [8:0] index,packet_length;
reg [4:0] record_byte,record_index;reg [15:0] checksum,tail;
reg [127:0] header;reg [143:0] record_data;
reg [31:0] last_seen;reg [4:0] committed_count;
assign ram_addr={2'b0,index};
assign applied_count=expired_sync[1]?0:committed_count;
assign feedback_flags={11'd0,2'b11,expired_sync[1],(rejected_packets!=0),have_applied};
wire polygon=header[127:96]==32'h54365031;
wire [31:0] incoming_id=header[63:32];
wire [31:0] frame_age=current_frame_id-incoming_id,sequence_delta=incoming_id-last_seen;
wire [143:0] next_record={record_data[135:0],ram_data};
wire legal=(polygon || header[127:96]==32'h54364f31) && header[95:88]==1 && header[87:80]<=MAX_BOXES &&
 header[79:64]==packet_length && packet_length==18+header[87:80]*(polygon?18:10) &&
 header[31:16]==1920 && header[15:0]==1080 && tail==~checksum && !bad_record &&
 record_index==header[87:80] && record_byte==0 && frame_age<=MAX_RESULT_AGE &&
 (!have_seen || sequence_delta==0 || !sequence_delta[31]);
reg record_legal;reg [127:0] packed_record;reg [10:0] xa,ya,xb,yb;integer j;
always @*begin
 record_legal=1;packed_record=0;xa=next_record[58:48];ya=next_record[42:32];xb=next_record[26:16]-1'b1;yb=next_record[10:0]-1'b1;
 if(polygon)begin
  if(next_record[143:136]>20 || next_record[135:128]>100)record_legal=0;
  for(j=0;j<4;j=j+1)if(next_record[32*j+16+:16]>=1920 || next_record[32*j+:16]>=1080)record_legal=0;
  packed_record={next_record[140:136],next_record[134:128],28'd0,
    next_record[122:112],next_record[106:96],next_record[90:80],next_record[74:64],
    next_record[58:48],next_record[42:32],next_record[26:16],next_record[10:0]};
 end else begin
  if(next_record[79:72]>20 || next_record[71:64]>100 || next_record[63:48]>=next_record[31:16] ||
     next_record[47:32]>=next_record[15:0] || next_record[31:16]>1920 || next_record[15:0]>1080)record_legal=0;
  packed_record={next_record[76:72],next_record[70:64],28'd0,xa,ya,xb,ya,xb,yb,xa,yb};
 end
end
always @(posedge clk or negedge rst_n)begin
 if(!rst_n)begin
  state<=IDLE;rec_d<=0;ack_sync<=0;expired_sync<=3;waiting_commit<=0;have_applied<=0;have_seen<=0;
  index<=0;packet_length<=18;checksum<=0;tail<=0;header<=0;record_data<=0;record_byte<=0;record_index<=0;bad_record<=0;
  boxes<=0;box_count<=0;result_frame_id<=0;request_toggle<=0;applied_frame_id<=0;committed_count<=0;last_seen<=0;rejected_packets<=0;
 end else begin
  rec_d<=rec_valid;ack_sync<={ack_sync[0],acknowledge_toggle};expired_sync<={expired_sync[0],display_expired};
  if(waiting_commit && ack_sync[1]==request_toggle)begin applied_frame_id<=result_frame_id;committed_count<=box_count;have_applied<=1;waiting_commit<=0;end
  case(state)
   IDLE:if(rec_valid&&!rec_d)begin
    if(rec_length>=26 && rec_length<=314 && request_toggle==ack_sync[1] && !waiting_commit)begin
     packet_length<=rec_length-8;index<=0;checksum<=0;tail<=0;header<=0;record_data<=0;record_byte<=0;record_index<=0;bad_record<=0;state<=ADDR;
    end else rejected_packets<=rejected_packets+1'b1;
   end
   ADDR:state<=WAIT_RAM;
   WAIT_RAM:state<=READ;
   READ:begin
    if(index<16)header<={header[119:0],ram_data};
    if(index<packet_length-2)checksum<=checksum+ram_data;
    else tail<={tail[7:0],ram_data};
    if(index>=16 && index<packet_length-2)begin
     record_data<=next_record;
     if(record_byte==(polygon?17:9))begin
      record_byte<=0;record_index<=record_index+1'b1;
      if(!record_legal || record_index>=MAX_BOXES)bad_record<=1;
      else boxes[record_index*128+:128]<=packed_record;
     end else record_byte<=record_byte+1'b1;
    end
    if(index==packet_length-1)state<=CHECK;
    else begin index<=index+1'b1;state<=ADDR;end
   end
   CHECK:if(legal)state<=PUBLISH;else begin rejected_packets<=rejected_packets+1'b1;state<=IDLE;end
   PUBLISH:begin
    box_count<=header[84:80];result_frame_id<=incoming_id;last_seen<=incoming_id;have_seen<=1;
    request_toggle<=~request_toggle;waiting_commit<=1;state<=IDLE;
   end
   default:state<=IDLE;
  endcase
 end
end
endmodule
