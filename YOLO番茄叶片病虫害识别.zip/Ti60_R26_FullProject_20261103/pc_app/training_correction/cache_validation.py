from pathlib import Path
import sys,json,time
import cv2,numpy as np
R=Path(__file__).resolve().parent;B=R.parent/'tomato_feature';A=R/'app';sys.path.insert(0,str(A))
from tomato import TomatoDetector
cv2.setNumThreads(1);model=TomatoDetector();records=json.loads((B/'split_audit.json').read_text(encoding='utf8'))['records'];output=[]
for index,row in enumerate([r for r in records if r['split']=='val']):
 path=B/'data/grouped_dataset'/row['path'];im=cv2.imread(str(path));h,w=im.shape[:2];candidates,timing=model.candidates(im,candidate_floor=.03);gt=[]
 for line in (path.parent.parent/'labels'/(path.stem+'.txt')).read_text().splitlines():
  c,x,y,bw,bh=map(float,line.split());gt.append(dict(class_id=int(c),xyxy=(np.array([x-bw/2,y-bh/2,x+bw/2,y+bh/2])*[w,h,w,h]).tolist()))
 output.append(dict(file=path.name,source_group=row['group'],ground_truth=gt,candidates=candidates,timing=timing))
 if index%20==0:print('VALIDATION_CANDIDATES',index+1,107,flush=True)
(R/'validation_candidates.json').write_text(json.dumps(output,ensure_ascii=False),encoding='utf8');print('VALIDATION_CANDIDATES_COMPLETE',flush=True)
