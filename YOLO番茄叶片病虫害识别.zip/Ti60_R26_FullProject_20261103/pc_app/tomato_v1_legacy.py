"""Locally trained tomato YOLOv8n, OpenCV ONNX CPU runtime only."""
from pathlib import Path
import hashlib,json,time
import cv2,numpy as np
NAMES_ZH=('早疫病','斑枯病','健康叶片','细菌性斑点病','晚疫病','花叶病毒病','黄化病毒病','叶霉病')
NAMES_EN=('Tomato Early blight leaf','Tomato Septoria leaf spot','Tomato leaf','Tomato leaf bacterial spot','Tomato leaf late blight','Tomato leaf mosaic virus','Tomato leaf yellow virus','Tomato mold leaf')
OFFSET=13

class TomatoDetector:
    def __init__(self,folder=None):
        self.folder=Path(folder or Path(__file__).parent/'model/tomato')
        self.net=None;self.meta=None;self.sha256=None;self.error='';self._stamp=None

    def state(self):
        model=self.folder/'tomato_yolov8n.onnx';meta=self.folder/'metadata.json'
        stamp=(model.stat().st_mtime_ns,meta.stat().st_mtime_ns) if model.is_file() and meta.is_file() else None
        if stamp is not None and stamp!=self._stamp:
            self._stamp=stamp;self.net=None;self.meta=None;self.sha256=None
            try:
                data=json.loads(meta.read_text(encoding='utf8'))
                digest=hashlib.sha256(model.read_bytes()).hexdigest()
                if digest!=data['onnx_sha256'] or data['names_en']!=list(NAMES_EN) or data.get('source_group_overlap')!=0 or not data.get('trained'):raise ValueError('番茄模型与类别元数据校验失败')
                if data['input_size'] not in [320,384,416,512,640]:raise ValueError('番茄模型输入尺寸不受支持')
                if type(data.get('default_confidence',.40)) not in (int,float) or data.get('default_confidence',.40) not in (.25,.40,.60):raise ValueError('番茄默认阈值元数据无效')
                self.meta=data;self.sha256=digest;self.error=''
            except (OSError,ValueError,KeyError,TypeError) as exc:self.error=str(exc)
        if stamp is None:self.net=None;self.meta=None;self.sha256=None;self._stamp=None
        return dict(ready=self.meta is not None,sha256=self.sha256,names=list(NAMES_ZH),classes=8,
                    task='番茄叶片病害与健康状态',error=self.error,
                    scope='8 类病害/健康叶片；未训练独立虫害类别',metrics=self.meta.get('test_metrics') if self.meta else None,
                    default_confidence=self.meta.get('default_confidence',.40) if self.meta else .40)

    def predict(self,bgr,confidence=.40):
        started=time.perf_counter()
        if not self.state()['ready']:raise ValueError(self.error or '番茄叶片模型尚未就绪，请先完成训练并安装配套模型')
        if self.net is None:
            self.net=cv2.dnn.readNetFromONNX(str(self.folder/'tomato_yolov8n.onnx'))
            self.net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV);self.net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
        h,w=bgr.shape[:2];size=self.meta['input_size'];gain=min(size/w,size/h)
        nw,nh=round(w*gain),round(h*gain);left=round((size-nw)/2-.1);top=round((size-nh)/2-.1)
        canvas=np.full((size,size,3),114,np.uint8);canvas[top:top+nh,left:left+nw]=cv2.resize(bgr,(nw,nh),interpolation=cv2.INTER_LINEAR)
        self.net.setInput(cv2.dnn.blobFromImage(canvas,1/255.,(size,size),swapRB=True,crop=False));before=time.perf_counter();raw=self.net.forward();after=time.perf_counter()
        if raw.ndim!=3 or raw.shape[0]!=1 or raw.shape[1]!=12 or not np.isfinite(raw).all():raise ValueError('番茄检测模型输出格式不匹配')
        rows=raw[0].T;classes=rows[:,4:].argmax(1);scores=rows[np.arange(len(rows)),classes+4]
        valid=(scores>=confidence)&(rows[:,2]>1)&(rows[:,3]>1);rows=rows[valid];classes=classes[valid];scores=scores[valid]
        boxes=np.column_stack(((rows[:,0]-rows[:,2]/2-left)/gain,(rows[:,1]-rows[:,3]/2-top)/gain,rows[:,2]/gain,rows[:,3]/gain))
        kept=[]
        for c in range(8):
            ix=np.flatnonzero(classes==c)
            if len(ix):kept.extend(ix[np.asarray(cv2.dnn.NMSBoxes(boxes[ix].tolist(),scores[ix].tolist(),confidence,.45),dtype=int).reshape(-1)].tolist())
        kept=sorted(kept,key=lambda i:-scores[i])[:30];pred=[]
        for i in kept:
            x,y,bw,bh=boxes[i];x1=max(0.,min(float(w),x));y1=max(0.,min(float(h),y));x2=max(0.,min(float(w),x+bw));y2=max(0.,min(float(h),y+bh));c=int(classes[i])
            if x2>x1 and y2>y1:pred.append(dict(class_id=OFFSET+c,disease_id=c,name=NAMES_ZH[c],name_en=NAMES_EN[c],confidence=float(scores[i]),xyxy=[float(v) for v in (x1,y1,x2,y2)],group='tomato',source='trained-yolov8n-onnx'))
        end=time.perf_counter()
        return pred,dict(preprocess_ms=(before-started)*1000,invoke_ms=(after-before)*1000,postprocess_ms=(end-after)*1000,tomato_total_ms=(end-started)*1000,tomato_model_sha256=self.sha256)
