"""Held-out HWD+ writer digits composed into controlled multi-digit scenes."""
from pathlib import Path
import sys,json,argparse,time
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from digit_common import normalize_digit
from digits import DigitDetector,_iou
def main():
 pa=argparse.ArgumentParser();pa.add_argument('--hwd',type=Path,required=True);a=pa.parse_args();cv2.setNumThreads(1)
 images=np.load(a.hwd/'Images28.npy',allow_pickle=False);info=np.load(a.hwd/'WriterInfo.npy',allow_pickle=False);split=np.load(ROOT/'model/digits/hwd_split_indices.npz',allow_pickle=False);rng=np.random.default_rng(4182);model=DigitDetector()
 total=correct=fp=0;latencies=[];cases=[]
 for s in range(40):
  dark=s%2;bg=25 if dark else 235;fg=230 if dark else 25;scene=np.full((360,640,3),bg,np.uint8);truth=[]
  ids=rng.choice(split['test'],8,replace=False)
  for k,idx in enumerate(ids):
   raw=normalize_digit(np.clip(255-images[idx],0,255).astype(np.uint8));size=int(rng.integers(44,72));patch=cv2.resize(raw,(size,size));x=25+(k%4)*150;y=30+(k//4)*160
   scene[y:y+size,x:x+size]=np.clip(bg+(fg-bg)*(patch[:,:,None].astype(float)/255),0,255).astype(np.uint8)
   ys,xs=np.where(patch>60);truth.append((int(info[idx,0]),[x+int(xs.min()),y+int(ys.min()),x+int(xs.max())+1,y+int(ys.max())+1]))
  if s%3==0:scene=cv2.GaussianBlur(scene,(3,3),.75)
  pred,timing=model.predict(scene,.93);latencies.append(timing['digit_total_ms']);matched=set();good=0
  for p in sorted(pred,key=lambda p:-p['confidence']):
   options=[(i,_iou(p['xyxy'],box)) for i,(digit,box) in enumerate(truth) if i not in matched and str(digit)==p['digit']]
   if options:
    i,overlap=max(options,key=lambda r:r[1])
    if overlap>=.5:matched.add(i);good+=1;continue
   fp+=1
  correct+=good;total+=len(truth);cases.append(dict(scene=s,dark_background=bool(dark),true=len(truth),detected=len(pred),correct=good))
 report=dict(scope='40 controlled composed scenes using test-writer HWD+ digits, separated objects, 44-71 pixel render size, two polarities, mild blur. Used during proposal tuning; not blind evaluation, real camera accuracy or mAP.',used_for_postprocessing_tuning=True,images=40,ground_truth_digits=total,true_positives=correct,false_positives=fp,precision=correct/max(correct+fp,1),recall=correct/total,mean_digit_stage_ms=float(np.mean(latencies)),p95_digit_stage_ms=float(np.percentile(latencies,95)),threshold=.93,digit_model_sha256=model.sha256,board_tested=False,cases=cases)
 (ROOT/'reports/digit_detection_evaluation.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='cases'},indent=2))
if __name__=='__main__':main()
