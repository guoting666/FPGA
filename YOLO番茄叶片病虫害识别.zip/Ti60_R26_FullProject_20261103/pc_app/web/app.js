"use strict";
const $ = id => document.getElementById(id);
let lastKey = "", uploadId = "", activeSession = 0, commandPending = false;
let latestState = null, fileEpoch = 0;
let exited = false;
let initialized = false;
const phaseNames = {idle:"就绪",opening:"正在打开画面",waiting:"等待 UDP 图像",running:"正在识别",snapshot:"单张图片 · 等待下次拍照",ended:"播放结束",stopped:"已停止",error:"输入异常"};
function message(text, error=false) { $("message").textContent=text; $("message").style.color=error?"#ff9d8a":""; }
async function post(path, body) {
 const response=await fetch(path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
 const result=await response.json(); if(!response.ok) throw new Error(result.error || "操作失败"); return result;
}
function settings() {return {confidence:Number($("confidence").value)/100,skip:Number($("skip").value),mode:$("mode").value,targets:$("targets").value,digit_confidence:Number($("digit-confidence").value),tomato_confidence:Number($("tomato-confidence").value),roi:["x","y","w","h"].map(k=>Number($("roi-"+k).value))};}
function kind() {return document.querySelector('input[name="source"]:checked').value;}
function digitSummary(predictions) {
 const digits=predictions.filter(p=>p.group==="digit").sort((a,b)=>(a.xyxy[1]+a.xyxy[3])-(b.xyxy[1]+b.xyxy[3]));
 const rows=[];
 for(const digit of digits){
  const center=(digit.xyxy[1]+digit.xyxy[3])/2,height=digit.xyxy[3]-digit.xyxy[1];
  let row=rows.find(r=>Math.abs(center-r.center)<.45*Math.max(height,r.height));
  if(!row){row={center,height,items:[]};rows.push(row);}row.items.push(digit);
 }
 return rows.map(r=>r.items.sort((a,b)=>a.xyxy[0]-b.xyxy[0]).map(p=>p.digit).join(" · ")).join(" / ")||"当前未检出数字";
}
function applyTaskUI(){
 const leaf=$("targets").value==="tomato";
 for(const id of ["digit-settings","shape-settings","shape-confidence-settings","shape-counts","digit-results"])$(id).classList.toggle("hidden",leaf);
 $("tomato-options").classList.toggle("hidden",!leaf);$("tomato-results").classList.toggle("hidden",!leaf);
}
$("targets").addEventListener("change",applyTaskUI);
function clearFrame() {
 $("sync-info").textContent="检测框与画面逐帧对应";$("frame-info").textContent="等待输入";
 lastKey=""; $("image").classList.add("hidden"); $("image").removeAttribute("src"); $("placeholder").classList.remove("hidden");
 $("total").textContent="0"; for(let c=0;c<23;c++) $("count-"+c).textContent="0";
 $("tomato-summary").textContent="等待检测";$("latency").textContent="—"; $("result-caption").textContent="等待检测结果";
 $("detection-list").textContent="识别结果会显示在这里。";$("digit-summary").textContent="等待检测"; $("save").disabled=true;
}
document.querySelectorAll('input[name="source"]').forEach(input=>input.addEventListener("change",()=>{
 document.querySelectorAll(".source").forEach(label=>label.classList.toggle("selected",label.querySelector("input").checked));
 $("upload-options").classList.toggle("hidden",kind()!=="upload");$("udp-options").classList.toggle("hidden",kind()!=="udp");
}));
$("file").addEventListener("change",async()=>{
 const epoch=++fileEpoch, file=$("file").files[0]; uploadId=""; if(!file) return;
 if(file.size>256*1024*1024){message("文件超过 256 MB，请选择较短的视频。",true);return;}
 $("start").disabled=true; $("file-hint").textContent="正在导入素材……";
 try {
  const response=await fetch("/api/upload?name="+encodeURIComponent(file.name),{method:"POST",body:file});
  const result=await response.json(); if(!response.ok) throw new Error(result.error);
  if(epoch!==fileEpoch)return; uploadId=result.upload_id; $("file-hint").textContent=file.name+" · 已就绪";
 } catch(error) {message(error.message,true); $("file-hint").textContent="导入失败，请重新选择";}
 finally {if(epoch===fileEpoch)$("start").disabled=false;}
});
$("confidence").addEventListener("input",()=>{$("confidence-label").textContent=$("confidence").value+"%";});
for(const id of ["confidence","skip","mode","targets","digit-confidence","tomato-confidence","roi-x","roi-y","roi-w","roi-h"]) $(id).addEventListener("change",async()=>{
 try{if(activeSession)await post("/api/settings",settings());}catch(error){message(error.message,true);}
});
for(const [id,values] of [["roi-screen",[10,15,80,70]],["roi-all",[0,0,100,100]]])$(id).addEventListener("click",async()=>{
 ["x","y","w","h"].forEach((k,i)=>$("roi-"+k).value=values[i]);
 try{if(activeSession)await post("/api/settings",settings());clearFrame();message(id==="roi-screen"?"已只检测中央区域：左 10%、上 15%、宽 80%、高 70%。可调整数值；被控件遮住的图形可能漏检。":"已恢复全画面检测。");}catch(error){message(error.message,true);}
});
$("start").addEventListener("click",async()=>{
 if(kind()==="upload"&&!uploadId){message("请先选择一张图片或一个视频。",true);return;}
 commandPending=true; $("start").disabled=true;
 try {
  message("正在打开画面……");
  const state=await post("/api/start",{kind:kind(),upload_id:uploadId,bind_ip:$("bind-ip").value,source_ip:$("source-ip").value,port:Number($("udp-port").value),delivery:$("udp-delivery").value,loop:true,...settings()});
  activeSession=state.session_id;clearFrame();
  $("source-title").textContent={demo:"示例视频",upload:"本地素材",udp:"板载以太网 · UDP"}[kind()];
  $("source-badge").textContent=kind()==="demo"?($("targets").value==="tomato"?"数据集叶片示例":"合成画面"):"电脑端识别";
  message(kind()==="demo"?($("targets").value==="tomato"?"正在播放公开数据集叶片示例，属于离线验证。":"示例由公开手写数字与几何图形合成，属于离线演示。"):"正在读取输入画面。检测框将显示在电脑页面。");
  applyState(state);
 }catch(error){message(error.message,true);}finally{commandPending=false;$("start").disabled=false;}
});
$("stop").addEventListener("click",async()=>{
 commandPending=true;$("stop").disabled=true;
 try{applyState(await post("/api/stop",{}));message("已停止读取画面，最后一次识别结果保留供查看。");}
 catch(error){message(error.message,true);}finally{commandPending=false;}
});
$("save").addEventListener("click",async()=>{
 try{const result=await post("/api/save",{});message("已保存原图、识别画面和检测数据："+result.saved_to);}
 catch(error){message(error.message,true);}
});
$("exit").addEventListener("click",async()=>{
 try{await post("/api/shutdown",{});exited=true;$("status").textContent="已退出";$("live-dot").classList.remove("active");$("start").disabled=true;$("stop").disabled=true;$("save").disabled=true;$("exit").disabled=true;message("识别服务已退出。下次使用时重新双击启动程序。");}
 catch(error){message(error.message,true);}
});
function applyState(state) {
 if(!initialized){$("confidence").value=Math.round(state.confidence*100);$("confidence-label").textContent=Math.round(state.confidence*100)+"%";$("skip").value=String(state.skip);$("mode").value=state.mode||"verified";$("targets").value=state.targets||"both";$("digit-confidence").value=String(state.digit_confidence||.93);$("tomato-confidence").value=Number(state.tomato_confidence||.40).toFixed(2);applyTaskUI();const roi=state.roi||[0,0,100,100];["x","y","w","h"].forEach((k,i)=>$("roi-"+k).value=roi[i]);
 const radio=document.querySelector(`input[name="source"][value="${state.kind}"]`);if(radio){radio.checked=true;radio.dispatchEvent(new Event("change"));}
 if(state.upload_id){uploadId=state.upload_id;$("file-hint").textContent="已恢复先前上传的素材";}
 if(state.source_options){$("bind-ip").value=state.source_options.bind_ip;$("source-ip").value=state.source_options.source_ip;$("udp-port").value=state.source_options.port;$("udp-delivery").value=state.source_options.delivery||"stream";}
 initialized=true;}
 $("tomato-task-option").disabled=!state.tomato_model?.ready;
 const tomatoAP=state.tomato_model?.metrics?.["metrics/mAP50(B)"];
 const leafEval=state.tomato_model?.evaluation_summary;
 $("tomato-model-status").textContent=state.tomato_model?.ready?((state.tomato_model.pipeline==="leaf-refiner-v3"?"本地数据续训版":"基础模型")+" · 10 类病害 / 健康 / 叶螨危害"+(leafEval?`\n留出 ${leafEval.images} 张评估：精确率 ${(100*leafEval.precision).toFixed(1)}% · 召回率 ${(100*leafEval.recall).toFixed(1)}%`:(Number.isFinite(tomatoAP)?`\n独立测试 mAP50 ${(tomatoAP*100).toFixed(1)}%（非准确率）`:""))+"\n仍有误检、漏检，实拍效果待验证。"):(state.tomato_model?.error||"叶片模型尚未就绪");
 $("tomato-hdmi-status").textContent=state.kind==="udp"?(state.udp?.hdmi_feedback?.supports_tomato?"HDMI 旧固件支持原八类叶片标注；双斑叶螨危害、靶斑病当前仅在电脑显示。":"病害结果在电脑显示；HDMI 病害标注需使用配套新版板卡程序。"):"本地素材用于电脑端验证。";
 const previousPhase=latestState?.phase;latestState=state;activeSession=state.session_id;
 $("status").textContent=phaseNames[state.phase]||state.phase;
 const running=["opening","running","waiting","snapshot"].includes(state.phase);
 if(state.phase==="waiting"){clearFrame();$("frame-info").textContent="未收到完整图像帧";message(state.source_options?.delivery==="snapshot"?"正在等板卡照片：先按 KEY1，等 2 秒，再按 KEY2 发送。":"正在监听 UDP；连续视频模式下，1 秒没有完整帧即清除旧画面。");}
 if(state.phase==="snapshot")message("已收到单张图片，结果保留。可保存这一帧；按 KEY1 拍下一张，等 2 秒再按 KEY2。此模式不是实时视频。");
 if(state.kind==="udp"&&state.phase==="running"&&previousPhase!=="running")message("已收到完整 UDP 图像帧，正在识别。" );
 if(state.kind==="upload"&&state.phase==="ended"&&previousPhase!=="ended")message("本地素材已处理完成，可保存结果或重新选择图片。");
 if(state.udp){const u=state.udp;let text=`收到 ${u.packets} 包 · 完整 ${u.complete_frames} 帧 · 丢弃 ${u.dropped_frames} 帧 · 格式错误 ${u.invalid_packets} 包`;const f=u.hdmi_feedback;if(f?.enabled){text+=` · HDMI 回传 ${f.sent} 次`;if(f.board_applied&&(f.board_applied[2]&1))text+=` · HDMI 已应用 ${f.board_applied[2]&4?0:f.board_applied[1]} 框`;if(f.errors)text+=` · 回传失败 ${f.errors} 次`;const a=u.awb;if(a?.enabled){text+=` · 自动白平衡${a.settled?"已生效":"收敛中"} · R/G/B ${a.gains_q14.map(x=>(x/16384).toFixed(2)).join("/")} · 更新 ${a.updates} 次`;if(a.limited)text+=" · 增益限幅";}else text+=" · 固定白平衡";}$("udp-stats").textContent=text;}
 $("source-title").textContent={demo:"示例视频",upload:"本地素材",udp:"板载以太网 · UDP"}[state.kind]||"识别预览";
 if(state.kind==="udp"&&state.source_options?.source_ip==="127.0.0.1")$("source-title").textContent="电脑回环测试 · UDP";
 $("source-badge").textContent=state.kind==="demo"?(state.targets==="tomato"?"数据集叶片示例":"合成画面"):state.kind==="udp"?(state.source_options?.delivery==="snapshot"?"单张图片 · 非实时":"T6V1 图像流"):"电脑端识别";
 $("live-dot").classList.toggle("active",running);
 $("capture-fps").textContent=state.capture_fps.toFixed(1);$("detection-fps").textContent=state.detection_fps.toFixed(1);
 $("stop").disabled=!running||commandPending;
 if(state.error){message(state.error,true);clearFrame();$("frame-info").textContent="输入已中断";}
}
async function refreshState(){
 if(exited)return;
 try{const response=await fetch("/api/state");if(!response.ok)throw new Error();const state=await response.json();if(!commandPending)applyState(state);}
 catch(error){$("status").textContent="服务已断开";message("本机识别服务未连接，请重新双击启动程序。",true);}
 setTimeout(refreshState,600);
}
async function refreshFrame(){
 if(exited)return;
 try{
  const response=await fetch("/api/frame?after="+encodeURIComponent(lastKey));
  if(response.status===200){
   const packet=await response.json();
   if(packet.session_id===activeSession&&latestState&&!["error","waiting"].includes(latestState.phase)&&!commandPending){
    const img=new Image();img.src=packet.image;await img.decode();
    if(packet.session_id===activeSession&&!commandPending){
     lastKey=packet.key;$("image").src=packet.image;$("image").classList.remove("hidden");$("placeholder").classList.add("hidden");
     const counts=Array(23).fill(0);for(const item of packet.predictions){if(item.class_id>=0&&item.class_id<23)counts[item.class_id]++;}$("digit-summary").textContent=digitSummary(packet.predictions);
     counts.forEach((n,c)=>$("count-"+c).textContent=n);
     $("total").textContent=packet.predictions.length;$("latency").textContent=packet.timing.inference_total_ms.toFixed(1);
     $("frame-info").textContent=`${packet.width} × ${packet.height}  ·  第 ${packet.source_frame} 帧`;
     $("sync-info").textContent=`${latestState.kind==="udp"?"整帧接收后处理":"采集到结果"} ${packet.capture_to_result_ms.toFixed(0)} ms`;
     $("tomato-summary").textContent=packet.targets==="tomato"?(packet.predictions.length?`${packet.predictions.length} 个叶片目标`:"未检出叶片或置信度不足"):"等待检测";
     $("result-caption").textContent=packet.targets==="tomato"?"番茄叶片 · 分类复核":packet.targets==="digits"?"数字 CNN":packet.targets==="both"?"图形 + 数字 CNN":({verified:"YOLO + 轮廓校验",geometry:"轮廓模式",yolo:"纯 YOLO"}[packet.mode]||"识别");
     $("detection-list").textContent=packet.predictions.length?packet.predictions.slice(0,24).map(x=>x.name+(x.confidence===null?" · 轮廓":" "+Math.round(x.confidence*100)+"%")).join("　 /　 "):"这一帧没有通过当前规则的目标。";
     $("save").disabled=false;
    }
   }
  }
 }catch(error){/* The status poll reports a lost server connection. */}
 setTimeout(refreshFrame,80);
}
refreshState();refreshFrame();
