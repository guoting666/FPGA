# 番茄数据、模型与署名

- 数据镜像：zongbaoshu，https://github.com/zongbaoshu/Tomato-leaf-pest-and-disease-detection-data-set 。下载 Git LFS 实体 ZIP，SHA256 `351a9fba7620c48f511e4da4f41cc6c9a111cc5fee0750c84044f3a186d1ec81`。
- 镜像 README 指向 plantdoc 的 Roboflow 项目：https://universe.roboflow.com/plantdoc-xztat/proposed ，项目标明 CC BY 4.0。
- 原始 PlantDoc：Davinder Singh、Naman Jain、Pranjali Jain、Pratik Kayal、Sudhakar Kumawat、Nipun Batra，*PlantDoc: A Dataset for Visual Plant Disease Detection*，CoDS COMAD 2020，DOI https://doi.org/10.1145/3371158.3371196 。原作者目标检测数据和 CSV：https://github.com/pratikkayal/PlantDoc-Object-Detection-Dataset 。原仓库标明 CC BY 4.0，全文随包保存在 `licenses/PlantDoc_CC_BY_4.0.txt`。
- 改动：选用镜像中的番茄八类；安全重命名长文件名；按原来源与文件哈希重新分组划分；每个训练来源最多选三种预增强图，评估每个来源选一张；训练时作旋转、缩放、平移、翻转、颜色变化和 Mosaic；中文标签映射由原作者 CSV 文件名交叉核对。
- 训练代码：Ultralytics 8.3.221，YOLOv8n，官方 COCO 预训练初始化。https://github.com/ultralytics/ultralytics/tree/v8.3.221 ，AGPL-3.0。许可证全文见 `licenses/Ultralytics_AGPL_3.0.txt`，对应模型、训练参数和检查点与可用源码一起提供。数据许可、训练库许可分别保留，不把仓库 MIT 软件许可当作数据许可。
- 部署：固定尺寸 ONNX，OpenCV DNN CPU 推理。本程序不调用外部图像识别 API，也不上传相机画面。

中文名称与类别编号：

| 原模型 ID | 应用/HDMI ID | 原标签 | 中文 |
|---|---|---|---|
|0|13|Tomato Early blight leaf|早疫病|
|1|14|Tomato Septoria leaf spot|斑枯病|
|2|15|Tomato leaf|健康叶片|
|3|16|Tomato leaf bacterial spot|细菌性斑点病|
|4|17|Tomato leaf late blight|晚疫病|
|5|18|Tomato leaf mosaic virus|花叶病毒病|
|6|19|Tomato leaf yellow virus|黄化病毒病|
|7|20|Tomato mold leaf|叶霉病|

“Tomato leaf yellow virus”沿用数据集标签，不据此声称已区分具体病毒亚型。未训练独立虫害、螨虫或其他数据源的十类标签。COCO 初始化不是番茄模型，只有通过哈希与八类元数据检查的训练结果才可启用叶片任务。


## MobileNetV3 纠错补充

TorchVision MobileNetV3 Large，IMAGENET1K_V2初始化：https://docs.pytorch.org/vision/stable/models/generated/torchvision.models.mobilenet_v3_large.html 。权重源 https://download.pytorch.org/models/mobilenet_v3_large-5c1a4163.pth ，SHA256 5c1a416349c4cf298f2a6a5e2600ed0ee55e604713578f5e74e6bc8bcaef7997。实现许可为BSD，全文随包提供。没有使用其他作者的番茄识别权重或移用其准确率。

分类器训练来自此前PlantDoc番茄图像的标注区域及弱背景区域，增加四个用户确认错误来源作纠错训练，并重放原训练数据。四个来源不再是测试集，其全部同源变体均排除于留出评估。输出仍只有八种病害/健康；内部第九类为拒识背景，不显示成病害或虫害。
