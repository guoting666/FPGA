`timescale 1ns/1ps
module tb_motion_banks;
reg camera=0,axi=0,rst=0;always #5 camera=~camera;always #7 axi=~axi;
reg [1:0]done_sync=0,idle_sync=0;reg write_done=0;reg[7:0]write_stall=0;wire writer_idle=write_stall==0;
reg frame_start=0;wire capture,publish,ready,send,fault,display_ready;wire[2:0]stage,state;wire[1:0]writes;
wire[31:0]write_base,published_base,network_base;wire net_reserved;wire[31:0]committed,network_starts;reg[1:0] hdmi_bank=0,old_hdmi_bank=0;reg[7:0]read_pending=0;
integer memory[0:127],single_memory[0:31];integer i,cycles=0,source_frame=0,source_pos=0,source_word=0;
integer write_slot=0,writing=0,write_frames=0,network_count=0,net_word=0,net_first=0,net_slot=0;
integer hdmi_pos=0,hdmi_word=0,hdmi_first=0,hdmi_value=0,single_first=0,single_value=0;
integer hdmi_frames=0,single_torn=0,single_this_torn=0,waited_frames=0;reg sender_busy=0,reader_done=0,send_seen=0;
ge_video_engine #(.BOOT_CYCLES(20),.SETTLE_CYCLES(20),.NETWORK_INTERVAL_CYCLES(500),.WATCHDOG_CYCLES(100000)) control(
 .capture_clk(camera),.axi_clk(axi),.rst_n(rst),.frame_start(frame_start),
 .write_done_toggle(done_sync[1]),.writer_idle(idle_sync[1]),.sender_busy(sender_busy),.reader_done(reader_done),
 .hdmi_read_bank(hdmi_bank),.hdmi_protected((4'b1<<hdmi_bank)|(read_pending!=0?(4'b1<<old_hdmi_bank):4'b0)),
 .capture_en(capture),.frame_publish(publish),.capture_ready(ready),.send_toggle(send),.fault(fault),.fault_stage(stage),
 .debug_state(state),.debug_writes(writes),.write_base(write_base),.published_base(published_base),.network_base(network_base),
 .display_ready(display_ready),.network_reserved(net_reserved),.published_count(committed),.network_count(network_starts));
// A frame-distinct moving scene, including delayed DDR write responses.
always @(negedge camera)begin
 if(rst)begin
  cycles=cycles+1;source_pos=(source_pos+1)%97;frame_start=(source_pos==0);
  if(source_pos==0)begin source_frame=source_frame+1;if(state==1&&!ready)waited_frames=waited_frames+1;end
  if(source_pos==4)begin writing=capture;write_slot=write_base[22:21];source_word=0;end
  if(writing&&source_pos>=5&&source_pos<37)begin
   if((write_slot==hdmi_bank||(read_pending!=0&&write_slot==old_hdmi_bank))&&display_ready)$fatal(1,"writer bank=%0d HDMI=%0d retired=%0d pending=%0d published=%0d grant=%0d capture=%0d state=%0d source_frame=%0d pos=%0d writes=%0d",write_slot,hdmi_bank,old_hdmi_bank,read_pending,published_base>>21,write_base>>21,capture,state,source_frame,source_pos,writes);
   if(net_reserved&&write_slot==network_base[22:21])$fatal(1,"camera touched pinned network snapshot");
   memory[write_slot*32+source_word]=source_frame;single_memory[source_word]=source_frame;source_word=source_word+1;
   if(source_word==32)begin writing=0;write_done=~write_done;write_frames=write_frames+1;end
  end
  if(send!=send_seen)begin
   send_seen=send;sender_busy=1;reader_done=0;net_word=0;net_slot=network_base[22:21];net_first=memory[net_slot*32];
  end else if(sender_busy)begin
   if(cycles%13==0&&net_word<32)begin
    if(memory[net_slot*32+net_word]!=net_first)$fatal(1,"network snapshot mixed frames");net_word=net_word+1;
   end
   if(net_word==32&&cycles%13==0)begin sender_busy=0;reader_done=1;network_count=network_count+1;end
  end
  if(fault)$fatal(1,"live controller watchdog fault %d",stage);
 end
end
reg done_axi=0;
always @(posedge axi)begin
 if(!rst)begin done_axi<=0;write_stall<=0;end
 else begin
  done_axi<=write_done;
  if(writing)write_stall<=40;
  else if(write_done!=done_axi)write_stall<=17+(write_frames%11);
  else if(write_stall!=0)write_stall<=write_stall-1'b1;
 end
end
always @(posedge camera)begin
 if(!rst)begin done_sync<=0;idle_sync<=0;end
 else begin done_sync<={done_sync[0],write_done};idle_sync<={idle_sync[0],writer_idle};end
end
// A slower independent display. Keep an old AXI response pending for part of
// blanking, so the bank guard must wait beyond an address-latch transition.
always @(negedge axi)begin
 if(rst)begin
  hdmi_pos=(hdmi_pos+1)%67;
  if(read_pending!=0)read_pending=read_pending-1'b1;
  if(hdmi_pos==0)begin
   old_hdmi_bank=hdmi_bank;hdmi_bank=published_base[22:21];hdmi_word=0;single_this_torn=0;read_pending=11;
  end
  if(hdmi_pos>=24&&hdmi_pos<56)begin
   hdmi_value=memory[hdmi_bank*32+hdmi_word];single_value=single_memory[hdmi_word];
   if(hdmi_word==0)begin hdmi_first=hdmi_value;single_first=single_value;end
   else begin
    if(display_ready&&hdmi_value!=hdmi_first)$fatal(1,"HDMI frame split at word %d: %d != %d",hdmi_word,hdmi_value,hdmi_first);
    if(single_value!=single_first)single_this_torn=1;
   end
   hdmi_word=hdmi_word+1;
   if(hdmi_word==32)begin
    if(display_ready)hdmi_frames=hdmi_frames+1;
    if(single_this_torn)single_torn=single_torn+1;
   end
  end
 end
end
initial begin
 for(i=0;i<128;i=i+1)memory[i]=-1;for(i=0;i<32;i=i+1)single_memory[i]=-1;
 repeat(10)@(negedge camera);rst=1;
 repeat(200000)@(negedge camera);
 if(committed<1000||network_count<200||committed<network_count*2||hdmi_frames<1000||write_frames<1000||single_torn<10)
  $fatal(1,"insufficient coverage %d %d %d %d %d",hdmi_frames,network_count,write_frames,single_torn,waited_frames);
 $display("PASS independent camera commits=%0d network starts=%0d",committed,network_starts);
 $display("PASS coherent HDMI frames=%d network frames=%d committed camera frames=%d capture waits=%d; single-buffer control tore=%d frames",hdmi_frames,network_count,write_frames,waited_frames,single_torn);
 $finish;
end endmodule
