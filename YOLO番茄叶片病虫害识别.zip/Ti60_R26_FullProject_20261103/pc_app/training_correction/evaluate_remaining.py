from pathlib import Path
import sys,json,time
import cv2,numpy as np
R=Path(__file__).resolve().parent;B=R.parent/'tomato_feature';A=R/'app';sys.path.insert(0,str(A))
from tomato import TomatoDetector,NAMES_ZH
from tomato_v1_legacy import TomatoDetector as Original
cv2.setNumThreads(1);new=TomatoDetector();old=Original(A/'model/tomato');threshold=new.state()['default_confidence']
audit=json.loads((B/'split_audit.json').read_text(encoding='utf8'));known=json.loads((B/'app/samples/TOMATO_DEMO_ATTRIBUTION.json').read_text(encoding='utf8'));excluded={x['source_group'] for x in known['examples']}
rows=[r for r in audit['records'] if r['split']=='test' and r['group'] not in excluded];assert len(rows)==99
stats={k:np.zeros((8,3),np.int64) for k in ['old_025','old_040','new_default']};details=[];timings=[]
def accumulate(pred,truth,table):
 matched=set()
 for p in sorted(pred,key=lambda x:-x['confidence']):
  c=p['disease_id'];box=np.array(p['xyxy']);best=(-1,0.)
  for j,(tc,other) in enumerate(truth):
   if tc!=c or j in matched:continue
   inter=np.maximum(0,np.minimum(box[2:],other[2:])-np.maximum(box[:2],other[:2])).prod();overlap=inter/max(1e-9,np.prod(box[2:]-box[:2])+np.prod(other[2:]-other[:2])-inter)
   if overlap>best[1]:best=(j,overlap)
  if best[1]>=.5:table[c,0]+=1;matched.add(best[0])
  else:table[c,1]+=1
 for j,(c,_) in enumerate(truth):
  if j not in matched:table[c,2]+=1
for i,row in enumerate(rows):
 path=B/'data/grouped_dataset'/row['path'];image=cv2.imread(str(path));h,w=image.shape[:2];truth=[]
 for line in (path.parent.parent/'labels'/(path.stem+'.txt')).read_text().splitlines():
  c,x,y,bw,bh=map(float,line.split());truth.append((int(c),np.array([x-bw/2,y-bh/2,x+bw/2,y+bh/2])*[w,h,w,h]))
 base,bt=old.predict(image,.25);pred,timing=new.predict(image,threshold);timings.append(dict(old_ms=bt['tomato_total_ms'],new_ms=timing['tomato_total_ms']))
 accumulate(base,truth,stats['old_025']);accumulate([p for p in base if p['confidence']>=.4],truth,stats['old_040']);accumulate(pred,truth,stats['new_default'])
 details.append(dict(file=path.name,source_group=row['group'],old=base,new=pred,ground_truth=[dict(class_id=c,xyxy=b.tolist()) for c,b in truth]))
 if i%20==0:print('REMAINING_EVALUATION',i+1,99,flush=True)
metrics={}
for name,table in stats.items():
 tp,fp,fn=map(int,table.sum(0));f1=2*table[:,0]/np.maximum(1,2*table[:,0]+table[:,1]+table[:,2])
 metrics[name]=dict(tp=tp,fp=fp,fn=fn,precision=tp/max(1,tp+fp),recall=tp/max(1,tp+fn),macro_f1=float(f1.mean()),per_class=[dict(name=NAMES_ZH[c],tp=int(a),fp=int(b),fn=int(d),precision=float(a/max(1,a+b)),recall=float(a/max(1,a+d))) for c,(a,b,d) in enumerate(table)])
report=dict(
 passed=True,images=99,
 scope='Same 99 remaining source groups for both versions, excluding all 8 previously supplied demos, including all 4 feedback sources. These are held-out regression images, not a brand-new blind test. No fitting or parameter choice on these 99.',
 excluded_groups=sorted(excluded),class_and_iou=.5,new_default_confidence=threshold,metrics=metrics,
 old_model_sha256=old.sha256,new_pipeline_sha256=new.sha256,
 timing=dict(old_median_ms=float(np.median([t['old_ms'] for t in timings[1:]])),new_median_ms=float(np.median([t['new_ms'] for t in timings[1:]]))),
 physical_camera_tested=False)
(A/'reports/remaining_99_comparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');(A/'reports/remaining_99_predictions.json').write_text(json.dumps(details,ensure_ascii=False),encoding='utf8')
mfile=A/'model/tomato/metadata.json';m=json.loads(mfile.read_text(encoding='utf8'));m['test_metrics']=None;m['evaluation_summary']=dict(images=99,precision=metrics['new_default']['precision'],recall=metrics['new_default']['recall'],macro_f1=metrics['new_default']['macro_f1'],scope='feedback-excluded held-out regression');mfile.write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf8');print('REMAINING_99_COMPLETE',json.dumps(metrics,ensure_ascii=True),flush=True)
