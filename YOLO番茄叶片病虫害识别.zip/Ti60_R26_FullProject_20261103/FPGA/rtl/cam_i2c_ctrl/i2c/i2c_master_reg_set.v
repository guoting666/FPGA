module i2c_master_reg_set #(
 parameter DATA_LENGTH=168,I2C_REG_ADDR_WIDTH=16,I2C_DATA_WIDTH=8,
 parameter I2C_DEVICE_ADDR=8'h60,parameter START_DELAY=50000,PROBE_GAP=5000000
)(input clk,rst_n,init_done,rd_done,wr_done,input [7:0]get_data,input txn_error,
 output reg wr_en,rd_en,output [15:0]addr,output [7:0]dout,
 output [7:0]dev_addr,output reg [255:0]sensor_status,output reg sensor_toggle);
reg [7:0]cnt;reg[4:0]probe;reg[3:0]state;reg[31:0]wait_count;
reg[191:0]read_values;reg[7:0]errors;wire[24:0]rom;
i2c_master_reg_rom #(.TOTAL_ROM_DEPTH(DATA_LENGTH)) u_user_rom(clk,cnt,rom);
reg[15:0]probe_addr;
always @* begin probe_addr=0;case(probe)
 0:probe_addr=16'h3107;
 1:probe_addr=16'h3108;
 2:probe_addr=16'h0100;
 3:probe_addr=16'h3221;
 4:probe_addr=16'h3208;
 5:probe_addr=16'h3209;
 6:probe_addr=16'h320a;
 7:probe_addr=16'h320b;
 8:probe_addr=16'h320e;
 9:probe_addr=16'h320f;
 10:probe_addr=16'h3e00;
 11:probe_addr=16'h3e01;
 12:probe_addr=16'h3e02;
 13:probe_addr=16'h3e06;
 14:probe_addr=16'h3e07;
 15:probe_addr=16'h3e08;
 16:probe_addr=16'h3e09;
 17:probe_addr=16'h3202;
 18:probe_addr=16'h3203;
 19:probe_addr=16'h3212;
 20:probe_addr=16'h3213;
 21:probe_addr=16'h3301;
 22:probe_addr=16'h36e9;
 23:probe_addr=16'h37f9;
 default:probe_addr=0;endcase end
assign addr=state>=6 ? probe_addr : rom[24:9];
assign dout=rom[8:1];assign dev_addr=I2C_DEVICE_ADDR;
always @(posedge clk or negedge rst_n)begin
 if(!rst_n)begin cnt<=0;probe<=0;state<=0;wait_count<=0;read_values<=0;
 errors<=0;wr_en<=0;rd_en<=0;sensor_status<=0;sensor_toggle<=0;end
 else begin
 wr_en<=0;rd_en<=0;
 case(state)
  0:if(init_done)begin if(wait_count==START_DELAY-1)begin wait_count<=0;state<=1;end else wait_count<=wait_count+1;end
  1:state<=2;
  2:begin wr_en<=1;state<=3;end
  3:state<=4;
  4:if(wr_done)begin
    if(txn_error&&errors!=255)errors<=errors+1;
    if(cnt==DATA_LENGTH-1)begin probe<=0;state<=6;end
    else begin cnt<=cnt+1;state<=1;end
   end
  6:begin rd_en<=1;state<=7;end
  7:state<=8;
  8:if(rd_done)begin
    read_values[191-probe*8 -:8]<=get_data;
    if(txn_error&&errors!=255)errors<=errors+1;
    if(probe==23)state<=9;
    else begin probe<=probe+1;state<=6;end
   end
  9:begin sensor_status<={32'h53433031,8'd1,8'd24,errors,8'd1,read_values};sensor_toggle<=~sensor_toggle;wait_count<=0;state<=10;end
  10:if(wait_count==PROBE_GAP-1)begin wait_count<=0;probe<=0;state<=6;end else wait_count<=wait_count+1;
  default:state<=0;
 endcase
 end
end
endmodule
