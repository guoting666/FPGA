onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /tb_video_src_gen/axi_clk
add wave -noupdate /tb_video_src_gen/rst_n
add wave -noupdate /tb_video_src_gen/sync_clk
add wave -noupdate /tb_video_src_gen/sync_rst_n
add wave -noupdate /tb_video_src_gen/mode
add wave -noupdate /tb_video_src_gen/m_axis_tdata
add wave -noupdate /tb_video_src_gen/m_axis_tvalid
add wave -noupdate /tb_video_src_gen/m_axis_tready
add wave -noupdate /tb_video_src_gen/m_axis_tuser
add wave -noupdate /tb_video_src_gen/m_axis_tlast
add wave -noupdate -radix unsigned /tb_video_src_gen/vout
add wave -noupdate /tb_video_src_gen/o_de
add wave -noupdate /tb_video_src_gen/o_hs
add wave -noupdate /tb_video_src_gen/o_vs
add wave -noupdate /tb_video_src_gen/fifo_rd_period
add wave -noupdate /tb_video_src_gen/cvo_axi_inst/v_state
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {787095000 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {0 ps} {1050 us}
