
/////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2013-2021 Efinix Inc. All rights reserved.
//
// Description:
// Example top file for ti60f225 dev kit OOB design
//
// Language:  Verilog 2001
//Ti60f225_sc431hai2hdmi_v6：
//使用了最新版本的framebuffer_v3;
// ------------------------------------------------------------------------------

/////////////////////////////////////////////////////////////////////////////////
//`define SOFT_TAP 1
`include "ddr3_controller/ddr3_parameter.vh"
// `include "define.v"

module ti60f225_oob_top #(

	parameter                       RANK_RATIO         = 1,       // # of unique CS outputs per rank
	parameter                       ASYN_AXI_CLK       = `ASYN_AXI_CLK, 
	parameter                       RANKS              = `RANKS,
	parameter                       CK_WIDTH           = `CK_WIDTH,       // # of CK/CK# outputs to memory   
	parameter                       CKE_WIDTH          = `CKE_WIDTH,       // # of cke outputs
	parameter                       CS_WIDTH           = `CS_WIDTH,       // # of unique CS outputs
	parameter                       BANK_WIDTH         = `BANK_WIDTH,       // # of bank bits
	parameter                       ROW_WIDTH          = `ROW_WIDTH,       // DRAM address bus width
	parameter                       COL_WIDTH          = `COL_WIDTH,      // column address width
	parameter                       DM_WIDTH           = `DM_WIDTH,       // # of DM (data mask)
	parameter                       DQS_WIDTH          = `DQS_WIDTH,       // # of DQS (strobe)
	parameter                       DQ_WIDTH           = `DQ_WIDTH,      // # of DQ (data)
	parameter                       ODT_WIDTH          = `ODT_WIDTH,
	parameter                       DQ_CNT_WIDTH       = `DQ_CNT_WIDTH,       // = ceil(log2(DQ_WIDTH))
	parameter                       DQS_CNT_WIDTH      = `DQS_CNT_WIDTH,       // = ceil(log2(DQS_WIDTH))  
	parameter                       DRAM_WIDTH         = `DRAM_WIDTH,       // # of DQ per DQS   
	parameter                       DATA_WIDTH         = `DATA_WIDTH,
	parameter                       ADDR_WIDTH         = `ADDR_WIDTH,    
	parameter                       AXI_ID_WIDTH       = `AXI_ID_WIDTH,
	parameter                       AXI_ADDR_WIDTH     = `AXI_ADDR_WIDTH,
	parameter                       AXI_DATA_WIDTH     = `AXI_DATA_WIDTH
)
(

  (* syn_peri_port = 0 *) input jtag_inst1_CAPTURE,
  (* syn_peri_port = 0 *) input jtag_inst1_DRCK,
  (* syn_peri_port = 0 *) input jtag_inst1_RESET,
  (* syn_peri_port = 0 *) input jtag_inst1_RUNTEST,
  (* syn_peri_port = 0 *) input jtag_inst1_SEL,
  (* syn_peri_port = 0 *) input jtag_inst1_SHIFT,
  (* syn_peri_port = 0 *) input jtag_inst1_TCK,
  (* syn_peri_port = 0 *) input jtag_inst1_TDI,
  (* syn_peri_port = 0 *) input jtag_inst1_TMS,
  (* syn_peri_port = 0 *) input jtag_inst1_UPDATE,
  (* syn_peri_port = 0 *) output jtag_inst1_TDO,

   //Clocks 
  input [3:0] key,
    input	wire	i_mipi_rx_pclk,
    input wire  vid_clk_dvi2,
    input wire hdmi_tx_slow_clk,
    input wire CLK_5M,
    input  wire CLK_25M,
	output  wire    MIPI_TX_PLL_RSTN,
	input	wire	MIPI_TX_PLL_LOCKED,
  output wire GE_PLL_RSTN,
  input   wire    GE_PLL_LOCKED,
	input 	wire  	DDR3_PLL_LOCKED,
	output  wire    pll_inst4_RSTN,
	input   wire    pll_inst4_LOCKED,
	output  wire  	USER_PLL_RSTN,
    output 	wire 	DDR3_PLL_RSTN,
	input 	wire  	USER_PLL_LOCKED,
    //CSI Interface
    input	 wire		io_cam_sda_IN,
    output wire   io_cam_sda_OUT,
    output wire		io_cam_sda_OE,

    output io_cam_scl_OUT,
    input io_cam_scl_IN,
    output io_cam_scl_OE,

    output	wire		o_cam_rst_p,
    
    input	wire		i_cam_ck_LP_P_IN,
    input	wire		i_cam_ck_LP_N_IN,
    output	wire		o_cam_ck_HS_TERM,
    output	wire		o_cam_ck_HS_ENA,
    input	wire		i_cam_ck_CLKOUT,
    
    input	wire	[7:0]			cam_d0_HS_IN,
    input	  wire		      cam_d0_LP_P_IN,
    input	  wire		      cam_d0_LP_N_IN,
    output	wire		      cam_d0_HS_TERM,
    output	wire		      cam_d0_HS_ENA,
    output	wire		      cam_d0_RST,
    output	wire		      cam_d0_FIFO_RD,
    input	  wire		      cam_d0_FIFO_EMPTY,
    
    input 	wire	[7:0]			cam_d1_HS_IN,
    input	  wire		        cam_d1_LP_P_IN,
    input	  wire		        cam_d1_LP_N_IN,
    output	wire		        cam_d1_HS_TERM,
    output	wire		        cam_d1_HS_ENA,
    output	wire		        cam_d1_RST,
    output	wire		        cam_d1_FIFO_RD,
    input	  wire		        cam_d1_FIFO_EMPTY,
    
    input 	wire	[7:0]			cam_d2_HS_IN,
    input	  wire		        cam_d2_LP_P_IN,
    input	  wire		        cam_d2_LP_N_IN,
    output	wire		        cam_d2_HS_TERM,
    output	wire		        cam_d2_HS_ENA,
    output	wire		        cam_d2_RST,
    output	wire		        cam_d2_FIFO_RD,
    input	  wire		        cam_d2_FIFO_EMPTY,  
   
    input 	wire	[7:0]			cam_d3_HS_IN,
    input	  wire		        cam_d3_LP_P_IN,
    input	  wire		        cam_d3_LP_N_IN,
    output	wire		        cam_d3_HS_TERM,
    output	wire		        cam_d3_HS_ENA,
    output	wire		        cam_d3_RST,
    output	wire		        cam_d3_FIFO_RD,
    input	  wire		        cam_d3_FIFO_EMPTY,

	
	input 					tx_cal_clk_90edge,
  	input 					rx_cal_clk,
  	input 					tx_cal_clk,
	input                              core_clk,     // CORE CLK @ 100MHz
	input                              sdram_clk,    // SDRAM CK @ 400MHz
	// PLL status flags  
	output [2:0]                       pll_shift,  
	output [4:0]                       pll_shift_sel,
	output                             pll_shift_ena,  
	// memory interface ports
	output                             ddr_ck_hi,
	output                             ddr_ck_lo,
	output                             ddr_reset_n,
	output [CKE_WIDTH-1:0]             ddr_cke,     
	output [ROW_WIDTH-1:0]             ddr_addr,
	output [BANK_WIDTH-1:0]            ddr_ba,
	output                             ddr_cas_n,
 
	output [CS_WIDTH*RANK_RATIO-1:0]   ddr_cs_n,
	output                             ddr_ras_n,
	output                             ddr_we_n,
	
	input  [DQS_WIDTH-1:0]             ddr_dqs_in_hi,
	input  [DQS_WIDTH-1:0]             ddr_dqs_in_lo,
	input  [DQ_WIDTH-1:0]              ddr_dq_in_hi,
	input  [DQ_WIDTH-1:0]              ddr_dq_in_lo,
	
	output [DQS_WIDTH-1:0]             ddr_dqs_oe,
	output [DQS_WIDTH-1:0]             ddr_dqs_oe_n,
	output [DQ_WIDTH-1:0]              ddr_dq_oe,  
	output [DQS_WIDTH-1:0]             ddr_dqs_out_hi,
	output [DQS_WIDTH-1:0]             ddr_dqs_out_lo,
	output [DQ_WIDTH-1:0]              ddr_dq_out_hi,
	output [DQ_WIDTH-1:0]              ddr_dq_out_lo,
	output [DM_WIDTH-1:0]              ddr_dm_hi,
	output [DM_WIDTH-1:0]              ddr_dm_lo,
	output [ODT_WIDTH-1:0]             ddr_odt,

       //LED
       output [7:0] led,

      

       // hdmi interface

    output tmds_tx_clk_TX_OE,
    output [9:0] tmds_tx_clk_TX_DATA,
    output tmds_tx_clk_TX_RST,
    output tmds_tx_data0_TX_OE,
    output [9:0] tmds_tx_data0_TX_DATA,
    output tmds_tx_data0_TX_RST,
    output tmds_tx_data1_TX_OE,
    output [9:0] tmds_tx_data1_TX_DATA,
    output tmds_tx_data1_TX_RST,
    output tmds_tx_data2_TX_OE,
    output [9:0] tmds_tx_data2_TX_DATA,
    output tmds_tx_data2_TX_RST,


  input rxc,

  input rx_dv_HI,
  input rx_dv_LO,
  input [3:0] rxd_hi_i,
  input [3:0] rxd_lo_i,
  output phy_rst_n,
  output mdc_o,
  input  mdio_i,
  output mdio_o,
  output mdio_oe,
  output tx_en_o_HI,
  output tx_en_o_LO,
  output txc_hi_o,
  output txc_lo_o,
  output [3:0] txd_hi_o,
  output [3:0] txd_lo_o,
  output osc_inst1_ENA


);

function integer log2;
	input	integer	val;
	integer	i;
	begin
		log2 = 0;
		for (i=0; 2**i<val; i=i+1)
			log2 = i+1;
	end
endfunction


//===============================================================================
//localparam
//===============================================================================
localparam WR_FIFO_DEPTH  = 1024;
localparam RD_FIFO_DEPTH  = 1024;

// localparam	MAX_HRES		= 12'd1920;
// localparam	MAX_VRES		= 12'd1080;
// localparam	HSP			= 8'd2;
// localparam	HBP			= 8'd88;
// localparam	HFP			= 8'd120;
// localparam	VSP			= 8'd2;
// localparam	VBP			= 8'd20;
// localparam	VFP			= 8'd20;

localparam HACT     = 1920;
localparam HFP      = 88;
localparam HSP      = 44;
localparam HBP      = 148;

localparam VACT     = 1080;
localparam VFP      = 4;
localparam VSP      = 5;
localparam VBP      = 36;
//===============================================================================
//signal
//===============================================================================
   
wire                              app_sr_active;
wire                              app_ref_ack;
wire                              app_zq_ack;
wire                              cal_done;

// Slave Interface Write Address Ports
wire [AXI_ID_WIDTH-1:0]           s_axi_awid;
wire [AXI_ADDR_WIDTH-1:0]         s_axi_awaddr;
wire [7:0]                        s_axi_awlen;
wire [2:0]                        s_axi_awsize;
wire [1:0]                        s_axi_awburst;
wire [0:0]                        s_axi_awlock;
wire [3:0]                        s_axi_awcache;
wire [2:0]                        s_axi_awprot;
wire                              s_axi_awvalid;
wire                              s_axi_awready;
// Slave Interface Write Data Ports
wire [AXI_DATA_WIDTH-1:0]         s_axi_wdata;
wire [(AXI_DATA_WIDTH/8)-1:0]     s_axi_wstrb;
wire                              s_axi_wlast;
wire                              s_axi_wvalid;
wire                              s_axi_wready;
// Slave Interface Write Response Ports
wire                              s_axi_bready;
wire [AXI_ID_WIDTH-1:0]           s_axi_bid;
wire [1:0]                        s_axi_bresp;
wire                              s_axi_bvalid;
// Slave Interface Read Address Ports
wire [AXI_ID_WIDTH-1:0]           s_axi_arid;
wire [AXI_ADDR_WIDTH-1:0]         s_axi_araddr;
wire [7:0]                        s_axi_arlen;
wire [2:0]                        s_axi_arsize;
wire [1:0]                        s_axi_arburst;
wire [0:0]                        s_axi_arlock;
wire [3:0]                        s_axi_arcache;
wire [2:0]                        s_axi_arprot;
wire                              s_axi_arvalid;
wire                              s_axi_arready;
// Slave Interface Read Data Ports
wire                              s_axi_rready;
wire [AXI_ID_WIDTH-1:0]           s_axi_rid;
wire [AXI_DATA_WIDTH-1:0]         s_axi_rdata;
wire [1:0]                        s_axi_rresp;
wire                              s_axi_rlast;
wire                              s_axi_rvalid;




wire  [AXI_ID_WIDTH-1  :0]   	m0_axi_awid      ; 
wire  [AXI_ADDR_WIDTH-1:0]   	m0_axi_awaddr    ; 
wire  [    7:0]   			      m0_axi_awlen     ; 
wire  [    2:0]   			      m0_axi_awsize    ; 
wire  [    1:0]   			      m0_axi_awburst   ; 
wire  [    1:0]   			      m0_axi_awlock    ; 
wire              			      m0_axi_awvalid   ; 
wire              			      m0_axi_awready   ; 
wire  [AXI_ID_WIDTH-1  :0]   	m0_axi_arid      ; 
wire  [AXI_ADDR_WIDTH-1:0]    m0_axi_araddr    ; 
wire  [    7:0]   			      m0_axi_arlen     ; 
wire  [    2:0]   			      m0_axi_arsize    ; 
wire  [    1:0]   			      m0_axi_arburst   ; 
wire  [    1:0]   			      m0_axi_arlock    ; 
wire              			      m0_axi_arvalid   ; 
wire              			      m0_axi_arready   ; 
wire  [AXI_ID_WIDTH-1:0]   	  m0_axi_wid       ; 
wire  [(AXI_DATA_WIDTH/8)-1:0]   m0_axi_wstrb     ; 
wire              			      m0_axi_wlast     ; 
wire              			    m0_axi_wvalid    ; 
wire  [AXI_DATA_WIDTH-1:0]   	m0_axi_wdata     ; 
wire              			    m0_axi_wready    ; 
wire  [AXI_ID_WIDTH-1:0]   	m0_axi_bid       ; 
wire              			    m0_axi_bvalid    ; 
wire              			    m0_axi_bready    ; 
wire              			    m0_axi_rready    ; 
wire  [AXI_ID_WIDTH-1:0]   	m0_axi_rid       ; 
wire  [    1:0]   			    m0_axi_rresp     ; 
wire              			    m0_axi_rlast     ; 
wire              			    m0_axi_rvalid    ; 
wire  [AXI_DATA_WIDTH-1:0]   	m0_axi_rdata     ; 
///////////// AXI MASTER 1   
wire  [AXI_ID_WIDTH-1:0]   	m1_axi_awid      ; 
wire  [AXI_ADDR_WIDTH-1:0]   m1_axi_awaddr    ; 
wire  [    7:0]   			    m1_axi_awlen     ; 
wire  [    2:0]   			    m1_axi_awsize    ; 
wire  [    1:0]   			    m1_axi_awburst   ; 
wire  [    1:0]   			    m1_axi_awlock    ; 
wire              			    m1_axi_awvalid   ; 
wire              			    m1_axi_awready   ; 
wire  [AXI_ID_WIDTH-1:0]   	m1_axi_arid      ; 
wire  [AXI_ADDR_WIDTH-1:0]   m1_axi_araddr    ; 
wire  [    7:0]   			    m1_axi_arlen     ; 
wire  [    2:0]   			    m1_axi_arsize    ; 
wire  [    1:0]   			    m1_axi_arburst   ; 
wire  [    1:0]   			    m1_axi_arlock    ; 
wire              			    m1_axi_arvalid   ; 
wire              			    m1_axi_arready   ; 
wire  [AXI_ID_WIDTH-1:0]   	m1_axi_wid       ; 
wire  [(AXI_DATA_WIDTH/8)-1:0]   m1_axi_wstrb     ; 
wire              			    m1_axi_wlast     ; 
wire              			    m1_axi_wvalid    ; 
wire  [AXI_DATA_WIDTH-1:0]   	m1_axi_wdata     ; 
wire              			    m1_axi_wready    ; 
wire  [AXI_ID_WIDTH-1:0]   	m1_axi_bid       ; 
wire              			    m1_axi_bvalid    ; 
wire              			    m1_axi_bready    ;  
wire              			    m1_axi_rready    ; 
wire  [AXI_ID_WIDTH-1:0]   	m1_axi_rid       ; 
wire  [    1:0]   			    m1_axi_rresp     ; 
wire              			    m1_axi_rlast     ; 
wire              			    m1_axi_rvalid    ; 
wire  [AXI_DATA_WIDTH-1:0]   	m1_axi_rdata     ;   

////////////////////////////////////////////////////////////////
// System & Debugger
wire    w_arstn;
// wire	w_sysclk_mcu_arstn;
// wire	w_sysclk_mcu_arst;
wire	w_mipi_rx_pclk_arstn;
wire	w_mipi_rx_pclk_arst;

wire		       w_mipi_rx_vs;
wire		       w_mipi_rx_hs;
wire	       w_mipi_rx_de;
wire	[63:0]			w_mipi_rx_data	;

wire					io_systemReset;



//===================================================================================================
//reset module
//===================================================================================================

assign w_arstn  		       = MIPI_TX_PLL_LOCKED & DDR3_PLL_LOCKED & USER_PLL_LOCKED;
assign MIPI_TX_PLL_RSTN  		= key[0];
assign USER_PLL_RSTN      		= key[0];
assign mipi_dsi_tx_pll_RSTN 	= key[0];
assign DDR3_PLL_RSTN 		= key[0];
assign GE_PLL_RSTN = key[0];
reset_ctrl
#(
	.NUM_RST		(2),
	.CYCLE			(1),
	.IN_RST_ACTIVE	(4'b00),
	.OUT_RST_ACTIVE	(4'b10)
)
inst_reset_ctrl
(
	.i_arst		({2{w_arstn}}),//({{4{MIPI_TX_PLL_LOCKED}},                  {2{key[0]}}}),
	.i_clk			({2{i_mipi_rx_pclk}}),
	.o_srst		({w_mipi_rx_pclk_arst, w_mipi_rx_pclk_arstn})
);



reg [25:0] cnt = 'd0;
always @( posedge core_clk)
begin 
       cnt <= cnt + 1'b1;
end
assign led[0]  = cal_done ? cnt[24] : 1'b0;

//========================================================================================================
//MIPI RX
//========================================================================================================
wire i_mipi_clk ;
assign i_mipi_clk = core_clk;

		assign	cam_d0_RST		= 1'b0;
		assign	cam_d1_RST		= 1'b0;
		assign  cam_d2_RST = 1'b0;
    assign  cam_d3_RST = 1'b0;
	
wire [15:0] mipi_debug_out;
		

		csi_rx_controller inst_efx_csi2_rx
		(
              .reset_n			(key[0]),
              .clk				(i_mipi_clk),
              .reset_byte_HS_n	(key[0]),
              .clk_byte_HS		  (i_cam_ck_CLKOUT),
              .reset_pixel_n		(w_mipi_rx_pclk_arstn),
              .clk_pixel			  (i_mipi_rx_pclk),
              
              .Rx_LP_CLK_P		  (i_cam_ck_LP_P_IN),
              .Rx_LP_CLK_N		  (i_cam_ck_LP_N_IN),
              .Rx_HS_enable_C		(o_cam_ck_HS_ENA),
              .LVDS_termen_C		(o_cam_ck_HS_TERM),
              
              .Rx_LP_D_P			({cam_d3_LP_P_IN, cam_d2_LP_P_IN, cam_d1_LP_P_IN, cam_d0_LP_P_IN}),//(r_mipi_rx_data_LP_P_IN_2P),
              .Rx_LP_D_N			({cam_d3_LP_N_IN, cam_d2_LP_N_IN, cam_d1_LP_N_IN, cam_d0_LP_N_IN}),//(r_mipi_rx_data_LP_N_IN_2P),
              .Rx_HS_D_0			(cam_d0_HS_IN),//(r_mipi_rx_data_HS_IN_2P[0*8+:8]),
              .Rx_HS_D_1			(cam_d1_HS_IN),//(r_mipi_rx_data_HS_IN_2P[1*8+:8]),
              .Rx_HS_D_2			(cam_d2_HS_IN),
              .Rx_HS_D_3			(cam_d3_HS_IN),
              .Rx_HS_D_4			(),
              .Rx_HS_D_5			(),
              .Rx_HS_D_6			(),
              .Rx_HS_D_7			(),
              .Rx_HS_enable_D		({cam_d3_HS_ENA    ,cam_d2_HS_ENA    ,cam_d1_HS_ENA    ,cam_d0_HS_ENA    }),//( w_cam_d_HS_ENA),
              .LVDS_termen_D		({cam_d3_HS_TERM   ,cam_d2_HS_TERM   ,cam_d1_HS_TERM   ,cam_d0_HS_TERM   }),
              .fifo_rd_enable		({cam_d3_FIFO_RD   ,cam_d2_FIFO_RD   ,cam_d1_FIFO_RD   ,cam_d0_FIFO_RD   }),
              .fifo_rd_empty		({cam_d3_FIFO_EMPTY,cam_d2_FIFO_EMPTY,cam_d1_FIFO_EMPTY,cam_d0_FIFO_EMPTY}),
              .DLY_enable_D		       (),
              .DLY_inc_D			(),
              .u_dly_enable_D		(),
              .u_dly_inc_D		       (),
              
              .axi_clk			(1'b0),
              .axi_reset_n		       (1'b0),
              .axi_awaddr			(6'b0),
              .axi_awvalid		       (1'b0),
              .axi_awready		       (),
              .axi_wdata			(32'b0),
              .axi_wvalid			(1'b0),
              .axi_wready			(),
              
              .axi_bvalid			(),
              .axi_bready			(1'b0),
              .axi_araddr			(6'b0),
              .axi_arvalid		       (1'b0),
              .axi_arready		       (),
              .axi_rdata			(),
              .axi_rvalid			(),
              .axi_rready			(1'b1),
              
              .hsync_vc0			(w_mipi_rx_hs),
              .hsync_vc1			(),
              .hsync_vc2			(),
              .hsync_vc3			(),
              .vsync_vc0			(w_mipi_rx_vs),
              .vsync_vc1			(),
              .vsync_vc2			(),
              .vsync_vc3			(),
              .vc				(),
              .word_count			(),
              .shortpkt_data_field        (),
              .datatype			(),
              .pixel_per_clk		(),
              .pixel_data			(w_mipi_rx_data),
              .pixel_data_valid	       (w_mipi_rx_de),
              .irq				(),
              .mipi_debug_out(mipi_debug_out)
		);

//     wire		       w1_mipi_rx_vs;
// wire		       w1_mipi_rx_hs;
// wire	       w1_mipi_rx_de;
// wire	[39:0]			w1_mipi_rx_data	;
// sensor_clipper  sensor_clipper_inst (
//     .clk(i_mipi_rx_pclk),
//     .i_vs(w_mipi_rx_vs),
//     .i_hs(w_mipi_rx_hs),
//     .i_de(w_mipi_rx_de),
//     .i_dat(w_mipi_rx_data[39:0]),

//     .o_hs(w1_mipi_rx_hs),
//     .o_vs(w1_mipi_rx_vs),
//     .o_de(w1_mipi_rx_de),
//     .o_dat(w1_mipi_rx_data)
   
//   );


wire mdebug_pixel_fifo_full     = mipi_debug_out[0] ;
wire mdebug_pixel_fifo_empty    = mipi_debug_out[1] ;
wire mdebug_crc_error           = mipi_debug_out[2] ;
wire mdebug_ecc_1bit_error      = mipi_debug_out[3] ;
wire mdebug_ecc_2bit_error      = mipi_debug_out[4] ;
wire mdebug_undersize_pkt_error = mipi_debug_out[5] ;
wire mdebug_line_vc0_error      = mipi_debug_out[6] ;
wire mdebug_frame_vc0_error    = mipi_debug_out[10];   
wire mdebug_receive_error      = mipi_debug_out[14];


//========================================================================================================
//
//========================================================================================================
		

//*************** imx219 config********************/
// mipi_config_imx219_top u_config_imx219(
// 										.i_sys_clk(CLK_5M)    	,    /////48M 
// 										.sys_rstn(vid_rst_n )    ,
// 										.o_sen_rst_n(o_cam_rstn)  	,
										
										// .o_iic_sda_OE(io_cam_sda_OE) ,
										// .i_iic_sda(io_cam_sda_IN)   	,
										// .o_iic_sda(io_cam_sda_OUT)   	,
										// .o_iic_scl(io_cam_scl)    	
										// ); 	

wire scl_padoen_o;
wire sda_padoen_o;


reg [12:0] i2c_rst_cnt = '0;

always @( posedge CLK_5M or negedge w_arstn )
begin
    if( !w_arstn )
       i2c_rst_cnt <= 'd0;
    else 
       i2c_rst_cnt <= i2c_rst_cnt[12] ? i2c_rst_cnt : i2c_rst_cnt + 1'b1;
end
wire i2c_rst_n = i2c_rst_cnt[12];

wire [255:0]sensor_status,net_sensor_status;wire sensor_toggle;
sensor_status_cdc sensor_mailbox(.source_clk(CLK_5M),.source_rst_n(i2c_rst_n),.source_status(sensor_status),.source_toggle(sensor_toggle),
 .dest_clk(rxc),.dest_rst_n(GE_PLL_LOCKED),.dest_status(net_sensor_status));
i2c_master_ctrl_top u2_i2c_master_ctrl_top(
  /*i*/.clk			(CLK_5M		),.sensor_status(sensor_status),.sensor_toggle(sensor_toggle),
  /*i*/.rst_n			(i2c_rst_n		),
  /*i*/.scl_pad_i     (io_cam_scl_IN),//(1'b1),
  /*o*/.scl_pad_o     (io_cam_scl_OUT),
  /*o*/.scl_padoen_o  (scl_padoen_o),
  /*i*/.sda_pad_i     (io_cam_sda_IN),
  /*o*/.sda_pad_o     (io_cam_sda_OUT),
  /*o*/.sda_padoen_o  (sda_padoen_o)
  
  );
assign o_cam_rst_p = ~w_arstn;
assign io_cam_scl_OE = ~scl_padoen_o;
assign io_cam_sda_OE = ~sda_padoen_o;

//=====================================================================================
//frame buffer
//=====================================================================================
wire [7:0] 	ch0_r;
wire [7:0]    ch0_g;
wire [7:0]    ch0_b;
wire ch0_vs;
wire ch0_hs;
wire ch0_de;
wire hdmi_fifo_underflow;
reg [31:0] hdmi_underflow_count=0,hdmi_frame_count=0;
reg hdmi_period_previous=0;
always @(posedge vid_clk_dvi2 or negedge vid_rst_n)begin
 if(!vid_rst_n)begin hdmi_underflow_count<=0;hdmi_frame_count<=0;hdmi_period_previous<=0;end
 else begin
  hdmi_period_previous<=fifo_rd_period;
  if(hdmi_fifo_underflow)hdmi_underflow_count<=hdmi_underflow_count+1'b1;
  if(fifo_rd_period&&!hdmi_period_previous)hdmi_frame_count<=hdmi_frame_count+1'b1;
 end
end
// Each counter increments by one in its source domain. Cross Gray codes.
wire[31:0]hdmi_underflow_gray=hdmi_underflow_count^(hdmi_underflow_count>>1);
wire[31:0]hdmi_frame_gray=hdmi_frame_count^(hdmi_frame_count>>1);
reg[63:0]hdmi_status_meta=0,hdmi_status_sync=0;
always @(posedge rxc or negedge GE_PLL_LOCKED)begin
 if(!GE_PLL_LOCKED)begin hdmi_status_meta<=0;hdmi_status_sync<=0;end
 else begin hdmi_status_meta<={hdmi_underflow_gray,hdmi_frame_gray};hdmi_status_sync<=hdmi_status_meta;end
end

wire  [16-1:0] fb0_m_axis_tdata;
wire           fb0_m_axis_tvalid;
wire           fb0_m_axis_tready;
wire           fb0_m_axis_tlast;
wire           fb0_m_axis_tuser;

wire  [16-1:0] fb1_m_axis_tdata;
wire           fb1_m_axis_tvalid;
wire           fb1_m_axis_tready;
wire           fb1_m_axis_tlast;
wire           fb1_m_axis_tuser;
wire  fifo_rd_period;
reg mipi_rx_vs_r = 'd0;
// Live mode owns capture; keys no longer trigger individual frames.
wire vs;
reg [1:0] net_start_video = 2'b00;
reg [5:0] net_start_delay = 6'd63;
always @(posedge vid_clk_dvi2 or negedge GE_PLL_LOCKED) begin
    if(!GE_PLL_LOCKED) begin net_start_video<=0; net_start_delay<=63; end
    else begin
        net_start_video <= {net_start_video[0],vs};
        if(!net_start_video[1]) net_start_delay<=63;
        else if(net_start_delay!=0) net_start_delay<=net_start_delay-1'b1;
    end
end
wire net_frame_read = net_start_video[1] && net_start_delay==0;


key_detect # (
    .CLK_FREQUENCY_MHz(50)
  )
  key1_detect_inst (
    .i_key(key[1]),
    .clk(i_mipi_rx_pclk),
    .rst_n(w_arstn),
    .key_sw_en(sw)
  );

always @( posedge i_mipi_rx_pclk )
begin
    mipi_rx_vs_r <= w_mipi_rx_vs;
end

wire pos_mipi_rx_vs = {mipi_rx_vs_r,w_mipi_rx_vs} == 2'b01;
// Count committed image beats and outstanding write responses in AXI domain.
reg [17:0] live_write_beats = 0;
wire live_write_toggle;
reg [15:0] live_write_pending = 0;
wire live_writer_idle = live_write_pending==0 && !m0_axi_awvalid && !m0_axi_wvalid;
always @(posedge core_clk or negedge vid_rst_n) begin
    if(!vid_rst_n) begin live_write_beats<=0; live_write_pending<=0; end
    else begin
        if(m0_axi_wvalid && m0_axi_wready) begin
            if(live_write_beats==129599) begin live_write_beats<=0; end
            else live_write_beats<=live_write_beats+1'b1;
        end
        case({m0_axi_awvalid && m0_axi_awready,m0_axi_bvalid && m0_axi_bready})
          2'b10:live_write_pending<=live_write_pending+1'b1;
          2'b01:live_write_pending<=live_write_pending-1'b1;
          default:live_write_pending<=live_write_pending;
        endcase
    end
end
ge_write_commit #(.ADDR_WIDTH(AXI_ADDR_WIDTH)) physical_write_commit(
 .clk(core_clk),.rst_n(vid_rst_n),.awaddr(m0_axi_awaddr),.awlen(m0_axi_awlen),
 .awvalid(m0_axi_awvalid),.awready(m0_axi_awready),.wvalid(m0_axi_wvalid),
 .wready(m0_axi_wready),.wlast(m0_axi_wlast),.done_toggle(live_write_toggle));
reg [1:0] live_written_sync=0, live_idle_sync=0, live_sender_sync=0, live_reader_sync=0;
wire live_read_done, capture_en, live_send_toggle, live_fault;
// R23: two 2-MiB DDR slots. A RAW frame occupies 129600*16 bytes.
wire frame_capture_ready,frame_publish,frame_display_ready;
wire [AXI_ADDR_WIDTH-1:0] snapshot_write_base,snapshot_read_base,snapshot_network_base,hdmi_active_base;
reg [5:0] hdmi_reads_pending=0;
wire hdmi_reads_idle=(hdmi_reads_pending==0)&&!m0_axi_arvalid;
// Protect the active frame, accepted read response and an offered AR.
// The physical DDR reader allows one outstanding burst per master.
reg[3:0]hdmi_reads_mask=0;
wire[3:0]hdmi_read_protected=hdmi_reads_mask|(4'b1<<hdmi_active_base[22:21])|
 (m0_axi_arvalid?(4'b1<<m0_axi_araddr[22:21]):4'b0);
always @(posedge core_clk or negedge vid_rst_n)begin
 if(!vid_rst_n)hdmi_reads_mask<=0;
 else if(m0_axi_arvalid&&m0_axi_arready)hdmi_reads_mask<=4'b1<<m0_axi_araddr[22:21];
 else if(m0_axi_rvalid&&m0_axi_rready&&m0_axi_rlast)hdmi_reads_mask<=0;
end
wire video_network_reserved;
reg[19:0]physical_write_collisions=0;
always @(posedge core_clk or negedge vid_rst_n)begin
 if(!vid_rst_n)physical_write_collisions<=0;
 else if(m0_axi_awvalid&&m0_axi_awready&&physical_write_collisions!=20'hfffff&&
  ((hdmi_read_protected>>m0_axi_awaddr[22:21]&1'b1)||
   (video_network_reserved&&m0_axi_awaddr[22:21]==snapshot_network_base[22:21])||
   m0_axi_awaddr[22:21]!=snapshot_write_base[22:21]))
  physical_write_collisions<=physical_write_collisions+1'b1;
end

wire[31:0]video_published_count,video_network_count;
wire[63:0]video_count_gray={video_published_count^(video_published_count>>1),video_network_count^(video_network_count>>1)};
reg[63:0]video_count_meta=0,video_count_sync=0;
always @(posedge rxc or negedge GE_PLL_LOCKED)begin
 if(!GE_PLL_LOCKED)begin video_count_meta<=0;video_count_sync<=0;end
 else begin video_count_meta<=video_count_gray;video_count_sync<=video_count_meta;end
end

always @(posedge core_clk or negedge vid_rst_n) begin
 if(!vid_rst_n)hdmi_reads_pending<=0;
 else case({m0_axi_arvalid&&m0_axi_arready,m0_axi_rvalid&&m0_axi_rready&&m0_axi_rlast})
  2'b10:hdmi_reads_pending<=hdmi_reads_pending+1'b1;
  2'b01:hdmi_reads_pending<=hdmi_reads_pending-1'b1;
  default:hdmi_reads_pending<=hdmi_reads_pending;
 endcase
end

wire live_reset_n = w_arstn && vid_rst_n && GE_PLL_LOCKED;
always @(posedge i_mipi_rx_pclk or negedge live_reset_n) begin
    if(!live_reset_n) begin
        live_written_sync<=0; live_idle_sync<=0; live_sender_sync<=0; live_reader_sync<=0;
    end else begin
        live_written_sync<={live_written_sync[0],live_write_toggle};
        live_idle_sync<={live_idle_sync[0],live_writer_idle};
        live_sender_sync<={live_sender_sync[0],vs};
        live_reader_sync<={live_reader_sync[0],live_read_done};
    end
end
wire [2:0] live_state_debug, live_fault_stage;
wire [63:0] mac_debug_status;
wire [1:0] live_writes_debug;
assign led[3:1]=live_state_debug;
assign led[5:4]=live_writes_debug;
assign led[6]=live_idle_sync[1];
assign led[7]=live_write_toggle;
ge_video_engine #(.ADDR_WIDTH(AXI_ADDR_WIDTH)) video_engine(
 .capture_clk(i_mipi_rx_pclk),.axi_clk(core_clk),.rst_n(live_reset_n),
 .frame_start(pos_mipi_rx_vs),.write_done_toggle(live_written_sync[1]),.writer_idle(live_idle_sync[1]),
 .sender_busy(vs),.reader_done(live_read_done),.hdmi_read_bank(hdmi_active_base[22:21]),.hdmi_protected(hdmi_read_protected),
 .capture_en(capture_en),.frame_publish(frame_publish),.capture_ready(frame_capture_ready),.send_toggle(live_send_toggle),
 .fault(live_fault),.fault_stage(live_fault_stage),.debug_state(live_state_debug),.debug_writes(live_writes_debug),
 .write_base(snapshot_write_base),.published_base(snapshot_read_base),.network_base(snapshot_network_base),
 .display_ready(frame_display_ready),.network_reserved(video_network_reserved),
 .published_count(video_published_count),.network_count(video_network_count));
reg [2:0] live_send_sync=0;
always @(posedge rxc or negedge GE_PLL_LOCKED) begin
    if(!GE_PLL_LOCKED) live_send_sync<=0;
    else live_send_sync<={live_send_sync[1:0],live_send_toggle};
end
wire live_send_pulse = live_send_sync[2] ^ live_send_sync[1];
// IMX219
  frame_buffer #(
.HDMI_CLEAN_STREAM(1),
.EXTERNAL_FRAME_BASE(1),
.I_VID_WIDTH         (32),
.O_VID_WIDTH         (16),
.START_ADDR          (32'h00000        ),
.AXI_DATA_WIDTH      ( AXI_DATA_WIDTH	),
.AXI_ADDR_WIDTH      ( AXI_ADDR_WIDTH	),
.WR_FIFO_DEPTH	      ( 1024		),    
.RD_FIFO_DEPTH 	      ( 1024 	),
.BURST_LEN  	        (127),
.GATE_WRITES (1),
.FB_NUM	              (1),
.MAX_VID_WIDTH	      (960) ,
.MAX_VID_HIGHT	      (1080),
.O_FRAME_WIDTH      (960),
.O_FRAME_HEIGHT     (1080)

)checker0(
       .external_write_base(snapshot_write_base),.external_read_base(snapshot_read_base),.active_read_base(hdmi_active_base),
       .capture_write_en(capture_en),
       .axi_clk		(core_clk 	        ),
       .rst_n			(vid_rst_n   ),

/*i*/.i_clk			(i_mipi_rx_pclk      ),
/*i*/.i_vs			(w_mipi_rx_vs),
/*i*/.i_de			(w_mipi_rx_de & w_mipi_rx_hs),
/*i*/.vin 			({w_mipi_rx_data[19:12],w_mipi_rx_data[9:2],w_mipi_rx_data[39:32],w_mipi_rx_data[29:22]}	),
                     
/*i*/.o_clk			(vid_clk_dvi2),//(i_mipi_rx_pclk	),                  
/*i*/.fifo_rd_period(fifo_rd_period),//(fifo_rd_period  ),

    .m_axis_tdata  (fb0_m_axis_tdata),
    .m_axis_tvalid (fb0_m_axis_tvalid),
    .m_axis_tready (fb0_m_axis_tready),
    .m_axis_tuser  (fb0_m_axis_tuser),
    .m_axis_tlast  (fb0_m_axis_tlast),
	

       .awid			(m0_axi_awid	  ),      
       .awaddr		(m0_axi_awaddr	),
       .awlen			(m0_axi_awlen	  ),
       .awsize		(m0_axi_awsize	),
       .awburst		(m0_axi_awburst ),
       .awprot    (m0_axi_awprot  ),
       .awcache   (m0_axi_awcache ),
       .awlock		(m0_axi_awlock	),
       .awvalid		(m0_axi_awvalid ),
       .awready		(m0_axi_awready ),

       .arid			(m0_axi_arid	  ),
       .araddr		(m0_axi_araddr	),
       .arlen			(m0_axi_arlen	  ),
       .arsize		(m0_axi_arsize	),
       .arburst 	(m0_axi_arburst ),

       .arprot    (m0_axi_arprot  ),
       .arcache   (m0_axi_arcache ),
       .arlock 		(m0_axi_arlock	),
       .arvalid		(m0_axi_arvalid ),
       .arready		(m0_axi_arready ),

       .wdata			(m0_axi_wdata	  ),
       .wstrb			(m0_axi_wstrb	  ),
       .wlast			(m0_axi_wlast	  ),
       .wvalid		(m0_axi_wvalid	),
       .wready		(m0_axi_wready	),
       .rid			  (m0_axi_rid	    ),
       .rdata			(m0_axi_rdata	  ),
       .rlast			(m0_axi_rlast	  ),
       .rvalid 		(m0_axi_rvalid	),
       .rready		(m0_axi_rready	),
       .rresp			(m0_axi_rresp	  ),
       .bid			  (m0_axi_bid	    ),
       .bvalid		(m0_axi_bvalid	),
       .bready	  (m0_axi_bready	)
);

		    
		    
cvo_axi # (
    .SYMBOL_WIDTH(8),
    .SYMBOL_NUM(1),
    .PIXEL_NUM(2),
    .HSYNC_POL(1),
    .VSYNC_POL(1),
    .FIFO_DEPTH(1024),
    .FIFO_ALMOST_FULL(1000),
    .MAX_H_VALID(1920),
    .MAX_V_VALID(1080)
  )
  cvo_axi_inst (
    .o_clk          (vid_clk_dvi2   ),
    .rst_n          (vid_rst_n      ),
    .fifo_rd_period (fifo_rd_period ),
    .fifo_rd_underflow(hdmi_fifo_underflow),
    .s_axi_clk      (vid_clk_dvi2   ),
    .s_axis_tdata   (fb0_m_axis_tdata   ),
    .s_axis_tvalid  (fb0_m_axis_tvalid  ),
    .s_axis_tready  (fb0_m_axis_tready  ),
    .s_axis_tlast   (fb0_m_axis_tlast   ),
    .s_axis_tuser   (fb0_m_axis_tuser   ),
    .H_FRONT_PORCH  (HFP            ),
    .H_SYNC         (HSP            ),
    .H_VALID        (HACT           ),
    .H_BACK_PORCH   (HBP            ),
    .V_FRONT_PORCH  (VFP            ),
    .V_SYNC         (VSP            ),
    .V_VALID        (VACT           ),
    .V_BACK_PORCH   (VBP            ),
     .vout          ({ch0_g,ch0_b}  ),
    .o_hs           (ch0_hs         ),
    .o_vs           (ch0_vs         ),
    .o_de           (ch0_de         )
  );		       

   frame_buffer #(
.RESET_READ_STREAM(1),
.EXTERNAL_FRAME_BASE(1),
.I_VID_WIDTH         (32),
.O_VID_WIDTH         (16),
.START_ADDR          (32'h00000        ),
.AXI_DATA_WIDTH      ( AXI_DATA_WIDTH	),
.AXI_ADDR_WIDTH      ( AXI_ADDR_WIDTH	),
.WR_FIFO_DEPTH	      ( 1024		),    
.RD_FIFO_DEPTH 	      ( 1024 	),
.BURST_LEN  	        (127),
.FB_NUM	              (1),
.MAX_VID_WIDTH	      (960) ,
.MAX_VID_HIGHT	      (1080),
.O_FRAME_WIDTH      (960),
.O_FRAME_HEIGHT     (1080)

   )frame_buffer2(
       .external_write_base(snapshot_write_base),.external_read_base(snapshot_network_base),.active_read_base(),
       .axi_clk		(core_clk 	        ),
       .rst_n			(vid_rst_n   ),

/*i*/.i_clk			(i_mipi_rx_pclk      ),
/*i*/.i_vs			(w_mipi_rx_vs	& 1'b0),
/*i*/.i_de			(w_mipi_rx_de & w_mipi_rx_hs	& 1'b0),
/*i*/.vin 			({w_mipi_rx_data[19:12],w_mipi_rx_data[9:2],w_mipi_rx_data[39:32],w_mipi_rx_data[29:22]}	),
                     
/*i*/.o_clk			(vid_clk_dvi2),//(i_mipi_rx_pclk	),                  
/*i*/.fifo_rd_period(net_frame_read),

    .m_axis_tdata  (fb1_m_axis_tdata),
    .m_axis_tvalid (fb1_m_axis_tvalid),
    .m_axis_tready (fb1_m_axis_tready),
    .m_axis_tuser  (fb1_m_axis_tuser),
    .m_axis_tlast  (fb1_m_axis_tlast),
	

       .awid			(m1_axi_awid	  ),      
       .awaddr		(m1_axi_awaddr	),
       .awlen			(m1_axi_awlen	  ),
       .awsize		(m1_axi_awsize	),
       .awburst		(m1_axi_awburst ),
       .awprot    (m1_axi_awprot  ),
       .awcache   (m1_axi_awcache ),
       .awlock		(m1_axi_awlock	),
       .awvalid		(m1_axi_awvalid ),
       .awready		(m1_axi_awready ),
       .arid			(m1_axi_arid	  ),
       .araddr		(m1_axi_araddr	),
       .arlen			(m1_axi_arlen	  ),
       .arsize		(m1_axi_arsize	),
       .arburst 	(m1_axi_arburst ),
       .arprot    (m1_axi_arprot  ),
       .arcache   (m1_axi_arcache ),
       .arlock 		(m1_axi_arlock	),
       .arvalid		(m1_axi_arvalid ),
       .arready		(m1_axi_arready ),
       .wdata			(m1_axi_wdata	  ),
       .wstrb			(m1_axi_wstrb	  ),
       .wlast			(m1_axi_wlast	  ),
       .wvalid		(m1_axi_wvalid	),
       .wready		(m1_axi_wready	),
       .rid			  (m1_axi_rid	    ),
       .rdata			(m1_axi_rdata	  ),
       .rlast			(m1_axi_rlast	  ),
       .rvalid 		(m1_axi_rvalid	),
       .rready		(m1_axi_rready	),
       .rresp			(m1_axi_rresp	  ),
       .bid			  (m1_axi_bid	    ),
       .bvalid		(m1_axi_bvalid	),
       .bready	  (m1_axi_bready	)
);

    
//========================================================================= 
//interconnect
//========================================================================= 
axi_interconnect wr_interconnect
(
    .rst_n          (vid_rst_n),//(w_sys_rst_n   ),
    .clk            (core_clk   ),
    .s_axi_awid     ({m3_axi_awid      ,m2_axi_awid      ,m1_axi_awid      , m0_axi_awid  }),//8'd128
    .s_axi_awaddr   ({m3_axi_awaddr    ,m2_axi_awaddr    ,m1_axi_awaddr    , m0_axi_awaddr }),
    .s_axi_awlen    ({m3_axi_awlen     ,m2_axi_awlen     ,m1_axi_awlen     , m0_axi_awlen  }),
    .s_axi_awsize   ({m3_axi_awsize    ,m2_axi_awsize    ,m1_axi_awsize    , m0_axi_awsize }),
    .s_axi_awburst  ({m3_axi_awburst   ,m2_axi_awburst   ,m1_axi_awburst   , m0_axi_awburst}),
    .s_axi_awlock   ({m3_axi_awlock    ,m2_axi_awlock    ,m1_axi_awlock    , m0_axi_awlock }),
    .s_axi_awvalid  ({m3_axi_awvalid   ,m2_axi_awvalid   ,m1_axi_awvalid   , m0_axi_awvalid}),
    .s_axi_awready  ({m3_axi_awready   ,m2_axi_awready   ,m1_axi_awready   , m0_axi_awready}),
    .s_axi_wid      ({m3_axi_wid       ,m2_axi_wid       ,m1_axi_wid       , m0_axi_wid    }),// 8'd128 
    .s_axi_wdata    ({m3_axi_wdata     ,m2_axi_wdata     ,m1_axi_wdata     , m0_axi_wdata  }),
    .s_axi_wlast    ({m3_axi_wlast     ,m2_axi_wlast     ,m1_axi_wlast     , m0_axi_wlast  }),
    .s_axi_wstrb    ({m3_axi_wstrb     ,m2_axi_wstrb     ,m1_axi_wstrb     , m0_axi_wstrb  }),
    .s_axi_wvalid   ({m3_axi_wvalid    ,m2_axi_wvalid    ,m1_axi_wvalid    , m0_axi_wvalid }),
    .s_axi_wready   ({m3_axi_wready    ,m2_axi_wready    ,m1_axi_wready    , m0_axi_wready }),
    .s_axi_bid      ({m3_axi_bid       ,m2_axi_bid       ,m1_axi_bid       , m0_axi_bid    }),
    .s_axi_bvalid   ({m3_axi_bvalid    ,m2_axi_bvalid    ,m1_axi_bvalid    , m0_axi_bvalid }),
    .s_axi_bready   ({m3_axi_bready    ,m2_axi_bready    ,m1_axi_bready    , m0_axi_bready }),

    .m_axi_awid     ( s_axi_awid ),
    .m_axi_awaddr   ( s_axi_awaddr ),
    .m_axi_awlen    ( s_axi_awlen ),
    .m_axi_awsize   ( s_axi_awsize ),
    .m_axi_awlock   ( s_axi_awlock ),
    .m_axi_awvalid  ( s_axi_awvalid ),
    .m_axi_awready  ( s_axi_awready ),
    .m_axi_awburst  ( s_axi_awburst ),
    .m_axi_awcache  (  ),
    .m_axi_awqos    (  ),
    .m_axi_awuser   (  ),
    .m_axi_awprot   (  ),
    .m_axi_awregion (  ),
    .m_axi_wuser    (  ),
     //s_axi_wid
     //
	// .m_axi_wid		(s_axi_wid  ),
    .m_axi_wvalid   ( s_axi_wvalid ),
    .m_axi_wlast    ( s_axi_wlast ),
    .m_axi_wdata    ( s_axi_wdata ),
    .m_axi_wstrb    ( s_axi_wstrb ),
    .m_axi_wready   ( s_axi_wready ),

    .m_axi_bid      ( s_axi_bid ),
    .m_axi_bvalid   ( s_axi_bvalid ),
    .m_axi_bready   ( s_axi_bready ),
    .m_axi_bresp    (  ),
                 
    
    .m_axi_ruser    (  ),
    .m_axi_buser    (  )
   
);



axi_interconnect rd_interconnect
(
    .rst_n          (vid_rst_n  ),
    .clk            (core_clk   ),

    .s_axi_arid     ({m3_axi_arid      ,m2_axi_arid      ,m1_axi_arid      , m0_axi_arid     }),//8'd128
    .s_axi_araddr   ({m3_axi_araddr    ,m2_axi_araddr    ,m1_axi_araddr    , m0_axi_araddr }),
    .s_axi_arlen    ({m3_axi_arlen     ,m2_axi_arlen     ,m1_axi_arlen     , m0_axi_arlen  }),
    .s_axi_arsize   ({m3_axi_arsize    ,m2_axi_arsize    ,m1_axi_arsize    , m0_axi_arsize }),
    .s_axi_arburst  ({m3_axi_arburst   ,m2_axi_arburst   ,m1_axi_arburst   , m0_axi_arburst}),
    .s_axi_arlock   ({m3_axi_arlock    ,m2_axi_arlock    ,m1_axi_arlock    , m0_axi_arlock }),
    .s_axi_arvalid  ({m3_axi_arvalid   ,m2_axi_arvalid   ,m1_axi_arvalid   , m0_axi_arvalid}),
    .s_axi_arready  ({m3_axi_arready   ,m2_axi_arready   ,m1_axi_arready   , m0_axi_arready}),
    .s_axi_rid      ({m3_axi_rid       ,m2_axi_rid       ,m1_axi_rid       , m0_axi_rid    }),//
    .s_axi_rdata    ({m3_axi_rdata     ,m2_axi_rdata     ,m1_axi_rdata     , m0_axi_rdata  }),
    .s_axi_rvalid   ({m3_axi_rvalid    ,m2_axi_rvalid    ,m1_axi_rvalid    , m0_axi_rvalid }),
    .s_axi_rready   ({m3_axi_rready    ,m2_axi_rready    ,m1_axi_rready    , m0_axi_rready }),
    .s_axi_rlast    ({m3_axi_rlast     ,m2_axi_rlast     ,m1_axi_rlast     , m0_axi_rlast  }),
    .s_axi_rresp    ({m3_axi_rresp     ,m2_axi_rresp     ,m1_axi_rresp     , m0_axi_rresp  }),
                 
    .m_axi_arid     ( s_axi_arid ),
	.m_axi_araddr     ( s_axi_araddr ),
    .m_axi_arlen    ( s_axi_arlen ),
    .m_axi_arsize   ( s_axi_arsize ),
	.m_axi_arvalid    ( s_axi_arvalid ),
    .m_axi_arready  ( s_axi_arready ),
    .m_axi_arlock   ( s_axi_arlock ),
    .m_axi_arprot   (  ),
    .m_axi_arburst  ( s_axi_arburst ),
    .m_axi_arcache  (  ),
    .m_axi_arqos    (  ),
    .m_axi_aruser   (  ),
    .m_axi_arregion (  ),

    .m_axi_rid      ( s_axi_rid ),
    .m_axi_rdata    ( s_axi_rdata ),
    .m_axi_rready   ( s_axi_rready ),
    .m_axi_rresp    ( s_axi_rresp ),
    .m_axi_rvalid   ( s_axi_rvalid ),
    .m_axi_rlast    ( s_axi_rlast ),
    
    .m_axi_ruser    (  ),
    .m_axi_buser    (  )
   
);

//=========================================================================== 
//ddr3
//=========================================================================== 

ddr3_top                 u_ddr3_top
(

.axi_clk                (core_clk            ),
.core_clk               (core_clk            ),
.sdram_clk              (sdram_clk           ),  
.rx_cal_clk             (rx_cal_clk          ),
.tx_cal_clk             (tx_cal_clk          ),
.tx_cal_clk_90edge      (tx_cal_clk_90edge   ),
.rstn                   (w_arstn             ),      
.pll_shift              (pll_shift           ),
.pll_shift_sel          (pll_shift_sel       ),
.pll_shift_ena          (pll_shift_ena       ),       
///////////////DDR BUS
.ddr_ck_hi              (ddr_ck_hi           ),
.ddr_ck_lo              (ddr_ck_lo           ),
.ddr_cke                (ddr_cke             ),    
.ddr_reset_n            (ddr_reset_n         ),
.ddr_cs_n               (ddr_cs_n            ),
.ddr_ras_n              (ddr_ras_n           ),
.ddr_cas_n              (ddr_cas_n           ),
.ddr_we_n               (ddr_we_n            ),     
.ddr_addr               (ddr_addr            ),
.ddr_ba                 (ddr_ba              ),

.ddr_dqs_oe             (ddr_dqs_oe          ),
.ddr_dqs_oe_n           (ddr_dqs_oe_n        ),
.ddr_dq_oe              (ddr_dq_oe           ),
.ddr_dqs_in_hi          (ddr_dqs_in_hi       ),
.ddr_dqs_in_lo          (ddr_dqs_in_lo       ),
.ddr_dq_in_hi           (ddr_dq_in_hi        ),
.ddr_dq_in_lo           (ddr_dq_in_lo        ),

.ddr_dqs_out_hi         (ddr_dqs_out_hi      ),
.ddr_dqs_out_lo         (ddr_dqs_out_lo      ),
.ddr_dq_out_hi          (ddr_dq_out_hi       ),
.ddr_dq_out_lo          (ddr_dq_out_lo       ),

.ddr_dm_hi              (ddr_dm_hi           ),
.ddr_dm_lo              (ddr_dm_lo           ),
.ddr_odt                (ddr_odt             ),

// Application interface ports
.app_sr_req                     (1'b0),
.app_ref_req                    (1'b0),
.app_zq_req                     (1'b0),
.app_sr_active                  (app_sr_active),
.app_ref_ack                    (app_ref_ack),
.app_zq_ack                     (app_zq_ack),

// Slave Interface Write Address Ports
.s_axi_awid                     (s_axi_awid        ),
.s_axi_awaddr                   (s_axi_awaddr      ),
.s_axi_awlen                    (s_axi_awlen       ),
.s_axi_awsize                   (s_axi_awsize      ),
.s_axi_awburst                  (s_axi_awburst     ),
.s_axi_awlock                   (s_axi_awlock      ),
.s_axi_awcache                  (s_axi_awcache     ),
.s_axi_awprot                   (s_axi_awprot      ),
.s_axi_awqos                    (4'h0              ),
.s_axi_awvalid                  (s_axi_awvalid     ),
.s_axi_awready                  (s_axi_awready     ),
// Slave Interface Write Data Ports
.s_axi_wdata                    (s_axi_wdata       ),
.s_axi_wstrb                    (s_axi_wstrb       ),
.s_axi_wlast                    (s_axi_wlast       ),
.s_axi_wvalid                   (s_axi_wvalid      ),
.s_axi_wready                   (s_axi_wready      ),
// Slave Interface Write Response Ports
.s_axi_bid                      (s_axi_bid         ),
.s_axi_bresp                    (s_axi_bresp       ),
.s_axi_bvalid                   (s_axi_bvalid      ),
.s_axi_bready                   (s_axi_bready      ),
// Slave Interface Read Address Ports
.s_axi_arid                     (s_axi_arid        ),
.s_axi_araddr                   (s_axi_araddr      ),
.s_axi_arlen                    (s_axi_arlen       ),
.s_axi_arsize                   (s_axi_arsize      ),
.s_axi_arburst                  (s_axi_arburst     ),
.s_axi_arlock                   (s_axi_arlock      ),
.s_axi_arcache                  (s_axi_arcache     ),
.s_axi_arprot                   (s_axi_arprot      ),
.s_axi_arqos                    (4'h0              ),
.s_axi_arvalid                  (s_axi_arvalid     ),
.s_axi_arready                  (s_axi_arready     ),
// Slave Interface Read Data Ports
.s_axi_rid                      (s_axi_rid         ),
.s_axi_rdata                    (s_axi_rdata       ),
.s_axi_rresp                    (s_axi_rresp       ),
.s_axi_rlast                    (s_axi_rlast       ),
.s_axi_rvalid                   (s_axi_rvalid      ),
.s_axi_rready                   (s_axi_rready      ),
//DEBUG       
.wrlvl_dq_check                 (wrlvl_dq_check    ) ,
.rd_level_dqs_check             (rd_level_dqs_check) ,
.init_cur_state                 (init_cur_state    ) ,
.idelay_ld                      (idelay_ld         ) ,
.mpr_rdlvl_dly                  (mpr_rdlvl_dly     ) ,
.cal_done                       (cal_done          ) 
);

//***************************************************************************
// debayer
//***************************************************************************


wire        rgb_vs;
wire        rgb_hs;
wire        rgb_de;
wire        rgb_valid;
wire [47:0] rgb_datax2;
wire [15:0] r_gain;
wire [1:0] isp_color_bank;
wire [15:0] g_gain;
wire [15:0] b_gain;

// One word is {first, second} in the captured image. Use the same BGGR
// phase and Q8.8 white balance as the PC board color profile.
wire [127:0] hdmi_awb_status,net_awb_status;
awb_status_cdc awb_mailbox(.source_clk(vid_clk_dvi2),.source_rst_n(vid_rst_n),
 .source_status(hdmi_awb_status),.source_vs(rgb_vs),.dest_clk(rxc),.dest_rst_n(GE_PLL_LOCKED),.dest_status(net_awb_status));
// Blank uninitialized DDR only during startup; enable at a VS boundary.
reg [1:0] display_ready_sync=0;
reg display_vs_previous=0,display_frame_valid=0;
always @(posedge vid_clk_dvi2 or negedge vid_rst_n)begin
 if(!vid_rst_n)begin display_ready_sync<=0;display_vs_previous<=0;display_frame_valid<=0;end
 else begin
  display_ready_sync<={display_ready_sync[0],frame_display_ready};display_vs_previous<=ch0_vs;
  if(display_vs_previous&&!ch0_vs)display_frame_valid<=display_ready_sync[1];
 end
end

v36_color_pair u_hdmi_color(
 .color_bank(2'd3),.color_bank_applied(isp_color_bank),
 .clk(vid_clk_dvi2), .rst_n(vid_rst_n),
 .in_vs(ch0_vs), .in_hs(ch0_hs), .in_de(ch0_de),
 .raw_pair(display_frame_valid?{ch0_g,ch0_b}:16'h1010),
 .out_vs(rgb_vs), .out_hs(rgb_hs), .out_de(rgb_de), .rgb_pair(rgb_datax2),.awb_status(hdmi_awb_status)
);
assign rgb_valid=rgb_de;
reg rgb_vs_r = 'd0;
always @( posedge hdmi_tx_slow_clk )
begin
  rgb_vs_r <= rgb_vs;
end
assign pos_vs = {rgb_vs_r,rgb_vs} == 2'b01;
reg vid_cnt = 'd0;
reg [7:0] hdmi_tx_rdata ;
reg [7:0] hdmi_tx_gdata ;
reg [7:0] hdmi_tx_bdata ;
reg hdmi_tx_vs;
reg hdmi_tx_hs;
reg hdmi_tx_de;
always @( posedge hdmi_tx_slow_clk )
begin
    if( pos_vs )
      vid_cnt <= 1'b1;
    else if( rgb_de )
      vid_cnt <= ~vid_cnt ;

    if( vid_cnt )
      {hdmi_tx_bdata,hdmi_tx_gdata,hdmi_tx_rdata} <= rgb_datax2[23:0];
    else 
      {hdmi_tx_bdata,hdmi_tx_gdata,hdmi_tx_rdata} <= rgb_datax2[47:24];

  hdmi_tx_vs <= rgb_vs;
  hdmi_tx_hs <= rgb_hs;
  hdmi_tx_de <= rgb_de;
end
//==============================================================================
// MIPI DSI
//==============================================================================
// signal 

reg		[25:0]	r_rst_cnt;

wire	[31:0]	w_axi_rdata;
wire			w_axi_awready;
wire			w_axi_wready;
wire			w_axi_arready;
wire			w_axi_rvalid;
wire			w_axi_bvalid;

wire	[6:0]	w_axi_awaddr;
wire			w_axi_awvalid;
wire	[31:0]	w_axi_wdata;
wire			w_axi_wvalid;
wire			w_axi_bready;
wire	[6:0]	w_axi_araddr;
wire			w_axi_arvalid;
wire			w_axi_rready;

wire			w_confdone;
assign w_confdone = 1'b1;

////////////////////////////////////////////////////////////////
always@(posedge i_mipi_clk or  negedge w_arstn )
begin
  if ( !w_arstn ) begin
    r_rst_cnt	<= 'd0;
  end else 		
    r_rst_cnt	<= r_rst_cnt[25] ? r_rst_cnt :r_rst_cnt + 1'b1;
end

wire axi_rst_n = r_rst_cnt[25];

reg [26:0] dly_cnt = 'd0;

always @( posedge vid_clk_dvi2 or negedge w_arstn )
begin
  if( !w_arstn )
    dly_cnt <= 'd0;
  else if( w_confdone )
    dly_cnt <= dly_cnt[26] ? dly_cnt :(dly_cnt + 1'b1);
  else 
    dly_cnt <= 'd0;
end 

assign vid_rst_n = dly_cnt[26];




// wire hs;

// wire de;
// wire [7:0] rgb_r;
// wire [7:0] rgb_g;
// wire [7:0] rgb_b;
  
  // color_bar_rgb #(
  // .HS_POLORY 		(1'b1		),
  // .VS_POLORY 		(1'b1		),
  // .H_FRONT_PORCH 	(HFP		),///2
  // .H_SYNC 		(HSP		),//
  // .H_VALID 		(MAX_HRES	),//
  // .H_BACK_PORCH 	(HBP		),//
  // .V_FRONT_PORCH 	(VFP		),
  // .V_SYNC 		(VSP		),
  // .V_VALID 		(MAX_VRES	),
  // .V_BACK_PORCH 	(VBP		),
  // .TEST_MODE 		(2'd2)
  // )u_color_bar_rgb1(
  // /*i*/.clk	(vid_clk_dvi2),//(vid_clk),
  // /*i*/.rst_n	(vid_rst_n),
  // /*o*/.hs	(hs),
  // /*o*/.vs	(vs),
  // /*o*/.de	(de),
  // // /*O*/.h_cnt (h_cnt),
  // // /*O*/.v_cnt (v_cnt),
  // /*o*/.rgb_r	(rgb_r),    //像素数据、红色分量
  // /*o*/.rgb_g	(rgb_g),    //像素数据、绿色分量
  // /*o*/.rgb_b (rgb_b)    //像素数据、蓝色分量
  
  // );

//=================================================================================
//hdmi tx ctrl 
//=================================================================================
wire                            video_hs;
wire                            video_vs;
wire                            video_de;
wire[7:0]                       video_r;
wire[7:0]                       video_g;
wire[7:0]                       video_b;

assign tmds_tx_data0_TX_OE = 1'b1;
assign tmds_tx_data1_TX_OE = 1'b1;
assign tmds_tx_data2_TX_OE = 1'b1;
assign tmds_tx_clk_TX_OE   = 1'b1;

assign tmds_tx_data0_TX_RST = 1'b0;
assign tmds_tx_data1_TX_RST = 1'b0;
assign tmds_tx_data2_TX_RST = 1'b0;
assign tmds_tx_clk_TX_RST   = 1'b0;

// 	  color_bar color_bar_m0(
// 	.clk(hdmi_tx_slow_clk),
// 	.rst(~vid_rst_n),
// 	.hs(video_hs),
// 	.vs(video_vs),
// 	.de(video_de),
// 	.rgb_r(video_r),
// 	.rgb_g(video_g),
// 	.rgb_b(video_b)
// );

wire [2047:0] osd_boxes;wire [4:0] osd_count;wire osd_request,osd_ack,osd_expired;
wire osd_vs,osd_hs,osd_de;wire [23:0] osd_bgr;
hdmi_osd u_hdmi_osd(.clk(hdmi_tx_slow_clk),.rst_n(vid_rst_n),
 .in_vs(hdmi_tx_vs),.in_hs(hdmi_tx_hs),.in_de(hdmi_tx_de),.in_bgr({hdmi_tx_bdata,hdmi_tx_gdata,hdmi_tx_rdata}),
 .mailbox_boxes(osd_boxes),.mailbox_count(osd_count),.request_toggle(osd_request),
 .acknowledge_toggle(osd_ack),.display_expired(osd_expired),.out_vs(osd_vs),.out_hs(osd_hs),.out_de(osd_de),.out_bgr(osd_bgr));
wire [9:0] tmds_data0;
wire [9:0] tmds_data1;
wire [9:0] tmds_data2;
wire [9:0] tmds_clk ;



dvi_encoder dvi_encoder_m0
(
	.pixelclk      		(hdmi_tx_slow_clk          ),// system clock
	.rst_p         		(~vid_rst_n      ),// reset
	.i_bdata      		(osd_bgr[23:16]),//(gamma_sel ? gamma_bdata	: hdmi_tx_rdata 	),//(osd_bgr[7:0]),//(video_b            ),//(bdata_in	),   //
	.i_gdata     		  (osd_bgr[15:8]),//(gamma_sel ? gamma_gdata	: hdmi_tx_gdata   ),//(hdmi_tx_gdata ),//(video_g            ),//(gdata_in	),   //   
	.i_rdata       		(osd_bgr[7:0]),//(gamma_sel ? gamma_rdata	: hdmi_tx_bdata 	),//(hdmi_tx_bdata ),//(video_r            ),//(rdata_in	),   //   
  .i_de            	(osd_de),//(gamma_sel ? gamma_valid	: hdmi_tx_de      ),//(hdmi_tx_de    ),//(video_de           ),//(rx_de		  ),   //
	.i_hs         		(osd_hs),//(gamma_sel ? gamma_hs	    : hdmi_tx_hs    ),//(video_hs           ),//(rx_hsync	),   //   
	.i_vs         		(osd_vs),//(gamma_sel ? gamma_vs	    : hdmi_tx_vs    ),//(video_vs           ),//(rx_vsync	),   //  
	
  .video_format     (2'b00), //// 00 = RGB, 01 = YCbCr 4:2:2, 10 = YCbCr 4:4:4
  .video_VIC        (0),
	.audio_L			    (audio_L),
  .audio_R			    (audio_R),
  .audio_valid		  (audio_valid),
  .audio_N                (6144),     //(20'h01880),//     
  .audio_CTS              (148500),      //(20'h28488),//      
  .audio_sample_frequency (audio_samp_freq),    //(3'b000),// 
  .audio_word_length      ({audio_samp_word_len,audio_max_word_length}),//(4'b1011),//

	.tmds_data0    		(tmds_data0),
  .tmds_data1    		(tmds_data1),
  .tmds_data2    		(tmds_data2),
  .tmds_clk      	  (tmds_clk  )
);
assign tmds_tx_clk_TX_DATA   = ~tmds_clk;
assign tmds_tx_data0_TX_DATA = ~tmds_data0;
assign tmds_tx_data1_TX_DATA = ~tmds_data1;
assign tmds_tx_data2_TX_DATA = ~tmds_data2;
//==================================================================  
//
//==================================================================



assign ge_rx_pll_RSTN = 1'b1;
assign osc_inst1_ENA = 1'b1;

wire prog_full_o;
wire [15:0] m_axis_tdata;
wire fifo_rd_en;
wire [7:0] fifo_rd_data;
reg fifo_rd_valid = 1'b0;
wire fifo_empty, fifo_rst_busy;
reg vs_r = 1'b0;
reg [7:0] pos_vs1_r = 8'b0;
wire pos_vs1;
wire image_fifo_reset = ~GE_PLL_LOCKED | (|pos_vs1_r) | pos_vs1;




always @( posedge rxc )
begin
  vs_r <= vs;
  pos_vs1_r <= {pos_vs1_r[6:0],pos_vs1};
end
assign pos_vs1 = {vs_r,vs} == 2'b01;


wire sw1;
key_detect # (
    .CLK_FREQUENCY_MHz(50)
  )
  key1_detect_inst1 (
    .i_key(key[2]),
    .clk(rxc),
    .rst_n(GE_PLL_LOCKED),
    .key_sw_en(sw1)
  );

wire [15:0] live_pixel_data;
wire live_pixel_valid;
wire live_pixel_ready;
reg [1:0] image_wr_reset = 2'b11;
reg [1:0] image_busy_wr = 2'b11;

 fifo u_fifo2
(
    .wr_clk_i ( vid_clk_dvi2 ),
    .a_rst_i ( image_fifo_reset ),//||(|pos_vs1_r)
    
    
    .wr_en_i  ( live_pixel_valid & live_pixel_ready ),
    .wdata    ( live_pixel_data ),
    .prog_full_o ( prog_full_o ),
    .rd_clk_i ( rxc ),
    .rd_en_i ( fifo_rd_en ),
    .rdata ( fifo_rd_data ),
    .empty_o ( fifo_empty ),
    .rst_busy ( fifo_rst_busy ),
    .rd_datacount_o (  ),
    .underflow_o (  )
);
// The reset request is asynchronous; release/gating is local to the write clock.
always @(posedge vid_clk_dvi2 or posedge image_fifo_reset) begin
    if(image_fifo_reset) begin image_wr_reset<=2'b11; image_busy_wr<=2'b11; end
    else begin
        image_wr_reset <= {image_wr_reset[0],1'b0};
        image_busy_wr <= {image_busy_wr[0],fifo_rst_busy};
    end
end
assign live_pixel_ready = ~prog_full_o & ~image_wr_reset[1] & ~image_busy_wr[1];
raw8_decimate3 u_live_reduce(
    .clk(vid_clk_dvi2), .rst_n(~image_wr_reset[1]),
    .enable(net_frame_read & ~image_wr_reset[1] & ~image_busy_wr[1]),
    .in_data(fb1_m_axis_tdata), .in_valid(fb1_m_axis_tvalid), .in_ready(fb1_m_axis_tready),
    .out_data(live_pixel_data), .out_valid(live_pixel_valid), .out_ready(live_pixel_ready),
    .done(live_read_done)
);

always @( posedge rxc )
begin
       if (image_fifo_reset || fifo_rst_busy) fifo_rd_valid <= 1'b0;
       else fifo_rd_valid <= fifo_rd_en & ~fifo_empty;
end



udp_test_top #(
       .UDP_WIDTH (8 ),
       .UDP_DEPTH (1280), ////UDP 一次发送的数据长度,也就是一次传输的字节数。
       .UDP_PACK_NUM(180), .FRAME_WIDTH(640), .FRAME_HEIGHT(360)
) u0_udp_test_top (
       .debug_status(mac_debug_status),
       .awb_status(net_awb_status),.sensor_status(net_sensor_status),
       .osd_boxes(osd_boxes),.osd_count(osd_count),.osd_request(osd_request),.osd_ack(osd_ack),.osd_expired(osd_expired),
       .rst_n(GE_PLL_LOCKED),
       .rxc(rxc),
       .sw(live_send_pulse ),
  /*I*/.source_mac_addr            (48'h00_0a_35_01_fe_c0)   ,       //source mac address
  /*I*/.TTL                        (8'h80),
  /*I*/.source_ip_addr             (32'hc0a80002),//192.168.0.2
  /*I*/.destination_ip_addr        (32'hc0a80003),//192.168.0.3
  /*I*/.udp_send_source_port       (16'h1f90),//8080
  /*I*/.udp_send_destination_port  (16'h1f90),//8080

 /*O*/.fifo_rd_en         (fifo_rd_en   ),
 /*I*/.fifo_empty         (fifo_empty | fifo_rst_busy | image_fifo_reset),
 /*I*/.fifo_rd_valid      (fifo_rd_valid),
 /*I*/.fifo_rd_data       (fifo_rd_data),//(src_sel? fifo_rd_data1:fifo_rd_data ),
 /*O*/.start_en           (vs),


       .rxd_hi_i(rxd_hi_i),
       .rxd_lo_i(rxd_lo_i),
       .rx_dv_HI(rx_dv_HI),
       .rx_dv_LO(rx_dv_LO),
       .tx_en_o_HI(tx_en_o_HI),
       .tx_en_o_LO(tx_en_o_LO),
       .txc_hi_o(txc_hi_o),
       .txc_lo_o(txc_lo_o),
       .txd_hi_o(txd_hi_o),
       .txd_lo_o(txd_lo_o),
       .mdc_o(mdc_o),
       .mdio_o(mdio_o),
       .mdio_oe(mdio_oe),
       .mdio_i(mdio_i),
       .phy_rst_n(phy_rst_n)
     );

//============================================================== 
//
//==============================================================

// Read-only JTAG diagnostics; counters are sampled after a fault.
reg [20:0] diag_source_words=0;
reg [17:0] diag_output_words=0;
always @(posedge vid_clk_dvi2 or posedge image_fifo_reset) begin
 if(image_fifo_reset) begin diag_source_words<=0; diag_output_words<=0; end
 else begin
  if(fb1_m_axis_tvalid && fb1_m_axis_tready) diag_source_words<=diag_source_words+1'b1;
  if(live_pixel_valid && live_pixel_ready) diag_output_words<=diag_output_words+1'b1;
 end
end
reg [31:0] diag_m1_beats=0;
always @(posedge core_clk or negedge vid_rst_n) begin
 if(!vid_rst_n) diag_m1_beats<=0;
 else if(m1_axi_rvalid && m1_axi_rready) diag_m1_beats<=diag_m1_beats+1'b1;
end
wire [255:0] ge_diag;
assign ge_diag[31:0]=32'h54364c34;
assign ge_diag[34:32]=live_state_debug;
assign ge_diag[37:35]=live_fault_stage;
assign ge_diag[39:38]=live_writes_debug;
assign ge_diag[40]=live_idle_sync[1];
assign ge_diag[41]=live_send_toggle;
assign ge_diag[42]=vs;
assign ge_diag[43]=live_read_done;
assign ge_diag[44]=net_frame_read;
assign ge_diag[45]=fifo_empty;
assign ge_diag[46]=fifo_rst_busy;
assign ge_diag[47]=image_fifo_reset;
assign ge_diag[48]=fb1_m_axis_tvalid;
assign ge_diag[49]=fb1_m_axis_tready;
assign ge_diag[50]=prog_full_o;
assign ge_diag[51]=image_wr_reset[1];
assign ge_diag[52]=image_busy_wr[1];
assign ge_diag[53]=capture_en;
assign ge_diag[54]=m1_axi_arvalid;
assign ge_diag[55]=m1_axi_arready;
assign ge_diag[56]=m1_axi_rvalid;
assign ge_diag[57]=m1_axi_rready;
assign ge_diag[60:58]=live_send_sync;
assign ge_diag[63:61]=0;
assign ge_diag[127:64]=hdmi_status_sync;
// R24: source cadence and independent reader ownership.
assign ge_diag[159:128]=video_count_sync[63:32]; // published camera frames, Gray
assign ge_diag[191:160]=video_count_sync[31:0];  // network starts, Gray
assign ge_diag[199:192]=0;
assign ge_diag[203:200]=hdmi_read_protected;
assign ge_diag[205:204]=snapshot_write_base[22:21];
assign ge_diag[207:206]=snapshot_read_base[22:21];
assign ge_diag[209:208]=snapshot_network_base[22:21];
assign ge_diag[211:210]=hdmi_active_base[22:21];
assign ge_diag[212]=video_network_reserved;
assign ge_diag[232:213]=physical_write_collisions;
// R22 identity and applied-bank readback in previously unused diagnostic bits.
assign ge_diag[234:233]=isp_color_bank;
assign ge_diag[242:235]=8'h26;
assign ge_diag[243]=frame_capture_ready;
assign ge_diag[244]=snapshot_write_base[21];
assign ge_diag[245]=snapshot_read_base[21];
assign ge_diag[246]=hdmi_active_base[21];
assign ge_diag[247]=frame_display_ready;
assign ge_diag[253:248]=hdmi_reads_pending;
assign ge_diag[254]=display_frame_valid;
assign ge_diag[255]=frame_publish;

debug_edb_top debug_edb_top_inst (
    .bscan_CAPTURE      ( jtag_inst1_CAPTURE  ),
    .bscan_DRCK         ( jtag_inst1_DRCK     ),
    .bscan_RESET        ( jtag_inst1_RESET    ),
    .bscan_RUNTEST      ( jtag_inst1_RUNTEST  ),
    .bscan_SEL          ( jtag_inst1_SEL      ),
    .bscan_SHIFT        ( jtag_inst1_SHIFT    ),
    .bscan_TCK          ( jtag_inst1_TCK      ),
    .bscan_TDI          ( jtag_inst1_TDI      ),
    .bscan_TMS          ( jtag_inst1_TMS      ),
    .bscan_UPDATE       ( jtag_inst1_UPDATE   ),
    .bscan_TDO          ( jtag_inst1_TDO      ),
    .vio0_clk           ( vid_clk_dvi2        ),
    .vio0_r_gain        ( r_gain              ),
    .vio0_g_gain        ( g_gain              ),
    .vio0_b_gain        ( b_gain              ),
    .vio0_gamma_sel     (gamma_sel            ),

    .vio1_clk           ( rxc        ),
    .vio1_status        (ge_diag),

    .la0_clk            ( vid_clk_dvi2 ),
    .la0_fb1_m_axis_tvalid      ( fb1_m_axis_tvalid ),
    .la0_fb1_m_axis_tdata       ( fb1_m_axis_tdata ),
    .la0_fb1_m_axis_tready      ( fb1_m_axis_tready ),
    .la0_fb1_m_axis_tuser       ( fb1_m_axis_tuser ),
    .la0_fb1_m_axis_tlast       ( fb1_m_axis_tlast ),
    .la0_vs     ( vs )

);


endmodule
