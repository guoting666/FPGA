"""Sequential video regression on the reported pink 1, including temporal gating.

Manual fact: the pink 1 remains in the upper-left region from frames 80..485.
Two crops from this video were used for training, so these are repair diagnostics.
"""
from pathlib import Path
import argparse,sys,json,time
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from detector import Detector
from geometry import ShapePipeline

def main():
 p=argparse.ArgumentParser();p.add_argument('--video',type=Path,required=True);a=p.parse_args();cv2.setNumThreads(1);d=Detector();pipe=ShapePipeline(d)
 cap=cv2.VideoCapture(str(a.video));cases=[];lat=[];fid=0;started=time.perf_counter()
 while True:
  ok,im=cap.read()
  if not ok:break
  if fid<80:fid+=1;continue
  # Same 960px analysis scale as the app, all consecutive frames are processed.
  im=cv2.resize(im,(960,555),interpolation=cv2.INTER_AREA)
  pred,t=pipe.predict(im,.96,targets='both',stable=True)
  local=[x for x in pred if x.get('group')=='digit' and 130<(x['xyxy'][0]+x['xyxy'][2])/2<280 and 100<(x['xyxy'][1]+x['xyxy'][3])/2<260 and x['xyxy'][3]-x['xyxy'][1]>90]
  cases.append(dict(frame=fid,local_digits=[x['digit'] for x in local]));lat.append(t['inference_total_ms']);fid+=1
 cap.release();correct=sum('1'in x['local_digits'] for x in cases);wrong=sum('9'in x['local_digits'] for x in cases)
 report=dict(scope='Same-video repair regression, not independent camera accuracy. Frames 80..485 contain the reported pink 1. All consecutive frames pass combined inference and two-frame confirmation; overlays may hide part of the object. Two foreground crops from this video were used for fitting.',digit_model_sha256=d.digits.sha256,frames=len(cases),frames_with_correct_one=correct,frames_with_wrong_nine=wrong,frames_missing_one=len(cases)-correct,mean_combined_ms=float(np.mean(lat)),wall_seconds=time.perf_counter()-started,cases=cases)
 (ROOT/'reports/clay_video_regression.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='cases'},indent=2))
if __name__=='__main__':main()
