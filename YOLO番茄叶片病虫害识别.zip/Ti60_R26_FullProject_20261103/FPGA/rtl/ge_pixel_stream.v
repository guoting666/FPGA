// Network-only DDR normal-FIFO to AXI pixel stream. Exact frame origin and
// bounded word count, including after a previous read was abandoned.
module ge_pixel_stream #(
 parameter I_WIDTH=128, O_WIDTH=16, FRAME_WIDTH=960, FRAME_HEIGHT=1080,
 parameter GUARD_CYCLES=64
)(
 input clk,rst_n,frame_period,input fifo_empty,input [I_WIDTH-1:0] fifo_data,
 output fifo_read,output [O_WIDTH-1:0] axis_data,output axis_valid,
 input axis_ready,output axis_sof,axis_eol
);
localparam WORDS=I_WIDTH/O_WIDTH;
localparam IDLE=0, WAIT_DATA=1, EMIT=2, COMPLETE=3;
reg [1:0] state;
reg period_d;
reg [6:0] guard;
reg [I_WIDTH-1:0] buffer;
reg [$clog2(WORDS)-1:0] index;
reg [12:0] x,y;
wire start=frame_period&&!period_d;
wire enabled=frame_period && guard==0 && !start;
assign fifo_read=enabled && state==IDLE && !fifo_empty;
assign axis_valid=enabled && state==EMIT;
assign axis_data=buffer[I_WIDTH-1-:O_WIDTH];
assign axis_sof=axis_valid && x==0 && y==0;
assign axis_eol=axis_valid && x==FRAME_WIDTH-1;
always @(posedge clk or negedge rst_n)begin
 if(!rst_n)begin
  state<=IDLE;period_d<=0;guard<=GUARD_CYCLES;buffer<=0;index<=0;x<=0;y<=0;
 end else begin
  period_d<=frame_period;
  if(start || !frame_period)begin
   state<=IDLE;guard<=GUARD_CYCLES;buffer<=0;index<=0;x<=0;y<=0;
  end else if(guard!=0)begin
   guard<=guard-1'b1;state<=IDLE;
  end else case(state)
   IDLE:if(fifo_read)state<=WAIT_DATA;
   WAIT_DATA:begin buffer<=fifo_data;index<=0;state<=EMIT;end
   EMIT:if(axis_ready)begin
    if(x==FRAME_WIDTH-1)begin
     x<=0;
     if(y==FRAME_HEIGHT-1)state<=COMPLETE;else y<=y+1'b1;
    end else x<=x+1'b1;
    if(!(x==FRAME_WIDTH-1 && y==FRAME_HEIGHT-1))begin
     if(index==WORDS-1)state<=IDLE;
     else begin index<=index+1'b1;buffer<=buffer<<O_WIDTH;end
    end
   end
   COMPLETE:state<=COMPLETE;
   default:state<=IDLE;
  endcase
 end
end
endmodule

// HDMI normal-FIFO unpacker. A VS pulse starts one complete frame; its
// falling edge does not stop the stream. Prefetch permits one pixel pair
// on every output clock, including across DDR-word boundaries.
module ge_hdmi_stream #(
 parameter I_WIDTH=128,O_WIDTH=16,FRAME_WIDTH=960,FRAME_HEIGHT=1080,
 parameter GUARD_CYCLES=128
)(
 input clk,rst_n,frame_period,input fifo_empty,input[I_WIDTH-1:0]fifo_data,
 output fifo_read,output[O_WIDTH-1:0]axis_data,output axis_valid,
 input axis_ready,output axis_sof,axis_eol
);
localparam WORDS=I_WIDTH/O_WIDTH;
reg period_d,running,pending;
reg[7:0]guard;
reg[I_WIDTH-1:0]queue[0:1];
reg write_ptr,read_ptr;
reg[1:0]used;
reg[$clog2(WORDS)-1:0]index;
reg[12:0]x,y;
wire start=frame_period&&!period_d;
wire enabled=running&&guard==0&&!start;
assign fifo_read=enabled&&!fifo_empty&&(used+{1'b0,pending}<2);
assign axis_valid=enabled&&used!=0;
assign axis_data=queue[read_ptr][I_WIDTH-1-index*O_WIDTH-:O_WIDTH];
assign axis_sof=axis_valid&&x==0&&y==0;
assign axis_eol=axis_valid&&x==FRAME_WIDTH-1;
wire accepted=axis_valid&&axis_ready;
wire pop=accepted&&index==WORDS-1;
always @(posedge clk or negedge rst_n)begin
 if(!rst_n)begin
  period_d<=0;running<=0;pending<=0;guard<=GUARD_CYCLES;
  write_ptr<=0;read_ptr<=0;used<=0;index<=0;x<=0;y<=0;
 end else begin
  period_d<=frame_period;
  if(start)begin
   running<=1;pending<=0;guard<=GUARD_CYCLES;
   write_ptr<=0;read_ptr<=0;used<=0;index<=0;x<=0;y<=0;
  end else if(guard!=0)begin guard<=guard-1'b1;pending<=0;end
  else if(running)begin
   pending<=fifo_read;
   if(pending)begin queue[write_ptr]<=fifo_data;write_ptr<=~write_ptr;end
   case({pending,pop})
    2'b10:used<=used+1'b1;
    2'b01:used<=used-1'b1;
    default:used<=used;
   endcase
   if(accepted)begin
    if(pop)begin index<=0;read_ptr<=~read_ptr;end
    else index<=index+1'b1;
    if(x==FRAME_WIDTH-1)begin
     x<=0;
     if(y==FRAME_HEIGHT-1)begin running<=0;pending<=0;end
     else y<=y+1'b1;
    end else x<=x+1'b1;
   end
  end
 end
end
endmodule
