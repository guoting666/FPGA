// T6V1 snapshot sender. Preload one chunk before requesting the vendor MAC.
// The vendor checksum circuit requires a CONTIGUOUS payload after its request.
`timescale 1ns/1ns
module mac_test #(
    parameter UDP_WIDTH=8, UDP_DEPTH=1280, UDP_PACK_NUM=1620,
    parameter FRAME_WIDTH=1920, FRAME_HEIGHT=1080,
    parameter PIXEL_FORMAT=6, // BGGR RAW8; odd 3x sampling preserves Bayer parity
    parameter PACKET_GAP=31250, STALL_CYCLES=125000000
)(
    input [127:0] awb_status,input [255:0]sensor_status, output [63:0] debug_status, output [31:0] wire_frame_id,
    input [31:0] osd_applied_frame,input [4:0] osd_applied_count,input [15:0] osd_feedback_flags,
    input rst_n, sw, input [31:0] pack_total_len,
    output reg start_en, input gmii_tx_clk, gmii_rx_clk,
    output fifo_rd_en, input fifo_empty, fifo_rd_valid,
    input [7:0] fifo_rd_data,
    output [7:0] tx_ram_wr_data, output tx_ram_wr_en,
    input udp_ram_data_req, output [15:0] udp_send_data_length,
    output udp_tx_req, arp_request_req, mac_data_valid,
    input mac_send_end, output [7:0] mac_tx_data,
    input [7:0] mac_rx_datain, udp_rec_ram_rdata,
    output [10:0] udp_rec_ram_read_addr,
    input [15:0] udp_rec_data_length, input udp_rec_data_valid,
    input arp_found, mac_not_exist
);
localparam [31:0] TOTAL_BYTES=UDP_DEPTH*UDP_PACK_NUM;
localparam [15:0] W=FRAME_WIDTH, H=FRAME_HEIGHT, PAYLOAD=UDP_DEPTH;
localparam IDLE=0, ARP_REQ=1, ARP_SEND=2, ARP_WAIT=3,
           FILL=4, GEN_REQ=5, WRITE=6, SEND=7, GAP=8, FAULT=9;
reg [3:0] state;
reg sw_r;
reg [3:0] fault_stage;
reg [31:0] frame_id, frame_offset, wait_cnt;
reg [127:0] frame_awb;reg[255:0]frame_sensor;
reg [31:0] feedback_frame;reg [4:0] feedback_count;reg [15:0] feedback_flags;
assign wire_frame_id=frame_id;
reg [15:0] packet_index, issued, received, write_index;
assign debug_status={packet_index,received,issued,8'b0,fault_stage,state};

(* syn_ramstyle="block_ram" *) reg [7:0] payload_mem [0:UDP_DEPTH-1];
reg [7:0] payload_out;
wire [15:0] read_index = write_index >= 87 ? write_index-87 : 0;
always @(posedge gmii_tx_clk) begin
    if (state==FILL && fifo_rd_valid && received<UDP_DEPTH)
        payload_mem[received] <= fifo_rd_data;
    if (read_index<UDP_DEPTH) payload_out <= payload_mem[read_index];
end
function [7:0] header_byte;
input [6:0] n;
begin
    case(n)
      0:header_byte="T"; 1:header_byte="6";
      2:header_byte="V"; 3:header_byte="1";
      4:header_byte=4; 5:header_byte=PIXEL_FORMAT;
      6:header_byte=0; 7:header_byte=88;
      8:header_byte=frame_id[31:24]; 9:header_byte=frame_id[23:16];
      10:header_byte=frame_id[15:8]; 11:header_byte=frame_id[7:0];
      12:header_byte=W[15:8]; 13:header_byte=W[7:0];
      14:header_byte=H[15:8]; 15:header_byte=H[7:0];
      16:header_byte=TOTAL_BYTES[31:24]; 17:header_byte=TOTAL_BYTES[23:16];
      18:header_byte=TOTAL_BYTES[15:8]; 19:header_byte=TOTAL_BYTES[7:0];
      20:header_byte=frame_offset[31:24]; 21:header_byte=frame_offset[23:16];
      22:header_byte=frame_offset[15:8]; 23:header_byte=frame_offset[7:0];
      24:header_byte=PAYLOAD[15:8]; 25:header_byte=PAYLOAD[7:0];
      28:header_byte=feedback_frame[31:24];29:header_byte=feedback_frame[23:16];
      30:header_byte=feedback_frame[15:8];31:header_byte=feedback_frame[7:0];
      32:header_byte=0;33:header_byte={3'b0,feedback_count};
      34:header_byte=feedback_flags[15:8];35:header_byte=feedback_flags[7:0];
      36:header_byte="T";37:header_byte="6";38:header_byte="O";39:header_byte="4";
      default:header_byte=n>=40 && n<56 ? (frame_awb >> ((55-n)*8)) : n>=56 && n<88 ? (frame_sensor >> ((87-n)*8)) : 0;
    endcase
end
endfunction
assign tx_ram_wr_data=write_index<88 ? header_byte(write_index[6:0]) : payload_out;
assign tx_ram_wr_en=state==WRITE;
assign fifo_rd_en=state==FILL && issued<UDP_DEPTH && !fifo_empty;
assign udp_send_data_length=UDP_DEPTH+88;
assign udp_tx_req=state==GEN_REQ;
assign arp_request_req=state==ARP_REQ;
// Unused legacy diagnostic/echo outputs. Pixel packets are transmit-only.
assign mac_data_valid=0;
assign mac_tx_data=0;
assign udp_rec_ram_read_addr=0;
always @(posedge gmii_tx_clk or negedge rst_n) begin
  if(!rst_n) begin
    frame_sensor<=0;frame_awb<=128'h0000000040004000917040006f4c0001;
    fault_stage<=0; state<=IDLE; start_en<=0; sw_r<=0; frame_id<=0;feedback_frame<=0;feedback_count<=0;feedback_flags<=0;
    frame_offset<=0; packet_index<=0; issued<=0; received<=0;
    write_index<=0; wait_cnt<=0;
  end else begin
    sw_r<=sw;
    if(state!=FAULT) fault_stage<=state;
    case(state)
      IDLE: begin
        wait_cnt<=0;
        if(sw && !sw_r) begin
          frame_awb<=awb_status;frame_sensor<=sensor_status;
          start_en<=1; frame_id<=frame_id+1'b1; frame_offset<=0;
          feedback_frame<=osd_applied_frame;feedback_count<=osd_applied_count;feedback_flags<=osd_feedback_flags;
          packet_index<=0; issued<=0; received<=0;
          state<=mac_not_exist ? ARP_REQ : FILL;
        end
      end
      ARP_REQ: begin state<=ARP_SEND; wait_cnt<=0; end
      ARP_SEND: begin
        if(mac_send_end) begin state<=ARP_WAIT; wait_cnt<=0; end
        else if(wait_cnt==STALL_CYCLES-1) begin state<=FAULT; start_en<=0; end
        else wait_cnt<=wait_cnt+1'b1;
      end
      ARP_WAIT: begin
        if(arp_found || !mac_not_exist) begin state<=FILL; wait_cnt<=0; end
        else if(wait_cnt>=pack_total_len) begin state<=ARP_REQ; wait_cnt<=0; end
        else wait_cnt<=wait_cnt+1'b1;
      end
      FILL: begin
        if(fifo_rd_en) issued<=issued+1'b1;
        if(fifo_rd_valid) begin
          received<=received+1'b1; wait_cnt<=0;
          if(received==UDP_DEPTH-1) state<=GEN_REQ;
        end else if(wait_cnt==STALL_CYCLES-1) begin state<=FAULT; start_en<=0; end
        else wait_cnt<=wait_cnt+1'b1;
      end
      GEN_REQ: begin
        if(udp_ram_data_req) begin state<=WRITE; write_index<=0; wait_cnt<=0; end
        else if(wait_cnt==STALL_CYCLES-1) begin state<=FAULT; start_en<=0; end
        else wait_cnt<=wait_cnt+1'b1;
      end
      WRITE: begin
        if(write_index==UDP_DEPTH+87) begin state<=SEND; wait_cnt<=0; end
        else write_index<=write_index+1'b1;
      end
      SEND: begin
        if(mac_send_end) begin
          wait_cnt<=0;
          if(packet_index==UDP_PACK_NUM-1) begin start_en<=0; state<=IDLE; end
          else begin
            packet_index<=packet_index+1'b1; frame_offset<=frame_offset+UDP_DEPTH;
            issued<=0; received<=0; state<=GAP;
          end
        end else if(wait_cnt==STALL_CYCLES-1) begin state<=FAULT; start_en<=0; end
        else wait_cnt<=wait_cnt+1'b1;
      end
      GAP: begin
        if(wait_cnt>=PACKET_GAP) begin
          state<=mac_not_exist ? ARP_REQ : FILL; wait_cnt<=0;
        end else wait_cnt<=wait_cnt+1'b1;
      end
      // A partial DDR frame must not be reused. Press KEY0/reset to retry.
      FAULT: begin start_en<=0; end
      default: begin state<=FAULT; start_en<=0; end
    endcase
  end
end
endmodule
