# Ti60 R8：旋转描边与图形、数字识别

双击 **启动识别.cmd**，页面为 **http://127.0.0.1:18792/**。电脑执行识别，FPGA 采集、网传并在 HDMI 上显示结果。

R8 新增矩形四角与三角形三边描边，倾斜时框随轮廓旋转。数字和圆形使用包围框。网页与 HDMI 使用同一组角点；HDMI 最多显示 16 个目标。选“YOLO＋严格轮廓校验”或“仅轮廓”使用旋转描边，纯 YOLO 保持水平框。

配套工程、位流、回退程序、时序与实板证据见相邻 `Ti60_旋转贴边框_R8` 目录。R8 保留 R6 网传修复和已确认正常的颜色、Bayer 排列，不重新训练数字或图形模型。实时传输与电脑推理仍有延迟，快速移动时可能短暂落后；请停稳后判断静态贴合。

当前测试记录为 `reports/hdmi_feedback_verification.json`、`reports/camera_shape_regression.json` 及配套工程中的 `reports/rotated_verification.json`；实板状态以配套目录的 `实板验证.json` 为准。

下面保留此前数字模型的训练与回归说明；reports 里此前的截图和板卡记录属于历史资料，不能视为 R8 HDMI 效果验证。

## 本次结果

| 数字 | 在场帧数 | 旧版正确帧 | 新版正确帧 | 新版误判帧 | 新版漏检帧 |
|---|---:|---:|---:|---:|---:|
| 2 | 370 | 0 | 240 | 1 | 129 |
| 7 | 159 | 88 | 151 | 0 | 8 |
| 9 | 65 | 0 | 56 | 0 | 9 |

视频共 486 帧，数字两帧确认，按人工在场区间和 IoU≥0.5 匹配。部分视频裁剪用于训练，所以这些数字仅表示同视频修复回归；遮挡帧没有被剔除。2→8 仍有 1 帧，2 仍有 129 帧漏检；未做到所有帧稳定识别。英文字母 O 与数字 0 也仍可能混淆。

已通过 54 项电脑功能/回归检查，其中新增 6 项反馈协议与实际模型/UDP socket 检查。旧粉色 1 连续 406 帧中 379 帧正确、0 帧报成 9、27 帧漏检。金色 0–9 在原尺寸、75%、50% 尺寸全部检出；图形与数字独立，允许 4 与其内部三角形同时显示。这些离线结果不代表实拍准确率。

实网页截图 `reports/立体数字2789修复后网页.png` 和配对 `2789_web_saved_*` 对应当前模型；清晰全景检出了 1–9，画面中的 10 仍未拆开。详情见 `reports/立体数字2789修复说明.md` 与逐帧 JSON。

## 实现

三角形、矩形、圆形沿用 ShapeYOLO-32K INT8 与轮廓校验。数字为独立的 68,603 参数 DigitCNN，0–9 与 reject 共 11 输出；通过连通区域定位后分类，**不是十三类 YOLO**。TFLite 动态权重量化、float32 输入。默认数字阈值 0.93、前两类差至少 0.20；字幕分离后的碎片至少 0.98。

改进了完整彩色前景定位、相邻数字的候选保留、字幕/UI色块分离，以及轮廓内部小碎片去重。没有按坐标指定类别或把所有 8 改成 2。连续视频保留两帧确认，物体消失立即清框；静态图片立即识别。支持本地视频/图片、合成示例及 T6V1 UDP；USB/HDMI 采集卡入口已移除。

保存一帧同时保存原图、识别图、参数和两套模型哈希。当前数字模型 SHA256：`cbbce20e5c4d854c60c7268b1f8e3f4c38b533ec63046a758ba847ebd193c616`。

## 数据与训练

用户的 [thawro/yolov8-digits-detection](https://github.com/thawro/yolov8-digits-detection) 指向 [HWD+ 原论文](https://pmc.ncbi.nlm.nih.gov/articles/PMC9702948/)，沿作者公开链接实际下载 13,580 张数字及标签。HWD+ 按书写者划分：训练 70 人/9,800 张、验证 14 人/1,960 张、测试 13 人/1,820 张，不重叠。MNIST 55,000 张训练、5,000 张验证，官方 10,000 张测试不训练。

本轮补充人工标注的 10 个立体数字、4 个玩具车拒识前景、3 个遮挡后的数字前景，保留此前 1/9 各一个样本。前景图、标签与来源在 `tests/fixtures/clay_all`、`tests/fixtures/clay`。金色数字图没有加入训练。公开测试图不进入拟合或检查点选择；同视频其他帧仍属于训练相关场景。

全部立体字阶段 81,800 样本训练 8 轮；加入遮挡前景再训练 6 轮，检查点按原 HWD 验证书写者与新生成样本的验证损失选择。为保留 1/9，通过原 HWD 验证集选择两轮检查点的 25%/75% 权重平均，再用 47,300 个训练样本重放，只更新最终分类层 3 轮。训练历史与选择依据均保存在 reports 和 metadata。

用户另一 GitHub 仓库 number0418525 没有实际图片标签；Roboflow 页面显示 300 张，但可用工具未能导出，未将其声称用于训练。没有执行这些仓库脚本或再分发它们的权重。Windows 字体只按路径渲染，字体文件未复制。数据权利见 `DIGIT_MODEL_NOTICE.md`。

现有前置检查点及新脚本可继续微调；从前一 1/9 版本开始的步骤为：

```powershell
python training/finetune_clay_all.py --data ../Digit_Training_Data --epochs 8 --exclude-overlays
# 把此步 clay_all_best.keras 另存为 clay_initial_best.keras
python training/finetune_clay_all.py --data ../Digit_Training_Data --epochs 6 --initial-checkpoint model/digits/clay_initial_best.keras
python training/average_clay_checkpoints.py --data ../Digit_Training_Data
python training/finetune_retention.py --data ../Digit_Training_Data
python tests/verify_2789.py
python tests/verify_one_nine.py
python tests/verify_gold.py
python tests/verify_digits.py
```

## 测试范围

当前 HWD 留出书写者单数字 top-1 为 97.42%，通过阈值结果正确率 99.59%，全部测试图中正确且通过 92.64%；MNIST 对应 98.18%、99.78%、94.94%。这是裁剪分类指标，不是全图检测 mAP 或实拍准确率。

受控组合图：320 个 HWD 数字正确匹配 299 个、额外错误框 1 个；360 个留出字体数字匹配 297 个、额外错误框 7 个。这些场景用于后处理调试，不是盲测。完整数值和缺陷保留在 reports。视频数字阶段平均 59.7 ms，处理比旧版更慢；不是板卡 FPS 或端到端延迟。

## 网线与板卡

摄像头 → Ti60 → 板载 RJ45 → 电脑有线网口；HDMI 接显示器。电脑 192.168.0.3/24、板卡 192.168.0.2、双方 UDP 8080。新版固件使用 T6V1 v2，电脑识别结果以 T6O1 自动回传。无需采集卡，不需要手动拍照。

电脑针对新版 Bayer 图像使用用户保存的 V36 黑电平、白平衡、gamma、颜色矩阵与饱和度。旧版 T6V1 v1 继续使用历史 491/256/418 增益。固件重启帧号归零后须停止再开始接收。协议详情见 `ethernet/T6V1协议.md`。

程序只在 localhost 提供页面，素材和识别结果保存在本机。旧版截图和 1/9、金色修复说明为历史证据；当前以 `2789_web_saved_*`、`video_2789_comparison.json`、`PROJECT_STATUS.json` 及当前模型哈希为准。

## 当前板卡连接（2026-10-24）

已按用户授权加载网传与 HDMI 标注固件至 SRAM，18792 实收 640×360 连续图像，并确认板卡实际接收、应用电脑回传的框。第一次上板用户确认有框，但报告 HDMI 偏紫，因此继续移植 V36 原有 Bayer 解码并修正三通道输出；随后修正 DDR 四像素写入与两像素读出间的组顺序，并同步修正网口抽样。最终版本和实测结论以 `reports/v36_hdmi_board.json` 为准。识别帧率会随电脑负载及目标数量波动。

HDMI 实时摄像头画面使用稍早的电脑识别结果，移动时可能有标注延迟；空结果或超时会清框。对色卡可检出矩形，复杂背景里的 UI 数字仍可能误检，三种图形和数字须用完整、清晰的实拍目标另外验收。Canny 原程序与用户参数已备份；本轮只写 SRAM，未写 Flash，未修改网卡。

