"""Ten-class leaf detection with a separately continued eleven-way classifier."""
from pathlib import Path
import hashlib,json,time,math
import cv2,numpy as np
NAMES_ZH=('早疫病','斑枯病','健康叶片','细菌性斑点病','晚疫病','花叶病毒病','黄化病毒病','叶霉病','双斑叶螨危害','靶斑病')
NAMES_EN=('Tomato Early blight leaf','Tomato Septoria leaf spot','Tomato leaf','Tomato leaf bacterial spot','Tomato leaf late blight','Tomato leaf mosaic virus','Tomato leaf yellow virus','Tomato mold leaf','Tomato spider mites damage','Tomato Target Spot')
OFFSET=13
def pipeline_identity(meta):
 fields=['onnx_sha256','refiner_sha256','proposal_confidence','classification_margin','crop_margin','leaf_nms_iou','proposal_nms_iou','max_proposals','fusion_alpha','background_threshold','fusion_adaptive','class_thresholds']
 return hashlib.sha256(json.dumps({k:meta.get(k) for k in fields},sort_keys=True,separators=(',',':')).encode()).hexdigest()
def prepare_crop(image,box,margin=.08):
 h,w=image.shape[:2];x1,y1,x2,y2=box;dx=(x2-x1)*margin;dy=(y2-y1)*margin
 a=max(0,math.floor(x1-dx));b=max(0,math.floor(y1-dy));c=min(w,math.ceil(x2+dx));d=min(h,math.ceil(y2+dy));crop=image[b:d,a:c];ch,cw=crop.shape[:2]
 gain=min(224/cw,224/ch);nw,nh=round(cw*gain),round(ch*gain);canvas=np.full((224,224,3),114,np.uint8);left=(224-nw)//2;top=(224-nh)//2
 canvas[top:top+nh,left:left+nw]=cv2.resize(crop,(nw,nh));x=canvas[:,:,::-1].astype(np.float32)/255.
 return ((x-[.485,.456,.406])/[.229,.224,.225]).transpose(2,0,1).astype(np.float32)
def select_candidates(candidates,confidence,proposal_confidence,margin,nms_iou,alpha=1.,background_threshold=.5,adaptive=False,class_thresholds=None):
 result=[]
 for item in candidates:
  q=np.asarray(item['class_probabilities'],float);p=np.asarray(item['proposal_probabilities'],float);p=p/max(1e-9,p.sum());leaf=q[:10]/max(1e-9,1-q[10]);weight=alpha+(1-alpha)*(1-item['localization_confidence']) if adaptive else alpha;scores=np.r_[((1-weight)*p+weight*leaf)*(1-q[10]),q[10]];c=int(np.argmax(scores));order=sorted(scores,reverse=True)
  if q[10]>=background_threshold:continue
  if c==10 or scores[c]<confidence or order[0]-order[1]<margin or item['localization_confidence']<proposal_confidence:continue
  result.append(dict(class_id=OFFSET+c,disease_id=c,name=NAMES_ZH[c],name_en=NAMES_EN[c],confidence=float(scores[c]),xyxy=list(item['xyxy']),group='tomato',source='yolo+leaf-refiner',localization_confidence=item['localization_confidence'],classification_margin=float(order[0]-order[1]),confidence_source='validated-leaf-fusion'))
 if not result:return []
 boxes=[[p['xyxy'][0],p['xyxy'][1],p['xyxy'][2]-p['xyxy'][0],p['xyxy'][3]-p['xyxy'][1]] for p in result]
 keep=np.asarray(cv2.dnn.NMSBoxes(boxes,[p['confidence'] for p in result],confidence,nms_iou),dtype=int).reshape(-1)
 kept=[result[int(i)] for i in keep[:30]]
 return [p for p in kept if class_thresholds is None or p['confidence']>=class_thresholds[p['disease_id']]]
class TomatoDetector:
 def __init__(self,folder=None):
  self.folder=Path(folder or Path(__file__).parent/'model/tomato');self.net=None;self.refiner=None;self.meta=None;self.sha256=None;self.error='';self._stamp=None
 def state(self):
  model=self.folder/'tomato_yolov8n.onnx';metadata=self.folder/'metadata.json';refiner=self.folder/'leaf_refiner.onnx'
  stamp=(model.stat().st_mtime_ns,metadata.stat().st_mtime_ns,refiner.stat().st_mtime_ns if refiner.is_file() else None) if model.is_file() and metadata.is_file() else None
  if stamp is not None and stamp!=self._stamp:
   self._stamp=stamp;self.net=self.refiner=None;self.meta=None;self.sha256=None
   try:
    m=json.loads(metadata.read_text(encoding='utf8'));digest=hashlib.sha256(model.read_bytes()).hexdigest()
    if digest!=m['onnx_sha256'] or m['names_en']!=list(NAMES_EN) or m.get('source_group_overlap')!=0 or not m.get('trained'):raise ValueError('番茄模型与类别元数据校验失败')
    if m['input_size'] not in [320,384,416,512,640] or m.get('default_confidence',.4) not in [.25,.4,.6]:raise ValueError('番茄输入尺寸或阈值无效')
    if m.get('pipeline')=='leaf-refiner-v3':
     if hashlib.sha256(refiner.read_bytes()).hexdigest()!=m['refiner_sha256'] or m.get('refiner_classes')!=11:raise ValueError('叶片分类模型校验失败')
     if not .005<=m['proposal_confidence']<=.25 or not 0<=m['classification_margin']<=.5 or not 0<=m['crop_margin']<=.2 or not 0.1<=m['leaf_nms_iou']<=.9 or not .1<=m['proposal_nms_iou']<=.9 or not 1<=m['max_proposals']<=64:raise ValueError('叶片复核参数无效')
     if not 0<=m['fusion_alpha']<=1 or not 0<m['background_threshold']<=1:raise ValueError('叶片融合参数无效')
     if m.get('class_thresholds') is not None and (len(m['class_thresholds'])!=10 or not all(type(t) in (int,float) and .05<=t<=.99 for t in m['class_thresholds'])):raise ValueError('类别阈值无效')
     digest=pipeline_identity(m)
     if digest!=m['pipeline_sha256']:raise ValueError('叶片模型组合与参数校验失败')
    self.meta=m;self.sha256=digest;self.error=''
   except (OSError,ValueError,KeyError,TypeError) as exc:self.error=str(exc)
  if stamp is None:self.net=self.refiner=None;self.meta=None;self.sha256=None;self._stamp=None
  return dict(ready=self.meta is not None,sha256=self.sha256,names=list(NAMES_ZH),classes=10,task='番茄叶片病害与健康状态',error=self.error,scope='10 类病害/健康/双斑叶螨危害；叶螨类识别受害叶片，不定位虫体',metrics=self.meta.get('test_metrics') if self.meta else None,default_confidence=self.meta.get('default_confidence',.4) if self.meta else .4,pipeline=self.meta.get('pipeline','yolo-v1') if self.meta else None,refiner_sha256=self.meta.get('refiner_sha256') if self.meta else None,evaluation_summary=self.meta.get('evaluation_summary') if self.meta else None)
 def _load(self):
  if not self.state()['ready']:raise ValueError(self.error or '番茄模型尚未就绪')
  if self.net is None:
   self.net=cv2.dnn.readNetFromONNX(str(self.folder/'tomato_yolov8n.onnx'));self.net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV);self.net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
  if self.meta.get('pipeline')=='leaf-refiner-v3' and self.refiner is None:
   self.refiner=cv2.dnn.readNetFromONNX(str(self.folder/'leaf_refiner.onnx'));self.refiner.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV);self.refiner.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
 def _yolo(self,bgr,confidence,classwise):
  h,w=bgr.shape[:2];size=self.meta['input_size'];gain=min(size/w,size/h);nw,nh=round(w*gain),round(h*gain);left=round((size-nw)/2-.1);top=round((size-nh)/2-.1)
  canvas=np.full((size,size,3),114,np.uint8);canvas[top:top+nh,left:left+nw]=cv2.resize(bgr,(nw,nh))
  self.net.setInput(cv2.dnn.blobFromImage(canvas,1/255.,(size,size),swapRB=True));raw=self.net.forward()
  if raw.ndim!=3 or raw.shape[0]!=1 or raw.shape[1]!=14 or not np.isfinite(raw).all():raise ValueError('番茄定位模型输出不匹配')
  rows=raw[0].T;classes=rows[:,4:].argmax(1);scores=rows[np.arange(len(rows)),classes+4];valid=(scores>=confidence)&(rows[:,2]>1)&(rows[:,3]>1);rows=rows[valid];classes=classes[valid];scores=scores[valid]
  boxes=np.column_stack(((rows[:,0]-rows[:,2]/2-left)/gain,(rows[:,1]-rows[:,3]/2-top)/gain,rows[:,2]/gain,rows[:,3]/gain));kept=[]
  if classwise:
   for c in range(10):
    ix=np.flatnonzero(classes==c)
    if len(ix):kept.extend(ix[np.asarray(cv2.dnn.NMSBoxes(boxes[ix].tolist(),scores[ix].tolist(),confidence,.45),dtype=int).reshape(-1)].tolist())
  elif len(boxes):
   ix=np.argsort(-scores)[:300];kept=ix[np.asarray(cv2.dnn.NMSBoxes(boxes[ix].tolist(),scores[ix].tolist(),confidence,self.meta['proposal_nms_iou']),dtype=int).reshape(-1)].tolist()
  limit=30 if classwise else self.meta['max_proposals'];kept=sorted(kept,key=lambda i:-scores[i])[:limit];result=[]
  for i in kept:
   x,y,bw,bh=boxes[i];box=[float(max(0,min(w,x))),float(max(0,min(h,y))),float(max(0,min(w,x+bw))),float(max(0,min(h,y+bh)))];c=int(classes[i])
   if box[2]>box[0] and box[3]>box[1]:result.append(dict(class_id=OFFSET+c,disease_id=c,name=NAMES_ZH[c],name_en=NAMES_EN[c],confidence=float(scores[i]),xyxy=box,group='tomato',source='trained-yolov8n-onnx',proposal_probabilities=[float(v) for v in rows[i,4:]]))
  return result
 def candidates(self,bgr,candidate_floor=None):
  self._load();start=time.perf_counter();props=self._yolo(bgr,self.meta['proposal_confidence'] if candidate_floor is None else candidate_floor,False)
  props=[p for p in props if min(p['xyxy'][2]-p['xyxy'][0],p['xyxy'][3]-p['xyxy'][1])>=12];yolo_done=time.perf_counter();result=[]
  for at in range(0,len(props),16):
   batch=props[at:at+16];blob=np.stack([prepare_crop(bgr,p['xyxy'],self.meta['crop_margin']) for p in batch]);self.refiner.setInput(blob);logits=self.refiner.forward()
   if logits.shape!=(len(batch),11) or not np.isfinite(logits).all():raise ValueError('叶片分类模型输出不匹配')
   exp=np.exp(logits-logits.max(1,keepdims=True));prob=exp/exp.sum(1,keepdims=True)
   for p,q in zip(batch,prob):result.append(dict(xyxy=p['xyxy'],localization_confidence=p['confidence'],class_probabilities=[float(v) for v in q],proposal_class=p['disease_id'],proposal_probabilities=p['proposal_probabilities']))
  return result,dict(yolo_ms=(yolo_done-start)*1000,leaf_classifier_ms=(time.perf_counter()-yolo_done)*1000,proposals=len(props))
 def predict(self,bgr,confidence=.4):
  started=time.perf_counter();self._load()
  if self.meta.get('pipeline')=='leaf-refiner-v3':
   candidates,timing=self.candidates(bgr);pred=select_candidates(candidates,confidence,self.meta['proposal_confidence'],self.meta['classification_margin'],self.meta['leaf_nms_iou'],self.meta['fusion_alpha'],self.meta['background_threshold'],self.meta.get('fusion_adaptive',False),self.meta.get('class_thresholds'))
  else:pred=self._yolo(bgr,confidence,True);timing={}
  total=(time.perf_counter()-started)*1000;timing.update(invoke_ms=timing.get('yolo_ms',total)+timing.get('leaf_classifier_ms',0),preprocess_ms=0.,postprocess_ms=0.,tomato_total_ms=total,tomato_model_sha256=self.sha256)
  return pred,timing
