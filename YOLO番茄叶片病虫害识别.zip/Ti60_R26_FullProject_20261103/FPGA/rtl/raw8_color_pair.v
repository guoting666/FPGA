// BGGR two-pixel color reconstruction. Each adjacent pair shares one 2x2
// Bayer neighborhood; full HDMI timing is retained, chroma resolution is lower.
module raw8_color_pair #(
 parameter LINE_WORDS=960, B_GAIN=491, G_GAIN=256, R_GAIN=418
)(input clk,rst_n,input in_vs,in_hs,in_de,input [15:0] raw_pair,
 output reg out_vs,out_hs,out_de,output reg [47:0] rgb_pair);
(* syn_ramstyle="block_ram" *) reg [15:0] line_mem[0:1023];
reg [9:0] x;
reg odd, first_line, last_de, last_vs;
reg [15:0] previous,current;
reg odd_d,first_d,vs_d,hs_d,de_d;
reg [7:0] b,r;
reg [8:0] g;
wire [7:0] b_bal,g_bal,r_bal;
function [7:0] balance;
 input [7:0] value;input [15:0] gain;
 reg [23:0] product;
 begin product=value*gain+128; balance=|product[23:16] ? 255 : product[15:8];end
endfunction
assign b_bal=balance(b,B_GAIN);
assign g_bal=balance(g[8:1],G_GAIN);
assign r_bal=balance(r,R_GAIN);
always @* begin
 if(first_d) begin b=current[15:8];r=current[15:8];g={current[7:0],1'b0};end
 else if(odd_d) begin // previous B,G; current G,R
  b=previous[15:8];r=current[7:0];g={1'b0,previous[7:0]}+{1'b0,current[15:8]};
 end else begin // previous G,R; current B,G
  b=current[15:8];r=previous[7:0];g={1'b0,current[7:0]}+{1'b0,previous[15:8]};
 end
end
always @(posedge clk) begin
 if(in_de) begin previous<=line_mem[x];line_mem[x]<=raw_pair;end
 current<=raw_pair;
 if(!rst_n) begin
  x<=0;odd<=0;first_line<=1;last_de<=0;last_vs<=0;
  odd_d<=0;first_d<=1;vs_d<=0;hs_d<=0;de_d<=0;
  out_vs<=0;out_hs<=0;out_de<=0;rgb_pair<=0;
 end else begin
  last_de<=in_de;last_vs<=in_vs;
  if(last_vs && !in_vs) begin x<=0;odd<=0;first_line<=1;end
  else if(last_de && !in_de) begin x<=0;odd<=~odd;first_line<=0;end
  else if(in_de) x<=x==LINE_WORDS-1 ? 0 : x+1'b1;
  odd_d<=odd;first_d<=first_line;vs_d<=in_vs;hs_d<=in_hs;de_d<=in_de;
  out_vs<=vs_d;out_hs<=hs_d;out_de<=de_d;
  rgb_pair<=de_d ? {b_bal,g_bal,r_bal,b_bal,g_bal,r_bal} : 48'b0;
 end
end
endmodule
