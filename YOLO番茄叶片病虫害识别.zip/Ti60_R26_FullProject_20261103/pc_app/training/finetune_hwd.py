"""Fine-tune on the actual HWD+ data linked by thawro's GitHub repository."""
import os
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL','2')
from pathlib import Path
import sys,json,hashlib,time,argparse,shutil
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from digit_common import normalize_digit
from train_digits import font_sample,negative

def main():
    pa=argparse.ArgumentParser();pa.add_argument('--hwd',type=Path,required=True);pa.add_argument('--mnist',type=Path,required=True);args=pa.parse_args()
    import tensorflow as tf
    tf.config.threading.set_intra_op_parallelism_threads(4);tf.config.threading.set_inter_op_parallelism_threads(2);tf.keras.utils.set_random_seed(2482);cv2.setNumThreads(1)
    rng=np.random.default_rng(2482);images=np.load(args.hwd/'Images28.npy',allow_pickle=False);info=np.load(args.hwd/'WriterInfo.npy',allow_pickle=False)
    assert images.shape==(13580,28,28) and info.shape==(13580,9)
    assert set(info[:,0])==set(range(10))
    writers=rng.permutation(np.unique(info[:,1]));train_ids=np.where(np.isin(info[:,1],writers[:70]))[0];val_ids=np.where(np.isin(info[:,1],writers[70:84]))[0];test_ids=np.where(np.isin(info[:,1],writers[84:]))[0]
    assert not set(train_ids)&set(test_ids) and len(train_ids)+len(val_ids)+len(test_ids)==13580
    normalized=np.stack([normalize_digit(np.clip(255-im,0,255).astype(np.uint8)) for im in images])
    out=ROOT/'model/digits';meta=json.loads((out/'metadata.json').read_text());shutil.copy2(out/'digit_cnn.tflite',out/'mnist_baseline.tflite');shutil.copy2(out/'metadata.json',out/'mnist_baseline_metadata.json')
    splits=np.load(out/'split_indices.npz',allow_pickle=False);mnist=np.load(args.mnist,allow_pickle=False);mt=rng.choice(splits['train'],20000,replace=False)
    mn=np.stack([normalize_digit(im) for im in mnist['x_train'][mt]])
    fonts=[Path('C:/Windows/Fonts')/f for f in meta['train_fonts']]
    extra=np.stack([font_sample(rng,i%10,fonts[i%len(fonts)]) for i in range(6000)])
    neg=np.stack([negative(rng) for _ in range(8000)]);vn=np.stack([negative(rng) for _ in range(1000)])
    x=np.concatenate([normalized[train_ids],mn,extra,neg]);y=np.concatenate([info[train_ids,0],mnist['y_train'][mt],np.arange(6000)%10,np.full(8000,10)])
    vx=np.concatenate([normalized[val_ids],vn]);vy=np.concatenate([info[val_ids,0],np.full(1000,10)])
    np.savez_compressed(out/'hwd_split_indices.npz',train=train_ids,validation=val_ids,test=test_ids,train_writers=writers[:70],validation_writers=writers[70:84],test_writers=writers[84:])
    # HWD+ samples are split by writer, so test handwriting never enters training.
    model=tf.keras.models.load_model(out/'best.keras');model.compile(optimizer=tf.keras.optimizers.Adam(.0003),loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),metrics=['accuracy'])
    started=time.time();history=[]
    class Progress(tf.keras.callbacks.Callback):
        def on_epoch_end(self,epoch,logs=None):
            row=dict(epoch=epoch+1,seconds=time.time()-started,**{k:float(v) for k,v in logs.items()});history.append(row);print(json.dumps(row),flush=True)
            (ROOT/'reports/hwd_training_history.json').write_text(json.dumps(history,indent=2))
    model.fit(x[...,None].astype(np.float32)/255,y,validation_data=(vx[...,None].astype(np.float32)/255,vy),epochs=8,batch_size=256,verbose=0,callbacks=[Progress(),tf.keras.callbacks.ModelCheckpoint(str(out/'hwd_best.keras'),monitor='val_loss',save_best_only=True),tf.keras.callbacks.ReduceLROnPlateau(monitor='val_loss',patience=2,factor=.5)])
    model=tf.keras.models.load_model(out/'hwd_best.keras');converter=tf.lite.TFLiteConverter.from_keras_model(model);converter.optimizations=[tf.lite.Optimize.DEFAULT];blob=converter.convert();(out/'digit_cnn.tflite').write_bytes(blob)
    meta.update(sha256=hashlib.sha256(blob).hexdigest(),source='MNIST pretraining + HWD+ writer-split fine-tuning + generated fonts/rejects',hwd_images=13580,hwd_train=len(train_ids),hwd_validation=len(val_ids),hwd_test=len(test_ids),hwd_train_writers=70,hwd_validation_writers=14,hwd_test_writers=13,hwd_finetune_epochs=8,hwd_finetune_examples=len(x),hwd_finetune_seconds=time.time()-started,requested_link_data_used=True,hwd_split='disjoint writer IDs; test never used for training or checkpoint selection')
    (out/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf8')
    provenance=json.loads((ROOT/'reports/digit_data_provenance.json').read_text(encoding='utf8'));provenance.update(used_dataset='MNIST + HWD+',hwd_source_chain=['https://github.com/thawro/yolov8-digits-detection','https://pmc.ncbi.nlm.nih.gov/articles/PMC9702948/','https://drive.google.com/drive/folders/1f2o1kjXLvcxRgtmMMuDkA2PQ5Zato4Or'],hwd_downloads=json.loads((args.hwd/'downloads.json').read_text()),requested_link_data_used=True,roboflow=dict(url='https://universe.roboflow.com/min-david-gglzp/mnist-ihqky',page_images=300,classes=list(range(10)),page_license='CC BY 4.0',downloaded=False,reason='Export was not accessible through available browser/web tools; not used for training.'))
    (ROOT/'reports/digit_data_provenance.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(meta),flush=True)
if __name__=='__main__':main()
