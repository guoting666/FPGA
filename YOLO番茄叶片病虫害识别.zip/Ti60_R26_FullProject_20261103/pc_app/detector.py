"""PC inference for the trained, three-class ShapeYOLO INT8 model."""
import hashlib
import json
import logging
import os
from pathlib import Path
import time

os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
logging.getLogger("tensorflow").setLevel(logging.ERROR)
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

NAMES = ("三角形", "矩形", "圆形")
COLORS = ((40, 212, 151), (78, 153, 255), (255, 183, 69)) + tuple((194,147,255) for _ in range(10)) + ((244,135,73),(239,189,70),(58,201,136),(225,104,112),(204,135,232),(125,166,244),(217,206,83),(112,196,192))
COLORS = COLORS + ((178,219,112),(226,154,205))
ROOT = Path(__file__).resolve().parent


def letterbox(rgb):
    height, width = rgb.shape[:2]
    ratio = min(192 / width, 192 / height)
    nw, nh = max(1, round(width * ratio)), max(1, round(height * ratio))
    left, top = (192 - nw) // 2, (192 - nh) // 2
    image = np.full((192, 192, 3), 114, np.uint8)
    image[top:top + nh, left:left + nw] = cv2.resize(
        rgb, (nw, nh), interpolation=cv2.INTER_NEAREST)
    return image, (nw / width, nh / height, left, top)


def sigmoid(x):
    return 1 / (1 + np.exp(-np.clip(x, -40, 40)))


def decode(raw, anchors, confidence, nms_iou=0.45, max_det=100):
    if raw.shape != (24, 24, 16) or not np.isfinite(raw).all():
        raise ValueError("模型输出不是有效的 24×24×16 检测头")
    pred = raw.reshape(24, 24, 2, 8)
    yy, xx = np.mgrid[:24, :24]
    grid = np.stack((xx, yy), -1).astype(np.float32)[:, :, None]
    xy = (sigmoid(pred[..., :2]) + grid) * 8
    wh = (2 * sigmoid(pred[..., 2:4])) ** 2 * np.asarray(anchors, np.float32)
    boxes = np.concatenate((xy - wh / 2, xy + wh / 2), -1).reshape(-1, 4).clip(0, 192)
    all_scores = (sigmoid(pred[..., 4:5]) * sigmoid(pred[..., 5:8])).reshape(-1, 3)
    classes = all_scores.argmax(1)
    scores = all_scores[np.arange(len(classes)), classes]
    valid = (scores >= confidence) & ((boxes[:, 2:] - boxes[:, :2]).min(1) > 0)
    boxes, scores, classes = boxes[valid], scores[valid], classes[valid]
    order = np.argsort(-scores, kind="stable")[:300]
    keep = []
    while len(order) and len(keep) < max_det:
        idx = order[0]
        keep.append(idx)
        rest = order[1:]
        intersection = np.maximum(np.minimum(boxes[idx, 2:], boxes[rest, 2:]) -
                                  np.maximum(boxes[idx, :2], boxes[rest, :2]), 0).prod(1)
        area = np.maximum(boxes[idx, 2:] - boxes[idx, :2], 0).prod()
        other_area = np.maximum(boxes[rest, 2:] - boxes[rest, :2], 0).prod(1)
        iou = intersection / (area + other_area - intersection + 1e-7)
        order = rest[~((classes[rest] == classes[idx]) & (iou > nms_iou))]
    keep = np.asarray(keep, dtype=int)
    return boxes[keep], scores[keep], classes[keep]


class Detector:
    def __init__(self, model_dir=ROOT / "model", threads=2):
        import tensorflow as tf
        model_dir = Path(model_dir)
        self.meta = json.loads((model_dir / "metadata.json").read_text(encoding="utf-8"))
        self.config = json.loads((model_dir / "runtime_config.json").read_text(encoding="utf-8"))
        model = model_dir / "shape_yolo_int8.tflite"
        self.sha256 = hashlib.sha256(model.read_bytes()).hexdigest()
        if self.sha256 != self.meta["tflite_sha256"] or self.sha256 != self.config["model_sha256"]:
            raise ValueError("模型与元数据校验失败，请恢复 model 目录的配套文件")
        self.interpreter = tf.lite.Interpreter(
            model_path=str(model), num_threads=threads,
            experimental_op_resolver_type=tf.lite.experimental.OpResolverType.BUILTIN_WITHOUT_DEFAULT_DELEGATES)
        self.interpreter.allocate_tensors()
        self.inp = self.interpreter.get_input_details()[0]
        self.out = self.interpreter.get_output_details()[0]
        for tensor, shape, scale, zero in [
            (self.inp, (1, 192, 192, 3), self.meta["input_scale"], self.meta["input_zero_point"]),
            (self.out, (1, 24, 24, 16), self.meta["output_scale"], self.meta["output_zero_point"])]:
            if tuple(tensor["shape"]) != shape or tensor["dtype"] != np.int8:
                raise ValueError("模型输入输出的尺寸或类型不匹配")
            if not np.isclose(tensor["quantization"][0], scale) or tensor["quantization"][1] != zero:
                raise ValueError("模型量化参数不匹配")
        self.font_path = next((p for p in [
            ROOT / "font.ttf", Path("C:/Windows/Fonts/simhei.ttf"),
            Path("C:/Windows/Fonts/msyh.ttc"),
            Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc")]
            if p.is_file()), None)
        if self.font_path is None:
            raise FileNotFoundError("找不到中文字体；请把中文 TTF 字体放在程序目录并命名为 font.ttf")
        self.font = ImageFont.truetype(str(self.font_path), 19)
        from digits import DigitDetector
        self.digits=DigitDetector()
        from tomato import TomatoDetector
        self.tomato=TomatoDetector(model_dir / "tomato")

    def predict(self, bgr, confidence=None):
        if confidence is None:
            confidence = self.config["confidence"]
        start = time.perf_counter()
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        image, (sx, sy, left, top) = letterbox(rgb)
        scale, zero = self.inp["quantization"]
        quantized = np.clip(np.rint(image.astype(np.float32) / 255 / scale + zero), -128, 127).astype(np.int8)
        self.interpreter.set_tensor(self.inp["index"], quantized[None])
        before_invoke = time.perf_counter()
        self.interpreter.invoke()
        after_invoke = time.perf_counter()
        scale, zero = self.out["quantization"]
        raw = (self.interpreter.get_tensor(self.out["index"])[0].astype(np.float32) - zero) * scale
        boxes, scores, classes = decode(raw, self.meta["anchors"], confidence, self.config["nms_iou"])
        h, w = bgr.shape[:2]
        boxes[:, [0, 2]] = ((boxes[:, [0, 2]] - left) / sx).clip(0, w)
        boxes[:, [1, 3]] = ((boxes[:, [1, 3]] - top) / sy).clip(0, h)
        predictions = [{"class_id": int(cls), "name": NAMES[int(cls)],
                        "confidence": float(score), "xyxy": [float(v) for v in box]}
                       for box, score, cls in zip(boxes, scores, classes)
                       if box[2] > box[0] and box[3] > box[1]]
        end = time.perf_counter()
        return predictions, {"preprocess_ms": (before_invoke - start) * 1000,
                             "invoke_ms": (after_invoke - before_invoke) * 1000,
                             "postprocess_ms": (end - after_invoke) * 1000,
                             "inference_total_ms": (end - start) * 1000}

    def annotate(self, bgr, predictions, max_width=1100):
        factor = min(1, max_width / bgr.shape[1])
        image = Image.fromarray(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB))
        if factor < 1:
            image = image.resize((round(image.width * factor), round(image.height * factor)), Image.Resampling.BILINEAR)
        draw = ImageDraw.Draw(image)
        for item in predictions:
            color = COLORS[item["class_id"]]
            x1, y1, x2, y2 = [v * factor for v in item["xyxy"]]
            points = item.get("polygon")
            if points and len(points) in (3, 4):
                points = [(px * factor, py * factor) for px, py in points]
                draw.line(points + points[:1], fill=color, width=3, joint="curve")
            else:
                draw.rectangle((x1, y1, x2, y2), outline=color, width=3)
            label = (f'{item["name"]} {item["confidence"]:.0%}' if item.get("confidence") is not None
                     else f'{item["name"]} · 轮廓')
            if item.get('group')=='digit':
                label=item['digit']  # Compact labels remain legible in a row of digits.
            bounds = draw.textbbox((0, 0), label, font=self.font)
            tw, th = bounds[2] + 14, bounds[3] - bounds[1] + 10
            tx = max(0, min(image.width - tw, x1))
            ty = max(0, min(image.height - th, y1 - th))
            draw.rectangle((tx, ty, tx + tw, ty + th), fill=(13, 25, 36), outline=color)
            draw.text((tx + 7, ty + 5 - bounds[1]), label, font=self.font, fill=color)
        return cv2.cvtColor(np.asarray(image), cv2.COLOR_RGB2BGR)
