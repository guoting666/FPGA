//=================================================================
//
//  Copyright (C) 2022 Persion All rights reserved.
//  文件名称：top.v
//  创 建 者：Ramsey Wang
//  创建日期：2022.04.01
//  描    述：led test
//
//=================================================================


module udp_test_top #(
  parameter UDP_WIDTH = 8 ,
  parameter UDP_DEPTH = 32,
  parameter UDP_PACK_NUM = 1080,
  parameter FRAME_WIDTH=1920, FRAME_HEIGHT=1080
)
(

    ////////////////////////    CLOCK & PLL     ////////////////////////
       output [63:0] debug_status, input [127:0] awb_status,input [255:0]sensor_status,
       output [2047:0] osd_boxes, output [4:0] osd_count, output osd_request,
       input osd_ack, osd_expired,
       input                rst_n,
       input                sw,
       input  [47:0]        source_mac_addr ,       //source mac address
       input  [7:0]         TTL,
       input  [31:0]        source_ip_addr,
       input  [31:0]        destination_ip_addr,
       input  [15:0]        udp_send_source_port,
       input  [15:0]        udp_send_destination_port,


       output              fifo_rd_en ,
       input               fifo_rd_valid,
       input               fifo_empty,
       input  [7:0]        fifo_rd_data,
       output              start_en,
  //ETH
   input			rxc,   
   input  [3:0]             rxd_hi_i    ,
   input  [3:0]             rxd_lo_i    ,
   input 			rx_dv_HI    ,
   input 			rx_dv_LO    ,
   output 			tx_en_o_HI  ,
   output 		       tx_en_o_LO  ,
   output                   txc_hi_o,
   output                   txc_lo_o,
   output 	  [3:0]       txd_hi_o,
   output 	  [3:0]       txd_lo_o,

  output 			  mdc_o,
   output                     mdio_o,
   output                     mdio_oe,     
   input                      mdio_i,     
   output 			  phy_rst_n
);

  

// wire   [ 7:0]   gmii_txd     ;
// wire            gmii_tx_en   ;
wire            gmii_tx_er   ;
wire            gmii_tx_clk  ;
wire            gmii_crs     ;
wire            gmii_col     ;
wire   [ 7:0]   gmii_rxd     ;
wire            gmii_rx_dv   ;
wire            gmii_rx_er   ;
wire            gmii_rx_clk  ;

wire  [31:0]    pack_total_len ;
wire            duplex_mode;     // 1 full, 0 half

assign duplex_mode = 1'b1;

wire [1:0]      speed      ;
wire            link       ;
wire            e_rx_dv    ;
wire [7:0]      e_rxd      ;
wire            e_tx_en    ;
wire [7:0]      e_txd      ;
wire            e_rst_n    ;

 wire  [7:0]       tx_ram_wr_data;
 wire              tx_ram_wr_en;
 wire              udp_ram_data_req;
 wire  [15:0]      udp_send_data_length;
 
 wire              udp_tx_req;
 wire              arp_request_req;
 wire              mac_data_valid;
 wire              mac_send_end;
 
 wire              rx_dv;
 wire [ 7:0]         udp_rec_ram_rdata ;
 wire [10:0]       udp_rec_ram_read_addr;
 wire [15:0]        udp_rec_data_length;
 wire              udp_rec_data_valid;
 
 assign udp_rec_ram_read_addr=osd_ram_addr;
wire              arp_found;
 wire              mac_not_exist;

assign phy_rst_n = 1'b1;
assign txc_hi_o = 1'b1;
assign txc_lo_o = 1'b0;



	
wire [31:0] frame_id,osd_applied_frame;wire [4:0] osd_applied_count;wire [15:0] osd_feedback_flags;
wire [31:0] osd_rejected;wire [10:0] osd_ram_addr;
osd_result_rx result_rx(.clk(gmii_rx_clk),.rst_n(e_rst_n),.rec_valid(udp_rec_data_valid),
 .rec_length(udp_rec_data_length),.ram_data(udp_rec_ram_rdata),.ram_addr(osd_ram_addr),
 .current_frame_id(frame_id),.boxes(osd_boxes),.box_count(osd_count),.result_frame_id(),.request_toggle(osd_request),
 .acknowledge_toggle(osd_ack),.display_expired(osd_expired),.applied_frame_id(osd_applied_frame),
 .applied_count(osd_applied_count),.feedback_flags(osd_feedback_flags),.rejected_packets(osd_rejected));
mac_test #(
       .UDP_WIDTH (UDP_WIDTH),
       .UDP_DEPTH (UDP_DEPTH),
       .UDP_PACK_NUM(UDP_PACK_NUM),
       .FRAME_WIDTH(FRAME_WIDTH), .FRAME_HEIGHT(FRAME_HEIGHT)
)mac_test0
(
 .debug_status(debug_status),.awb_status(awb_status),.sensor_status(sensor_status),
 .wire_frame_id(frame_id),.osd_applied_frame(osd_applied_frame),.osd_applied_count(osd_applied_count),.osd_feedback_flags(osd_feedback_flags),
 /*I*/.gmii_tx_clk        (gmii_tx_clk     ),
 /*I*/.gmii_rx_clk        (gmii_rx_clk     ),
 /*I*/.rst_n              (e_rst_n         ),
 /*I*/.sw                 (sw),
 /*I*/.pack_total_len     (pack_total_len  ),
/*O*/.start_en            (start_en),

 /*O*/.fifo_rd_en         (fifo_rd_en   ),
 /*I*/.fifo_rd_valid      (fifo_rd_valid),
 /*I*/.fifo_empty         (fifo_empty),
 /*I*/.fifo_rd_data       (fifo_rd_data ),

 /*o*/.tx_ram_wr_data              (tx_ram_wr_data        ),
 /*o*/.tx_ram_wr_en                (tx_ram_wr_en          ),
 /*i*/.udp_ram_data_req            (udp_ram_data_req      ),
 /*o*/.udp_send_data_length        (udp_send_data_length  ),
 /*o*/.udp_tx_req                  (udp_tx_req            ),
 /*o*/.arp_request_req             (arp_request_req       )       ,
 /*o*/.mac_data_valid              (mac_data_valid        ),
 /*i*/.mac_send_end                (mac_send_end          ),
 /*i*/.udp_rec_ram_rdata           (udp_rec_ram_rdata     ),
 /*o*/.udp_rec_ram_read_addr       ( ),
 /*i*/.udp_rec_data_length         (udp_rec_data_length   ),
 /*i*/.udp_rec_data_valid          (udp_rec_data_valid    ),
 /*i*/.arp_found                   (arp_found             ),
 /*i*/.mac_not_exist               (mac_not_exist         )
 
); 
reg                  gmii_rx_dv_d0 ;
reg   [7:0]          gmii_rxd_d0 ;
wire                 gmii_tx_en_tmp ;
wire   [7:0]         gmii_txd_tmp ;
wire           gmii_tx_en;
wire [7:0]     gmii_txd;


mac_top mac_top0
(
/*I*/.gmii_tx_clk                 (gmii_tx_clk)                  ,
/*I*/.gmii_rx_clk                 (gmii_rx_clk)                  ,
/*I*/.rst_n                       (e_rst_n)  ,

/*I*/.source_mac_addr             (source_mac_addr          ),//(48'h00_0a_35_01_fe_c0)   ,       //source mac address
/*I*/.TTL                         (TTL                      ),//(8'h80),
/*I*/.source_ip_addr              (source_ip_addr           ),//(32'hc0a80002),//192.168.0.2
/*I*/.destination_ip_addr         (destination_ip_addr      ),//(32'hc0a80003),//192.168.0.3
/*I*/.udp_send_source_port        (udp_send_source_port     ),//(16'h1f90),//8080
/*I*/.udp_send_destination_port   (udp_send_destination_port),//(16'h1f90),//8080

/*I*/.ram_wr_data                 (tx_ram_wr_data) ,
/*I*/.ram_wr_en                   (tx_ram_wr_en),
/*O*/.udp_ram_data_req            (udp_ram_data_req),
/*I*/.udp_send_data_length        (udp_send_data_length),

/*I*/.udp_tx_req                  (udp_tx_req),
/*I*/.arp_request_req             (arp_request_req ),

/*O*/.mac_send_end                (mac_send_end),
/*O*/.mac_data_valid              (gmii_tx_en),//(gmii_tx_en_tmp),
/*O*/.mac_tx_data                 (gmii_txd),//(gmii_txd_tmp),
//RGMII RX
/*I*/.rx_dv                       (gmii_rx_dv   ),//(gmii_rx_dv_d0   ),
/*I*/.mac_rx_datain               (gmii_rxd ),//(gmii_rxd_d0 ),

/*O*/.udp_rec_ram_rdata           (udp_rec_ram_rdata),
/*I*/.udp_rec_ram_read_addr       (udp_rec_ram_read_addr),
/*O*/.udp_rec_data_length         (udp_rec_data_length ),

/*O*/.udp_rec_data_valid          (udp_rec_data_valid),
/*O*/.arp_found                   (arp_found ),
/*O*/.mac_not_exist               (mac_not_exist )
) ;
        
//  always@(posedge gmii_tx_clk or negedge rst_n)
//   begin
//     if(rst_n == 1'b0)
//       begin
//         gmii_tx_en <= 1'b0 ;
//         gmii_txd   <= 8'd0 ;
//       end
//     else
//       begin
//         gmii_tx_en <= gmii_tx_en_tmp ;
//         gmii_txd   <= gmii_txd_tmp ;
//       end
//   end     
  
//   always@(posedge gmii_rx_clk or negedge e_rst_n)
//   begin
//     if(!e_rst_n)
//       begin
//         gmii_rx_dv_d0 <= 1'b0 ;
//         gmii_rxd_d0   <= 8'd0 ;
//       end
//     else
//       begin
//         gmii_rx_dv_d0 <= gmii_rx_dv ;
//         gmii_rxd_d0   <= gmii_rxd ;
//       end
//   end

gmii_arbi arbi_inst
(
 /*I*/.clk                (gmii_tx_clk      ),
 /*I*/.rst_n              (rst_n            ),
 /*I*/.speed              (2'b10),//(speed            ),  
 /*I*/.link               (1'b1),//(link             ), 
 /*O*/.pack_total_len     (pack_total_len   ), 
 /*O*/.e_rst_n            (e_rst_n          ),

 /*I*/.gmii_rx_dv         (gmii_rx_dv       ),
 /*I*/.gmii_rxd           (gmii_rxd         ),

 /*I*/.gmii_tx_en         (gmii_tx_en       ),
 /*I*/.gmii_txd           (gmii_txd         ), 

 /*O*/.e_rx_dv            (e_rx_dv          ),
 /*O*/.e_rxd              (e_rxd            ),
 /*O*/.e_tx_en            (e_tx_en          ),
 /*O*/.e_txd              (e_txd            )
);

reg [3:0] align_rxd_hi;
wire [3:0] align_rxd_lo;
reg       align_rx_dv_hi;
wire      align_rx_dv_lo;
always @(posedge rxc)begin
       
       
       align_rxd_hi     <= rxd_hi_i;
       align_rx_dv_hi <= rx_dv_HI;
end
assign align_rxd_lo = rxd_lo_i;
assign align_rx_dv_lo = rx_dv_LO;
util_gmii_to_rgmii util_gmii_to_rgmii_m0
(
 /*I*/.rst_n                  (rst_n           ),     
 //interface RXD
 /*i*/.rgmii_rxc              (rxc         ),
 /*i*/.rgmii_rx_hi            (align_rxd_lo),//(rxd_hi_i        ),
 /*i*/.rgmii_rx_lo            (align_rxd_hi),//(rxd_lo_i        ),
 /*i*/.rgmii_rx_dv            (align_rx_dv_lo),//(rx_dv_HI        ),
 /*i*/.rgmii_rx_er            (align_rx_dv_hi),//(rx_dv_LO        ),
 
 //interface TXD
 /*o*/.rgmii_tx_ctrl_hi       (  tx_en_o_HI    ),
 /*o*/.rgmii_tx_ctrl_lo       (  tx_en_o_LO    ),
 /*o*/.rgmii_txd_lo           (  txd_lo_o      ),
 /*o*/.rgmii_txd_hi           (  txd_hi_o      ),

 //tx
 /*I*/.gmii_txd               (e_txd           ),
 /*I*/.gmii_tx_en             (e_tx_en         ),
 /*I*/.gmii_tx_er             (1'b0            ),
 /*o*/.gmii_tx_clk            (gmii_tx_clk     ),
//rx
 /*o*/.gmii_crs               (gmii_crs        ),
 /*o*/.gmii_col               (gmii_col        ),
 /*o*/.gmii_rxd               (gmii_rxd        ),
 /*o*/.gmii_rx_dv             (gmii_rx_dv      ),
 /*o*/.gmii_rx_er             (gmii_rx_er      ),
 /*o*/.gmii_rx_clk            (gmii_rx_clk     ),
 .duplex_mode                 (duplex_mode     )
);



//==================================================================== 
//
//====================================================================


 
endmodule
