"""Before/after whole-video diagnostics with manually specified object slots.

The source contains video captions and occlusions. Two-frame confirmation and
IoU>=0.5 are used. Same-video training crops were used; this is not a blind test.
"""
from pathlib import Path
import argparse,sys,json,importlib.util,time
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from digits import DigitDetector,_iou

def truths(fid):
 if fid<=8:return {2:[197,77,335,250],7:[169,293,301,489],9:[431,272,553,492]}
 result={}
 if fid>=125:result[2]=[290,100,405,247] if fid<195 else [270,105,395,253]
 if fid>=336:result[7]=[270,290,390,460]
 if fid>=430:result[9]=[535,274,665,479]
 return result

def main():
 pa=argparse.ArgumentParser();pa.add_argument('--video',type=Path,required=True);pa.add_argument('--baseline',type=Path,required=True);a=pa.parse_args();cv2.setNumThreads(1)
 spec=importlib.util.spec_from_file_location('baseline_digits',a.baseline/'digits.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 models={'before':module.DigitDetector(a.baseline),'after':DigitDetector()};previous={k:[] for k in models};stats={k:{d:dict(present=0,correct=0,wrong=0,miss=0,wrong_as={}) for d in [2,7,9]} for k in models};cases=[];cap=cv2.VideoCapture(str(a.video));fid=0;times={k:[] for k in models};started=time.perf_counter()
 while True:
  ok,im=cap.read()
  if not ok:break
  im=cv2.resize(im,(960,555),interpolation=cv2.INTER_AREA);gt=truths(fid);row=dict(frame=fid,truth=gt)
  for name,model in models.items():
   raw,t=model.predict(im,.93);times[name].append(t['digit_total_ms']);pred=[p for p in raw if any(p['class_id']==old['class_id'] and _iou(p['xyxy'],old['xyxy'])>.45 for old in previous[name])];previous[name]=raw;local={}
   for digit,box in gt.items():
    s=stats[name][digit];s['present']+=1;matches=[p for p in pred if _iou(p['xyxy'],box)>=.5]
    if any(p['digit']==str(digit) for p in matches):s['correct']+=1;local[digit]=str(digit)
    elif matches:
     best=max(matches,key=lambda p:_iou(p['xyxy'],box));s['wrong']+=1;s['wrong_as'][best['digit']]=s['wrong_as'].get(best['digit'],0)+1;local[digit]='wrong:'+best['digit']
    else:s['miss']+=1;local[digit]='missing'
   row[name]=local
  if gt:cases.append(row)
  fid+=1
 cap.release()
 report=dict(scope='Original user video; two-frame confirmation, IoU>=0.5, manual presence intervals and approximate full-object boxes. Captions/occlusions remain included. Same-video crops were used for training, so this is repair regression rather than independent detection accuracy/mAP.',frames=fid,threshold=.93,before_model_sha256=models['before'].sha256,digit_model_sha256=models['after'].sha256,stats=stats,mean_digit_stage_ms={k:float(np.mean(v)) for k,v in times.items()},wall_seconds=time.perf_counter()-started,cases=cases)
 (ROOT/'reports/video_2789_comparison.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='cases'},indent=2))
if __name__=='__main__':main()
