from pathlib import Path
import json,hashlib,sys
root=Path(__file__).resolve().parent
j=json.loads((root/'PACKAGE_MANIFEST.json').read_text(encoding='utf8'))
bad=[]
for name,digest in j['files_sha256'].items():
 p=(root/name).resolve()
 if root not in p.parents or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:bad.append(name)
if bad:print('FAILED:',*bad,sep='\n');sys.exit(1)
print('PASS:',len(j['files_sha256']),'files verified; accepted R26 bit:',j['bit_sha256'])
