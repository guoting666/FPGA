"""Bounded T6O1 result feedback for the matching Ethernet OSD firmware."""
import math,struct
HEADER=struct.Struct('!4sBBHIHH')
RECORD=struct.Struct('!BBHHHH')
MAX_BOXES=16

def encode_results(frame_id,width,height,predictions):
    if not isinstance(frame_id,int) or not 0<=frame_id<=0xffffffff:raise ValueError('Invalid wire frame id')
    if width<=0 or height<=0:raise ValueError('Invalid source dimensions')
    records=[]
    for p in predictions:
        cls=p.get('class_id');box=p.get('xyxy')
        if not isinstance(cls,int) or not 0<=cls<=20 or not isinstance(box,(list,tuple)) or len(box)!=4:continue
        if not all(isinstance(v,(float,int)) and math.isfinite(v) for v in box):continue
        x,y,x2,y2=box
        if x2<=x or y2<=y:continue
        x=max(0,min(1919,math.floor(x*1920/width)));y=max(0,min(1079,math.floor(y*1080/height)))
        x2=max(0,min(1920,math.ceil(x2*1920/width)));y2=max(0,min(1080,math.ceil(y2*1080/height)))
        if x2<=x or y2<=y:continue
        confidence=p.get('confidence');score=0 if confidence is None else round(100*max(0,min(1,float(confidence))))
        records.append(RECORD.pack(cls,score,x,y,x2,y2))
        if len(records)==MAX_BOXES:break
    data=HEADER.pack(b'T6O1',1,len(records),18+len(records)*10,frame_id,1920,1080)+b''.join(records)
    return data+struct.pack('!H',(~sum(data))&0xffff)

def decode_results(data):
    if len(data)<18:raise ValueError('Short packet')
    magic,ver,count,length,fid,w,h=HEADER.unpack_from(data)
    if magic!=b'T6O1' or ver!=1 or count>MAX_BOXES or length!=18+10*count or len(data)!=length or (w,h)!=(1920,1080):raise ValueError('Invalid header')
    if struct.unpack_from('!H',data,len(data)-2)[0]!=(~sum(data[:-2]))&0xffff:raise ValueError('Invalid payload checksum')
    records=[]
    for i in range(count):
        c,score,x,y,x2,y2=RECORD.unpack_from(data,16+i*10)
        if c>20 or score>100 or not 0<=x<x2<=w or not 0<=y<y2<=h:raise ValueError('Invalid box')
        records.append(dict(class_id=c,confidence=score,xyxy=[x,y,x2,y2]))
    return fid,records

# Capability bit 3 in the board's T6V1 v2 header selects T6P1 feedback.
# Four cyclic vertices are native HDMI pixel coordinates (inclusive).
POLYGON_RECORD=struct.Struct('!BB8H')
def encode_polygons(frame_id,width,height,predictions):
    if not isinstance(frame_id,int) or not 0<=frame_id<=0xffffffff:raise ValueError('Invalid wire frame id')
    if width<=0 or height<=0:raise ValueError('Invalid source dimensions')
    records=[]
    for p in predictions:
        cls=p.get('class_id');box=p.get('xyxy')
        if not isinstance(cls,int) or not 0<=cls<=20 or not isinstance(box,(list,tuple)) or len(box)!=4:continue
        if not all(isinstance(v,(float,int)) and math.isfinite(v) for v in box):continue
        x,y,x2,y2=box
        if x2<=x or y2<=y:continue
        points=p.get('polygon')
        if points is not None:
            if not isinstance(points,(list,tuple)) or len(points) not in (3,4):continue
            if not all(isinstance(q,(list,tuple)) and len(q)==2 and all(isinstance(v,(int,float)) and math.isfinite(v) for v in q) for q in points):continue
            native=[(max(0,min(1919,round(px*1920/width))),max(0,min(1079,round(py*1080/height)))) for px,py in points]
            if len(native)==3:native.append(native[-1])
        else:
            a=max(0,min(1919,math.floor(x*1920/width)));b=max(0,min(1079,math.floor(y*1080/height)))
            c=max(0,min(1919,math.ceil(x2*1920/width)-1));d=max(0,min(1079,math.ceil(y2*1080/height)-1))
            if c<=a or d<=b:continue
            native=[(a,b),(c,b),(c,d),(a,d)]
        confidence=p.get('confidence');score=0 if confidence is None else round(100*max(0,min(1,float(confidence))))
        records.append(POLYGON_RECORD.pack(cls,score,*(v for q in native for v in q)))
        if len(records)==MAX_BOXES:break
    data=HEADER.pack(b'T6P1',1,len(records),18+len(records)*18,frame_id,1920,1080)+b''.join(records)
    return data+struct.pack('!H',(~sum(data))&0xffff)

def decode_polygons(data):
    if len(data)<18:raise ValueError('Short packet')
    magic,ver,count,length,fid,w,h=HEADER.unpack_from(data)
    if magic!=b'T6P1' or ver!=1 or count>16 or length!=18+18*count or len(data)!=length or (w,h)!=(1920,1080):raise ValueError('Invalid header')
    if struct.unpack_from('!H',data,len(data)-2)[0]!=(~sum(data[:-2]))&0xffff:raise ValueError('Invalid payload checksum')
    records=[]
    for i in range(count):
        c,score,*xy=POLYGON_RECORD.unpack_from(data,16+i*18)
        if c>20 or score>100 or any(v>= (w if j%2==0 else h) for j,v in enumerate(xy)):raise ValueError('Invalid polygon')
        records.append(dict(class_id=c,confidence=score,polygon=[xy[j:j+2] for j in range(0,8,2)]))
    return fid,records
