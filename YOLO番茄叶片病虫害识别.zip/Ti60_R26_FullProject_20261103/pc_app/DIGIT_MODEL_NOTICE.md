# 数字数据与模型说明

本次编写的训练、定位、归一化和整合代码未复制执行用户链接仓库的训练代码。数字模型是自训的 DigitCNN_Reject_v1；图形模型来源继续见 MODEL_NOTICE.md。

HWD+：Cédric Beaulac 与 Jeffrey S. Rosenthal，Introducing a New High-Resolution Handwritten Digits Data Set with Writer Characteristics，doi:10.1007/s42979-022-01494-2。来源链为用户提供 GitHub 的 README → 原论文 → 作者 Google Drive。原数据与随附说明的权利归原作者，本地使用数据并不转让原作者权利。本次未将论文页面版权条款误当成数据集的开放许可证。

MNIST：Yann LeCun、Corinna Cortes、Christopher J. C. Burges。经 TensorFlow 官方镜像下载。所用 Keras 数据加载器注明原数据为 CC BY-SA 3.0；具体数据权利以原发布方条款为准。参考 https://www.tensorflow.org/api_docs/python/tf/keras/datasets/mnist/load_data 。

字体样本由本机 Windows 字体渲染，原字体文件未随包复制。新增衬线/装饰字体和明暗变化训练，覆盖分离的手写与印刷数字；不保证任意艺术字体。用户金色数字截图仅用于回归，没有放入训练。非数字负例包括几何形状、字母及随机笔画。

Roboflow min-david-gglzp/mnist-ihqky 页面显示 CC BY 4.0，本次未下载、未训练使用。thawro 仓库没有 LICENSE 文件，未将它的 ONNX 权重当成可随意再分发的权重；本次数字部署文件由本地训练导出。

2026-10-24 立体 1/9 修复：经用户提供的本地视频人工确认并提取 1 和 9 两个前景，用于本地困难样本微调。来源与裁剪包含在 tests/fixtures/clay。该视频的回归指标不是独立测试；MNIST 和 HWD+ 测试图未进入训练。

2026-10-24 立体 2/7/9 修复：用户开发视频增加十个立体数字、四个玩具车拒识前景及三个字幕/UI遮挡后的数字前景，并重放此前1/9样本。标注与来源见 tests/fixtures/clay_all/source.json。视频数据参与微调，所以所有同视频回归均不是独立测试。公开测试划分继续排除在训练及检查点选择之外。
