"""V36 saved color controls, Q14 arithmetic and original 512-entry gamma LUT."""
from pathlib import Path
import json
import cv2,numpy as np
ROOT=Path(__file__).parent
PROFILE=json.loads((ROOT/'v36_color_profile.json').read_text(encoding='utf8'))
CFG=PROFILE['config']
GAMMA=np.asarray(json.loads((ROOT/'v36_gamma_lut.json').read_text()),np.uint8)

def apply_rgb(bgr,wb=None,color_bank=None):
    # V36 WB retains one fractional bit before the gamma lookup.
    rgb=np.asarray(bgr,np.int64)[...,::-1]
    k=np.minimum((rgb*np.asarray(CFG['wb'] if wb is None else wb,np.int64)+4096)>>13,511)
    rgb=GAMMA[k].astype(np.int64) if CFG['gamma'] else k>>1
    if not CFG['flags']&1:
        values=CFG['matrix'] if color_bank is None else PROFILE.get('matrix_banks',{}).get(str(color_bank),CFG['matrix'])
        matrix=np.asarray(values,np.int64).reshape(3,3)
        rgb=np.clip((rgb@matrix.T+8192)>>14,0,255)
    if not CFG['flags']&2:
        y=(rgb@np.array([77,150,29],np.int64)+128)>>8
        s=np.where(y<=32,CFG['low'],np.where(y>=96,CFG['sat'],CFG['low']+(((CFG['sat']-CFG['low'])*(y-32)+32)>>6)))
        d=rgb-y[...,None];amount=(np.abs(d)*s[...,None]+8192)>>14
        rgb=np.clip(y[...,None]+np.where(d<0,-amount,amount),0,255)
    return rgb[...,::-1].astype(np.uint8)

def decode_bayer(raw,code,wb=None,color_bank=None):
    # Black subtraction precedes demosaicing, just as in the reference ISP.
    raw=np.maximum(np.asarray(raw,np.int16)-CFG['black'],0).astype(np.uint8)
    return apply_rgb(cv2.cvtColor(raw,code),wb,color_bank)
