"""Full-image font stress test, with families excluded from model fitting.

Synthetic renders measure a limited domain; this is not a camera benchmark.
The user's gold image is a separate regression fixture used for debugging.
"""
from pathlib import Path
import sys,json,time
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from digits import DigitDetector,_iou
from finetune_print import glyph,TEST_FONTS

def scenes():
 rng=np.random.default_rng(10598)
 for font in TEST_FONTS:
  for style in range(6):
   yy,xx=np.indices((360,640));bg=(225+22*((xx//12+yy//12)%2)).astype(np.uint8) if style>=2 else np.full((360,640),235 if style==0 else 20,np.uint8)
   im=np.repeat(bg[:,:,None],3,axis=2);truth=[]
   for k in range(10):
    alpha=glyph(rng,str(k),font,augment=False);alpha=cv2.resize(alpha,(112,112),interpolation=cv2.INTER_LINEAR).astype(float)/255
    color=(20,20,20) if style==0 else (240,240,240) if style==1 else tuple(int(v) for v in cv2.cvtColor(np.uint8([[[25 if style==2 else int(rng.integers(180)),220,245]]]),cv2.COLOR_HSV2BGR)[0,0])
    x=13+(k%5)*126;y=24+(k//5)*168
    if style==4:alpha=cv2.GaussianBlur(alpha,(5,5),.9)
    shade=(.8+.2*np.sin(np.arange(112)/8)[None,:,None]) if style==3 else 1
    patch=im[y:y+112,x:x+112];im[y:y+112,x:x+112]=np.clip(patch*(1-alpha[:,:,None])+np.array(color)*shade*alpha[:,:,None],0,255).astype(np.uint8)
    ys,xs=np.where(alpha>.2);truth.append((str(k),[x+int(xs.min()),y+int(ys.min()),x+int(xs.max())+1,y+int(ys.max())+1]))
   if style==5:
    ok,encoded=cv2.imencode('.jpg',im,[cv2.IMWRITE_JPEG_QUALITY,65]);assert ok;im=cv2.imdecode(encoded,1)
   yield font,style,im,truth

def main():
 cv2.setNumThreads(1);d=DigitDetector();cases=[];tp=fp=gt=0;times=[]
 for font,style,im,truth in scenes():
  pred,t=d.predict(im);matched=set();good=0;bad=0
  for p in pred:
   options=[(i,_iou(p['xyxy'],b)) for i,(n,b) in enumerate(truth) if i not in matched and n==p['digit']]
   if options:
    i,overlap=max(options,key=lambda r:r[1])
    if overlap>=.5:matched.add(i);good+=1;continue
   bad+=1
  tp+=good;fp+=bad;gt+=len(truth);times.append(t['digit_total_ms'])
  cases.append(dict(font=font,style=style,correct=good,false_positives=bad,digits=[p['digit'] for p in pred]))
 report=dict(scope='36 controlled synthetic scenes, six font families excluded from training/checkpoint selection, 360 digits. Styles: dark/light ink, gold/random colors on checkerboard, shading, blur, JPEG. Inspected during proposal/NMS tuning, not blind evaluation, real-camera accuracy or mAP.',used_for_postprocessing_tuning=True,families=TEST_FONTS,images=len(cases),ground_truth_digits=gt,true_positives=tp,false_positives=fp,precision=tp/max(tp+fp,1),recall=tp/gt,mean_digit_stage_ms=float(np.mean(times)),threshold=.93,digit_model_sha256=d.sha256,cases=cases)
 (ROOT/'reports/print_detection_evaluation.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='cases'},indent=2))
if __name__=='__main__':main()
