//============================================================================
// Module: axis_dly
// Description: AXI4-Stream delay module with parameterizable delay cycles
//              Delays all AXI Stream signals (tdata, tvalid, tlast, tuser) 
//              by a configurable number of clock cycles
//              Properly handles backpressure through the pipeline
// Author: Auto Generated
//============================================================================

module axis_dly #(
    parameter DATA_WIDTH = 64,           // AXI Stream data width
    parameter DELAY_CYCLES = 4           // Number of delay cycles (pipeline stages)
)(
    input  wire                         clk,
    input  wire                         rst_n,
    
    // AXI Stream Slave (input)
    input  wire [DATA_WIDTH-1:0]        s_axis_tdata,
    input  wire                         s_axis_tvalid,
    output wire                         s_axis_tready,
    input  wire                         s_axis_tlast,
    input  wire                         s_axis_tuser,
    
    // AXI Stream Master (output)
    output reg  [DATA_WIDTH-1:0]        m_axis_tdata,
    output reg                          m_axis_tvalid,
    input  wire                         m_axis_tready,
    output reg                          m_axis_tlast,
    output reg                          m_axis_tuser
);

    //------------------------------------------------------------------------
    // Pipeline control
    //------------------------------------------------------------------------
    
    // Pipeline can advance when output is ready or not valid
    wire pipe_advance;
    assign pipe_advance = m_axis_tready || !m_axis_tvalid;
    
    //------------------------------------------------------------------------
    // Forward pipeline: tdata, tvalid, tlast, tuser
    //------------------------------------------------------------------------
    
    generate
        if (DELAY_CYCLES > 0) begin
            // Internal pipeline registers
            reg [DATA_WIDTH-1:0] tdata_pipe [0:DELAY_CYCLES-1];
            reg [DELAY_CYCLES-1:0] tvalid_pipe;
            reg [DELAY_CYCLES-1:0] tlast_pipe;
            reg [DELAY_CYCLES-1:0] tuser_pipe;
            
            integer i;
            always @(posedge clk or negedge rst_n) begin
                if (!rst_n) begin
                    // Reset all pipeline stages
                    for (i = 0; i < DELAY_CYCLES; i = i + 1) begin
                        tdata_pipe[i] <= {DATA_WIDTH{1'b0}};
                    end
                    tvalid_pipe <= {DELAY_CYCLES{1'b0}};
                    tlast_pipe  <= {DELAY_CYCLES{1'b0}};
                    tuser_pipe  <= {DELAY_CYCLES{1'b0}};
                end else begin
                    if (pipe_advance) begin
                        // Shift pipeline forward
                        tdata_pipe[0] <= s_axis_tdata;
                        for (i = 1; i < DELAY_CYCLES; i = i + 1) begin
                            tdata_pipe[i] <= tdata_pipe[i-1];
                        end
                        
                        // Handle different delay cycle cases
                        if (DELAY_CYCLES == 1) begin
                            // Single stage: direct assignment
                            tvalid_pipe <= s_axis_tvalid;
                            tlast_pipe  <= s_axis_tlast;
                            tuser_pipe  <= s_axis_tuser;
                        end else begin
                            // Multiple stages: shift and append
                            tvalid_pipe <= {tvalid_pipe[DELAY_CYCLES-2:0], s_axis_tvalid};
                            tlast_pipe  <= {tlast_pipe[DELAY_CYCLES-2:0], s_axis_tlast};
                            tuser_pipe  <= {tuser_pipe[DELAY_CYCLES-2:0], s_axis_tuser};
                        end
                    end
                end
            end
            
            // Output from last pipeline stage
            always @(posedge clk or negedge rst_n) begin
                if (!rst_n) begin
                    m_axis_tdata  <= {DATA_WIDTH{1'b0}};
                    m_axis_tvalid <= 1'b0;
                    m_axis_tlast  <= 1'b0;
                    m_axis_tuser  <= 1'b0;
                end else if (pipe_advance) begin
                    m_axis_tdata  <= tdata_pipe[DELAY_CYCLES-1];
                    m_axis_tvalid <= tvalid_pipe[DELAY_CYCLES-1];
                    m_axis_tlast  <= tlast_pipe[DELAY_CYCLES-1];
                    m_axis_tuser  <= tuser_pipe[DELAY_CYCLES-1];
                end
            end
            
            // Input ready: ready when pipeline can accept (output ready or not valid)
            assign s_axis_tready = pipe_advance;
        end else begin
            // Zero delay: true pass-through (combinational, no clock delay)
            always @(*) begin
                m_axis_tdata  = s_axis_tdata;
                m_axis_tvalid = s_axis_tvalid;
                m_axis_tlast  = s_axis_tlast;
                m_axis_tuser  = s_axis_tuser;
            end
            assign s_axis_tready = m_axis_tready;
        end
    endgenerate

endmodule
