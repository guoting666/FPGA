`timescale 1ns/1ps
// Gray-world AWB, G reference, after demosaic and before WB/gamma.
// Algorithm reference: supplied report pp.29-30 and uiisp_ph1a/awb2.v.
// Portable Ti60 implementation: one time-shared serial divider, no image RAM.
// RGB planes contain two pixels (low/high byte). Statistics gates must match
// the RGB data, already aligned at _3P by the current raw_to_rgb.
module awb_gray_world_2px #(
    parameter integer MIN_WORDS=1024,
    parameter integer GRAY_GATE=0
)(
    input clk,rstn,enable,hold,vs,de,
    input [15:0] r,g,b,
    input [15:0] manual_r,manual_g,manual_b,
    output [15:0] gain_r,gain_g,gain_b,
    output [127:0] status
);
localparam [15:0] GAIN_MIN=16'd6554, GAIN_MAX=16'd40960;
reg vs_d,mode_active,have_solution,pending_result,rejected,limited;
reg frame_seen,overflow;
wire sync_rise=vs&&!vs_d, sync_fall=!vs&&vs_d;
reg [28:0] sum_r,sum_g,sum_b;
reg [20:0] words;
wire [8:0] pair_r={1'b0,r[7:0]}+{1'b0,r[15:8]};
wire [8:0] pair_g={1'b0,g[7:0]}+{1'b0,g[15:8]};
wire [8:0] pair_b={1'b0,b[7:0]}+{1'b0,b[15:8]};
wire [29:0] add_r={1'b0,sum_r}+{21'b0,pair_r};
wire [29:0] add_g={1'b0,sum_g}+{21'b0,pair_g};
wire [29:0] add_b={1'b0,sum_b}+{21'b0,pair_b};
wire [28:0] minimum_sum={5'b0,words,3'b0}; // channel mean >= 4
// R21: optional neutral-pixel statistics. Keep the V36 divider, smoothing,
// frame-boundary commit and telemetry. A colored/dark frame with insufficient
// neutral samples is rejected and retains the last valid white balance.
// Comparisons use full Q14 products; no clipping/rounding in sample selection.
function neutral;
    input [7:0] rr,gg,bb;
    input [15:0] gr,ggain,gb;
    reg [23:0] sr,sg,sb,hi,lo;
    begin
        sr=rr*gr;sg=gg*ggain;sb=bb*gb;
        hi=(sr>sg)?sr:sg;hi=(hi>sb)?hi:sb;
        lo=(sr<sg)?sr:sg;lo=(lo<sb)?lo:sb;
        neutral=(hi>=24'd262144)&&(hi<24'd3768320)&&((hi-lo)<=(hi>>3));
    end
endfunction
wire neutral_pair=neutral(r[7:0],g[7:0],b[7:0],gain_r,gain_g,gain_b)&&
                  neutral(r[15:8],g[15:8],b[15:8],gain_r,gain_g,gain_b);
reg [15:0] active_r,active_g,active_b,target_r,target_b,red_result;
reg [15:0] updates,rejects;
reg [1:0] phase; // 0=idle, 1=red divide, 2=blue divide
reg [5:0] bit_count;
reg [44:0] dividend,numerator_hold;
reg [28:0] divisor,blue_divisor;
reg [29:0] remainder;
wire [29:0] trial={remainder[28:0],dividend[44]};
// Share subtraction and its borrow flag; exact same unsigned result.
wire [30:0] difference={1'b0,trial}-{2'b0,divisor};
wire subtract_ok=!difference[30];
wire [44:0] quotient_next={dividend[43:0],subtract_ok};
wire [29:0] remainder_next=subtract_ok?difference[29:0]:trial;
wire quotient_limited=(|quotient_next[44:16]) || quotient_next[15:0]>GAIN_MAX || quotient_next[15:0]<GAIN_MIN;
function [15:0] clamp_gain;
    input [44:0] value;
    begin
        if((|value[44:16])||value[15:0]>GAIN_MAX)clamp_gain=GAIN_MAX;
        else if(value[15:0]<GAIN_MIN)clamp_gain=GAIN_MIN;
        else clamp_gain=value[15:0];
    end
endfunction
function [15:0] smooth_gain;
    input [15:0] old_gain,new_gain;
    reg [17:0] weighted;
    begin
        weighted={old_gain,1'b0}+{2'b0,old_gain}+{2'b0,new_gain}+18'd2;
        smooth_gain=weighted[17:2]; // 3/4 old + 1/4 new, rounded
    end
endfunction
assign gain_r=mode_active?active_r:manual_r;
assign gain_g=mode_active?active_g:manual_g;
assign gain_b=mode_active?active_b:manual_b;
// 16-byte AWB1 payload, v1. Remaining 16 UART payload bytes are reserved.
assign status={rejects,updates,target_b,target_r,gain_b,gain_g,gain_r,
    3'b0,limited,rejected,(phase!=0),(mode_active&&have_solution),mode_active,8'd1};
// Positive VS is the blanking pulse from cvo_axi, while DE marks pixels.
// Snapshot the completed frame on VS rise. Divide during blanking and commit
// only on VS fall. A too-short blanking pulse defers a result to a later VS fall.
always @(posedge clk or negedge rstn)begin
    if(!rstn)begin
        vs_d<=0;mode_active<=0;have_solution<=0;pending_result<=0;
        rejected<=0;limited<=0;frame_seen<=0;overflow<=0;
        sum_r<=0;sum_g<=0;sum_b<=0;words<=0;
        active_r<=16384;active_g<=16384;active_b<=16384;
        target_r<=16384;target_b<=16384;red_result<=16384;
        updates<=0;rejects<=0;phase<=0;bit_count<=0;
        dividend<=0;numerator_hold<=0;divisor<=0;blue_divisor<=0;remainder<=0;
    end else begin
        vs_d<=vs;
        if(hold)begin
            // Retain actual gains throughout A/B; restart complete statistics.
            frame_seen<=0;phase<=0;pending_result<=0;
        end else if(sync_rise)begin
            mode_active<=enable;frame_seen<=enable;overflow<=0;
            sum_r<=0;sum_g<=0;sum_b<=0;words<=0;
            if(!enable||!mode_active||manual_g!=active_g)begin
                active_r<=manual_r;active_g<=manual_g;active_b<=manual_b;
                have_solution<=0;pending_result<=0;phase<=0;rejected<=0;limited<=0;
            end else if(frame_seen)begin
                if(!overflow&&words>=MIN_WORDS&&sum_r>=minimum_sum&&sum_g>=minimum_sum&&sum_b>=minimum_sum&&phase==0&&!pending_result)begin
                    dividend<=sum_g*active_g;numerator_hold<=sum_g*active_g;
                    divisor<=sum_r;blue_divisor<=sum_b;
                    remainder<=0;bit_count<=44;phase<=1;rejected<=0;limited<=0;
                end else begin rejected<=1;rejects<=rejects+1'b1;end
            end
        end else begin
            if(mode_active&&!vs&&de&&frame_seen&&(!GRAY_GATE||neutral_pair))begin
                sum_r<=add_r[28:0];sum_g<=add_g[28:0];sum_b<=add_b[28:0];
                words<=words+1'b1;
                if(add_r[29]||add_g[29]||add_b[29]||(&words))overflow<=1;
            end
            if(sync_fall&&pending_result)begin
                active_r<=have_solution?smooth_gain(active_r,target_r):target_r;
                active_b<=have_solution?smooth_gain(active_b,target_b):target_b;
                have_solution<=1;pending_result<=0;updates<=updates+1'b1;
            end
            if(phase!=0)begin
                dividend<=quotient_next;remainder<=remainder_next;
                if(bit_count!=0)bit_count<=bit_count-1'b1;
                else if(phase==1)begin
                    red_result<=clamp_gain(quotient_next);limited<=quotient_limited;
                    dividend<=numerator_hold;divisor<=blue_divisor;
                    remainder<=0;bit_count<=44;phase<=2;
                end else begin
                    target_r<=red_result;target_b<=clamp_gain(quotient_next);
                    limited<=limited||quotient_limited;pending_result<=1;phase<=0;
                end
            end
        end
    end
end
endmodule
