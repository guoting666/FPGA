"""Actual final model + HTTP upload/settings/save + localhost UDP, no board."""
from pathlib import Path
from http.server import ThreadingHTTPServer
from urllib.request import Request,urlopen
import sys,tempfile,json,threading,time,socket
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app import Application,make_handler
from detector import Detector
from udp_video import packetize,JPEG,HEADER,OSD_EXTENSION
from hdmi_feedback import decode_polygons

def wait(fn,seconds=12):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  value=fn()
  if value:return value
  time.sleep(.03)
 raise AssertionError('Timed out waiting for app result')

def main():
 cv2.setNumThreads(1);det=Detector();assert det.tomato.state()['ready'];checks=[]
 # A positive example is chosen only for exercising feedback; this is not an
 # accuracy benchmark. Separate accuracy reports cover the frozen350-image and99-image evaluations.
 positive=None
 for path in sorted((ROOT/'samples').glob('tomato_example_*.jpg')):
  im=cv2.imread(str(path))
  if any(p['class_id']<=20 for p in det.tomato.predict(im,.25)[0]):positive=path;break
 assert positive is not None,'Final model found no leaf in any fixed example'
 with tempfile.TemporaryDirectory(prefix='tomato_app_') as tmp:
  app=Application(det,tmp);server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(app));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  base='http://127.0.0.1:'+str(server.server_port)
  def post(route,body,raw=False):
   req=Request(base+route,data=body if raw else json.dumps(body).encode(),method='POST',headers={'Origin':base,'Content-Type':'application/octet-stream' if raw else 'application/json'})
   with urlopen(req,timeout=25) as response:return json.load(response)
  def frame():
   p=app.frame('')
   if p is None and app.state()['error']:raise AssertionError(app.state()['error'])
   return p
  try:
   uploaded=post('/api/upload?name=leaf.jpg',positive.read_bytes(),True)
   state=post('/api/start',dict(kind='upload',upload_id=uploaded['upload_id'],targets='tomato',tomato_confidence=.25,skip=1));first=wait(frame)
   assert state['app_id']=='Ti60_Ethernet_ShapeDigitsTomato_R11' and first['predictions'] and all(p['group']=='tomato' and 13<=p['class_id']<=22 for p in first['predictions'])
   checks.append('HTTP upload -> actual final ONNX -> Chinese leaf predictions')
   saved=post('/api/save',{});folder=Path(saved['saved_to']);record=json.loads((folder/'result.json').read_text(encoding='utf8'))
   assert record['predictions']==first['predictions'] and record['tomato_model']['sha256']==det.tomato.sha256
   assert np.array_equal(cv2.imread(str(folder/'original.png')),cv2.imread(str(positive)))
   assert (folder/'detection.jpg').is_file() and record['synthetic'] is False and record['dataset_demo'] is False
   checks.append('Original, annotated image, settings and exact model hash saved as a pair')
   newer=post('/api/settings',dict(targets='tomato',tomato_confidence=.99,skip=1));high=wait(frame)
   assert newer['session_id']>first['session_id'] and high['session_id']==newer['session_id'] and all(p['confidence']>=.99 for p in high['predictions'])
   old=post('/api/settings',dict(targets='both',skip=1));legacy=wait(frame);assert legacy['targets']=='both' and all(p['class_id']<13 for p in legacy['predictions'])
   post('/api/settings',dict(targets='tomato',tomato_confidence=.25,skip=1));leaf=wait(frame);assert leaf['targets']=='tomato'
   checks.append('Changing threshold or switching tasks reruns same still image and clears previous task results')
   post('/api/start',dict(kind='demo',targets='tomato',tomato_confidence=.25,skip=1));wait(frame)
   assert Path(app.session.source).name=='tomato_demo.avi'
   post('/api/settings',dict(targets='both',skip=1));wait(frame);assert Path(app.session.source).name=='digits_demo.avi'
   checks.append('Demo task switching selects correct leaf or shape/digit video')
   post('/api/stop',{})
   board=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);board.bind(('127.0.0.2',0));board.settimeout(.12);port=board.getsockname()[1]
   try:
    post('/api/start',dict(kind='udp',bind_ip='127.0.0.1',source_ip='127.0.0.2',port=port,delivery='stream',targets='tomato',tomato_confidence=.25,skip=1))
    wait(lambda:app.session.receiver)
    image=cv2.imread(str(positive));received=[]
    for fid in range(1,9):
     flags=25 if fid<=4 else 9
     for i,p in enumerate(packetize(image,fid,JPEG)):
      h=list(HEADER.unpack_from(p));h[1]=2;h[3]=40
      board.sendto(HEADER.pack(*h)+OSD_EXTENSION.pack(max(0,fid-1),0,flags,b'T6O2')+p[28:],('127.0.0.1',port))
      if i%16==15:time.sleep(.001)
     end=time.monotonic()+.8
     while time.monotonic()<end:
      try:data,_=board.recvfrom(2048);received.append(decode_polygons(data))
      except socket.timeout:pass
    assert any(1<=f<=4 and rows and all(13<=r['class_id']<=20 for r in rows) for f,rows in received),received
    assert any(5<=f<=8 and rows==[] for f,rows in received),received
    assert all(1<=f<=8 for f,rows in received)
    checks.append('Real localhost UDP -> actual final leaf model -> native HDMI coordinates and matching frame ID; old firmware receives empty leaf feedback')
    wait(lambda:app.state()['phase']=='waiting');assert app.frame('') is None
    checks.append('Stream timeout clears old leaf image/results; stop releases UDP socket')
   finally:app.stop();board.close()
  finally:app.stop();server.shutdown();server.server_close();thread.join(timeout=3)
 report=dict(passed=True,checks=checks,count=len(checks),onnx_sha256=det.tomato.sha256,scope='Final model actual HTTP and real localhost UDP endpoints; no physical board or HDMI verification')
 (ROOT/'reports/tomato_app_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print('TOMATO_APP_PASS',flush=True)
if __name__=='__main__':main()
