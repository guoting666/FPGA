"""Source-group-disjoint MobileNet leaf crop classifier with background rejection."""
from pathlib import Path
import os,time,json,hashlib,csv,math,random,copy
R=Path(__file__).resolve().parent;B=R.parent/'tomato_feature'
os.environ['TORCH_HOME']=str(R/'assets');os.environ['OMP_NUM_THREADS']='4';os.environ['MKL_NUM_THREADS']='4'
import cv2,numpy as np,torch,requests
from torch import nn
from torch.utils.data import Dataset,DataLoader,WeightedRandomSampler
from torchvision.models import mobilenet_v3_large,MobileNet_V3_Large_Weights
cv2.setNumThreads(1);torch.set_num_threads(4);torch.manual_seed(20261025);np.random.seed(20261025);random.seed(20261025)
(R/'assets').mkdir(exist_ok=True);started=time.time()
def progress(**x):
 x.update(elapsed_seconds=round(time.time()-started,1));p=R/'refiner_progress.json';tmp=p.with_suffix('.json.tmp');tmp.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf8');tmp.replace(p)
def crop_input(image,box,margin=.08):
 h,w=image.shape[:2];x1,y1,x2,y2=box;dx=(x2-x1)*margin;dy=(y2-y1)*margin
 x1=max(0,int(math.floor(x1-dx)));y1=max(0,int(math.floor(y1-dy)));x2=min(w,int(math.ceil(x2+dx)));y2=min(h,int(math.ceil(y2+dy)))
 crop=image[y1:y2,x1:x2];ch,cw=crop.shape[:2];g=min(224/cw,224/ch);nw,nh=round(cw*g),round(ch*g)
 canvas=np.full((224,224,3),114,np.uint8);left=(224-nw)//2;top=(224-nh)//2;canvas[top:top+nh,left:left+nw]=cv2.resize(crop,(nw,nh))
 x=canvas[:,:,::-1].astype(np.float32)/255.;x=(x-[.485,.456,.406])/[.229,.224,.225]
 return x.transpose(2,0,1).astype(np.float32)
def make_rows():
 audit=json.loads((B/'split_audit.json').read_text(encoding='utf8'));rows=[];rng=np.random.default_rng(20261025)
 for record in audit['records']:
  if record['split'] not in ['train','val']:continue
  p=B/'data/grouped_dataset'/record['path'];im=cv2.imread(str(p));h,w=im.shape[:2];boxes=[]
  for i,line in enumerate((p.parent.parent/'labels'/(p.stem+'.txt')).read_text().splitlines()):
   c,x,y,bw,bh=map(float,line.split());box=np.array([x-bw/2,y-bh/2,x+bw/2,y+bh/2])*[w,h,w,h];boxes.append(box)
   if min(box[2:]-box[:2])>=12:rows.append(dict(path=str(p),box=box.tolist(),label=int(c),split=record['split'],group=record['group'],annotation=i))
  # Background is an unannotated crop with <0.5% intersection with every GT.
  for _ in range(25):
   bw=float(rng.uniform(.12,.45)*w);bh=float(rng.uniform(.12,.45)*h);x=float(rng.uniform(0,w-bw));y=float(rng.uniform(0,h-bh));box=np.array([x,y,x+bw,y+bh])
   if all(np.maximum(0,np.minimum(box[2:],b[2:])-np.maximum(box[:2],b[:2])).prod()/(bw*bh)<.005 for b in boxes):
    rows.append(dict(path=str(p),box=box.tolist(),label=8,split=record['split'],group=record['group'],annotation='weak_background'));break
 return rows
class Crops(Dataset):
 def __init__(self,rows):self.rows=rows
 def __len__(self):return len(self.rows)
 def __getitem__(self,i):
  r=self.rows[i];im=cv2.imread(r['path']);return torch.from_numpy(crop_input(im,r['box'],0 if r['label']==8 else .08))
class Cached(Dataset):
 def __init__(self,path,rows,train):self.x=np.load(path,mmap_mode='r');self.y=np.array([r['label'] for r in rows]);self.train=train
 def __len__(self):return len(self.y)
 def __getitem__(self,i):
  x=torch.from_numpy(np.array(self.x[i],dtype=np.float32))
  if self.train and torch.rand(())<.5:x=x.flip(-1)
  return x,int(self.y[i])
def metrics(cm):
 tp=np.diag(cm);den=cm.sum(0)+cm.sum(1);f1=2*tp/np.maximum(den,1)
 return dict(macro_f1=float(f1[:8].mean()),accuracy=float(tp.sum()/max(1,cm.sum())),per_class_f1=f1.tolist(),confusion_matrix=cm.tolist())
def main():
 url=MobileNet_V3_Large_Weights.IMAGENET1K_V2.url;path=R/'assets/mobilenet_v3_large_imagenet_v2.pth'
 if not path.exists():
  response=requests.get(url,timeout=(20,120));response.raise_for_status();path.write_bytes(response.content)
 digest=hashlib.sha256(path.read_bytes()).hexdigest();assert digest.startswith(Path(url).stem.split('-')[-1])
 (R/'pretrained_source.json').write_text(json.dumps(dict(url=url,sha256=digest,scope='Official TorchVision ImageNet initialization, not a disease model'),indent=2),encoding='utf8')
 net=mobilenet_v3_large(weights=None);net.load_state_dict(torch.load(path,map_location='cpu',weights_only=True));net.classifier[-1]=nn.Linear(1280,9)
 prefix=net.features[:13].eval();tail=nn.Sequential(net.features[13:],net.avgpool,nn.Flatten(),net.classifier)
 for p in prefix.parameters():p.requires_grad=False
 rows_path=R/'crop_records.json'
 rows=json.loads(rows_path.read_text()) if rows_path.exists() else make_rows();rows_path.write_text(json.dumps(rows,ensure_ascii=False),encoding='utf8')
 split_rows={k:[r for r in rows if r['split']==k] for k in ['train','val']}
 assert not ({r['group'] for r in split_rows['train']}&{r['group'] for r in split_rows['val']})
 for split,items in split_rows.items():
  cache=R/(split+'_prefix.npy')
  marker=R/(split+'_prefix.complete.json')
  if not cache.exists() or not marker.exists():
   arr=np.lib.format.open_memmap(cache,mode='w+',dtype=np.float16,shape=(len(items),112,14,14));at=0
   with torch.inference_mode():
    for batch in DataLoader(Crops(items),batch_size=32,shuffle=False,num_workers=0):
     f=prefix(batch).numpy().astype(np.float16);arr[at:at+len(f)]=f;at+=len(f)
     progress(phase='extracting',split=split,completed=at,total=len(items))
   arr.flush();assert at==len(items);marker.write_text(json.dumps(dict(complete=True,rows=at)),encoding='utf8')
 train=Cached(R/'train_prefix.npy',split_rows['train'],True);val=Cached(R/'val_prefix.npy',split_rows['val'],False)
 count=np.bincount(train.y,minlength=9);weights=(1/np.sqrt(np.maximum(count,1)))[train.y];sampler=WeightedRandomSampler(torch.from_numpy(weights),len(train),replacement=True)
 trainloader=DataLoader(train,batch_size=64,sampler=sampler,num_workers=0);valloader=DataLoader(val,batch_size=64,num_workers=0)
 optimizer=torch.optim.AdamW([dict(params=tail[0].parameters(),lr=.00008),dict(params=tail[3].parameters(),lr=.001)],weight_decay=.01)
 loss_fn=nn.CrossEntropyLoss(label_smoothing=.03);best=-1;best_epoch=0;history=[]
 for epoch in range(24):
  tail.train();total=0.;seen=0
  factor=.1+.9*(1+math.cos(math.pi*epoch/24))/2
  for g,base in zip(optimizer.param_groups,[.00008,.001]):g['lr']=base*factor
  for x,y in trainloader:
   optimizer.zero_grad(set_to_none=True);z=tail(x);loss=loss_fn(z,y);loss.backward();optimizer.step();total+=loss.item()*len(y);seen+=len(y)
  tail.eval();cm=np.zeros((9,9),np.int64)
  with torch.inference_mode():
   for x,y in valloader:
    got=tail(x).argmax(1).numpy();np.add.at(cm,(y.numpy(),got),1)
  m=metrics(cm);row=dict(epoch=epoch+1,loss=total/seen,**m);history.append(row)
  if m['macro_f1']>best:
   best=m['macro_f1'];best_epoch=epoch+1;torch.save(dict(state_dict=net.state_dict(),epoch=best_epoch,validation=m,classes=9,prefix_split=13),R/'leaf_refiner_best.pt')
  progress(phase='training',epoch=epoch+1,epochs=24,best_epoch=best_epoch,best_macro_f1=best,**m);print(json.dumps(row),flush=True)
  (R/'refiner_history.json').write_text(json.dumps(history,indent=2),encoding='utf8')
  if epoch+1-best_epoch>=6 and epoch>=9:break
 best_checkpoint=torch.load(R/'leaf_refiner_best.pt',map_location='cpu',weights_only=False);net.load_state_dict(best_checkpoint['state_dict']);net.eval()
 onnx=R/'leaf_refiner.onnx';torch.onnx.export(net,torch.zeros(1,3,224,224),onnx,input_names=['images'],output_names=['logits'],dynamic_axes={'images':{0:'batch'},'logits':{0:'batch'}},opset_version=12)
 report=dict(training_complete=True,best_epoch=best_epoch,validation=best_checkpoint['validation'],train_crops=len(train),validation_crops=len(val),class_counts=count.tolist(),classifier_classes=9,background_index=8,trained_on_user_examples=False,source_group_overlap=0,onnx_sha256=hashlib.sha256(onnx.read_bytes()).hexdigest(),elapsed_seconds=time.time()-started)
 (R/'refiner_training_result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');progress(phase='complete',**report);print('REFINER_TRAINING_COMPLETE',flush=True)
if __name__=='__main__':
 try:main()
 except Exception as e:progress(phase='error',error=repr(e));raise
