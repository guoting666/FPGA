from pathlib import Path
import sys,json,cv2,numpy as np
R=Path(__file__).resolve().parent;B=R.parent/'tomato_feature';sys.path.insert(0,str(R/'app'))
from tomato import TomatoDetector
cv2.setNumThreads(1);d=TomatoDetector();rows=[]
for c in [1,0,3,5]:
 p=B/'app/samples'/f'tomato_example_{c}.jpg';im=cv2.imread(str(p));h,w=im.shape[:2];candidates,timing=d.candidates(im,candidate_floor=.03);gt=[]
 for line in p.with_suffix('.txt').read_text().splitlines():
  k,x,y,bw,bh=map(float,line.split());gt.append(dict(class_id=int(k),xyxy=(np.array([x-bw/2,y-bh/2,x+bw/2,y+bh/2])*[w,h,w,h]).tolist()))
 rows.append(dict(expected=c,ground_truth=gt,candidates=candidates))
(R/'feedback_candidates.json').write_text(json.dumps(rows,ensure_ascii=False),encoding='utf8');print('FEEDBACK_CANDIDATES_CACHED')
