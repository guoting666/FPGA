"""Labelled clay 1/9 regression, explicitly not a blind evaluation."""
from pathlib import Path
import argparse,sys,json
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from digits import DigitDetector
from detector import Detector
from geometry import ShapePipeline

def near_one(p):
 x,y,x2,y2=p['xyxy'];return 130<(x+x2)/2<280 and 100<(y+y2)/2<260 and y2-y>90

def main():
 pa=argparse.ArgumentParser();pa.add_argument('--baseline-dir',type=Path);a=pa.parse_args();cv2.setNumThreads(1)
 d=Detector();f=ROOT/'tests/fixtures/clay';checks=[]
 def passed(name):checks.append(name);print('PASS',name,flush=True)
 for label,file in [(1,'hard_one_foreground.png'),(9,'hard_nine_foreground.png')]:
  pr=d.digits.classify(cv2.imread(str(f/file),0));order=np.argsort(pr)
  assert int(order[-1])==label and float(pr[label])>=.93 and float(pr[order[-1]]-pr[order[-2]])>=.2,(label,pr.tolist())
 passed('manually labelled training foregrounds 1 and 9 remain distinct; training fit only')
 baseline=DigitDetector(a.baseline_dir) if a.baseline_dir else None;cases=[]
 for fid in [88,110,132,176,220,264,308,396,440,485]:
  im=cv2.imread(str(f/f'frame_{fid}.png'));pred,t=d.digits.predict(im,.93)
  old=baseline.predict(im,.93)[0] if baseline else []
  row=dict(frame=fid,predictions=pred,one_region=[p for p in pred if near_one(p)],before_one_region=[p for p in old if near_one(p)],timing=t);cases.append(row)
  print('FRAME',fid,'ONE_REGION',[(p['digit'],round(p['confidence'],4)) for p in row['one_region']],flush=True)
 report=dict(passed=False,count=0,digit_model_sha256=d.digits.sha256,baseline_model_sha256=baseline.sha256 if baseline else None,scope='Regression of the reported clay 1/9 error. Two labelled crops from this video were used for adaptation; other frames show the same object, not an independent benchmark. English-word O versus digit 0 and occlusion remain outside this check.',training_video=True,cases=cases)
 (ROOT/'reports/one_nine_regression.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 # The THREE caption meets/covers the terminal of the 1 in frame 176.
 # Keep that case in the report and forbid a wrong 9; do not claim perfect
 # recall on an obscured glyph. The three clear frames spanning the reported
 # error must actually be recognized as 1, not merely rejected.
 assert all(not any(p['digit']=='9' for p in c['one_region']) for c in cases)
 assert all(any(p['digit']=='1' for p in c['one_region']) for c in cases if c['frame'] in [88,110,132])
 report.update(selected_frames_with_correct_one=sum(any(p['digit']=='1' for p in c['one_region']) for c in cases),selected_frames_missing_one=[c['frame'] for c in cases if not any(p['digit']=='1' for p in c['one_region'])])
 passed('clear frames spanning reported error must recognize 1; all ten sampled frames forbid a wrong 9, caption-related misses remain reported')
 im=cv2.imread(str(f/'frame_132.png'));p,t=ShapePipeline(d).predict(im,.96,targets='both')
 assert any(near_one(x) and x.get('digit')=='1' for x in p)
 cv2.imwrite(str(ROOT/'reports/clay_one_fixed.jpg'),d.annotate(im,p))
 passed('whole original problem scene passes combined shape and digit pipeline')
 pipe=ShapePipeline(d);assert not pipe.predict(im,.96,targets='both',stable=True)[0]
 assert any(near_one(x) and x.get('digit')=='1' for x in pipe.predict(im,.96,targets='both',stable=True)[0])
 assert not pipe.predict(np.full_like(im,230),.96,targets='both',stable=True)[0]
 passed('pink digit requires two video frames and disappears when removed')
 report.update(passed=True,count=len(checks),checks=checks)
 (ROOT/'reports/one_nine_regression.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
if __name__=='__main__':main()
