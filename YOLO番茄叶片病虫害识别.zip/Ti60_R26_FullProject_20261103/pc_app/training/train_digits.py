"""Train a small CPU digit CNN; no code from the linked repository is executed."""
import os
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL','2')
os.environ.setdefault('TF_ENABLE_ONEDNN_OPTS','1')
from pathlib import Path
import sys,json,time,hashlib,argparse
import cv2,numpy as np
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from digit_common import normalize_digit

def font_sample(rng,digit,font):
    image=Image.new('L',(80,80));draw=ImageDraw.Draw(image)
    face=ImageFont.truetype(str(font),int(rng.integers(40,69)))
    box=draw.textbbox((0,0),str(digit),font=face)
    draw.text(((80-(box[2]-box[0]))/2-box[0],(80-(box[3]-box[1]))/2-box[1]),str(digit),fill=255,font=face)
    return normalize_digit(np.asarray(image))

def negative(rng):
    image=np.zeros((64,64),np.uint8);k=int(rng.integers(0,9));thick=int(rng.integers(1,5))
    if k==0:cv2.rectangle(image,(12,8),(52,55),255,-1)
    elif k==1:cv2.fillPoly(image,[np.array([[32,7],[8,55],[56,55]])],255)
    elif k==2:cv2.circle(image,(32,32),int(rng.integers(18,26)),255,-1)
    elif k==3:cv2.rectangle(image,(13,9),(51,55),255,thick)
    elif k==4:cv2.circle(image,(32,32),int(rng.integers(18,26)),255,thick)
    elif k==5:
        pts=np.array([[32+25*np.cos(t),32+25*np.sin(t)] for t in np.arange(6)*np.pi/3],np.int32);cv2.polylines(image,[pts],True,255,thick)
    elif k==6:
        for _ in range(int(rng.integers(2,6))):cv2.line(image,tuple(rng.integers(5,59,2)),tuple(rng.integers(5,59,2)),255,thick)
    elif k==7:cv2.putText(image,str(rng.choice(list('AHKMNRTXZ+*=/'))),(5,51),cv2.FONT_HERSHEY_SIMPLEX,1.7,255,thick)
    else:
        image=(rng.random((64,64))>.95).astype(np.uint8)*255
    return normalize_digit(image)

def main():
    pa=argparse.ArgumentParser();pa.add_argument('--data',type=Path,required=True);pa.add_argument('--epochs',type=int,default=6);args=pa.parse_args()
    import tensorflow as tf
    tf.config.threading.set_intra_op_parallelism_threads(4);tf.config.threading.set_inter_op_parallelism_threads(2)
    tf.keras.utils.set_random_seed(2471);cv2.setNumThreads(1);rng=np.random.default_rng(2471)
    data=np.load(args.data,allow_pickle=False);order=rng.permutation(60000);train_ids=order[:55000];val_ids=order[55000:]
    train=np.stack([normalize_digit(im) for im in data['x_train'][train_ids]])
    val=np.stack([normalize_digit(im) for im in data['x_train'][val_ids]])
    labels=data['y_train'][train_ids];val_labels=data['y_train'][val_ids]
    font_root=Path('C:/Windows/Fonts');fonts=[font_root/x for x in ['arial.ttf','arialbd.ttf','calibri.ttf','calibrib.ttf','consola.ttf','comic.ttf','segoeui.ttf']]
    extra=np.stack([font_sample(rng,i%10,fonts[i%len(fonts)]) for i in range(14000)])
    rejects=np.stack([negative(rng) for _ in range(16000)])
    val_reject=np.stack([negative(rng) for _ in range(1800)])
    train=np.concatenate([train,extra,rejects]);labels=np.concatenate([labels,np.arange(len(extra))%10,np.full(len(rejects),10)])
    val=np.concatenate([val,val_reject]);val_labels=np.concatenate([val_labels,np.full(len(val_reject),10)])
    out=ROOT/'model/digits';report=ROOT/'reports';out.mkdir(exist_ok=True)
    np.savez_compressed(out/'split_indices.npz',train=train_ids,validation=val_ids)
    inputs=tf.keras.Input((32,32,1),name='foreground')
    x=tf.keras.layers.RandomRotation(.045,fill_mode='constant',fill_value=0)(inputs)
    x=tf.keras.layers.RandomTranslation(.055,.055,fill_mode='constant',fill_value=0)(x)
    for n in [16,32,48]:
        x=tf.keras.layers.Conv2D(n,3,padding='same',activation='relu')(x);x=tf.keras.layers.MaxPooling2D()(x)
    x=tf.keras.layers.Flatten()(x);x=tf.keras.layers.Dense(64,activation='relu')(x);x=tf.keras.layers.Dropout(.2)(x)
    logits=tf.keras.layers.Dense(11,name='logits')(x)
    model=tf.keras.Model(inputs,logits,name='DigitCNN_Reject_v1')
    model.compile(optimizer=tf.keras.optimizers.Adam(.001),loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),metrics=['accuracy'])
    history=[];started=time.time()
    class Progress(tf.keras.callbacks.Callback):
        def on_epoch_end(self,epoch,logs=None):
            record=dict(epoch=epoch+1,seconds=time.time()-started,**{k:float(v) for k,v in logs.items()});history.append(record)
            (report/'digit_training_history.json').write_text(json.dumps(history,indent=2));print(json.dumps(record),flush=True)
    model.fit(train[...,None].astype(np.float32)/255,labels,validation_data=(val[...,None].astype(np.float32)/255,val_labels),epochs=args.epochs,batch_size=256,verbose=0,callbacks=[Progress(),tf.keras.callbacks.ModelCheckpoint(str(out/'best.keras'),monitor='val_loss',save_best_only=True),tf.keras.callbacks.ReduceLROnPlateau(monitor='val_loss',patience=1,factor=.5)])
    model=tf.keras.models.load_model(out/'best.keras');converter=tf.lite.TFLiteConverter.from_keras_model(model)
    converter.optimizations=[tf.lite.Optimize.DEFAULT];blob=converter.convert();(out/'digit_cnn.tflite').write_bytes(blob)
    meta=dict(architecture='DigitCNN_Reject_v1',input_shape=[1,32,32,1],input_dtype='float32',input_range=[0,1],class_names=[str(i) for i in range(10)]+['reject'],class_id_offset=3,sha256=hashlib.sha256(blob).hexdigest(),parameters=model.count_params(),confidence=.93,minimum_margin=.20,training_examples=len(train),validation_examples=len(val),mnist_train=55000,mnist_validation=5000,mnist_test=10000,synthetic_font_examples=14000,synthetic_reject_examples=16000,epochs=args.epochs,train_fonts=[str(p.name) for p in fonts],test_used_for_training=False,source='MNIST + locally generated font and reject examples',training_seconds=time.time()-started,scope='Digit classification after contour proposals, not YOLO detection or semantic segmentation.')
    (out/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(meta),flush=True)
if __name__=='__main__':main()
