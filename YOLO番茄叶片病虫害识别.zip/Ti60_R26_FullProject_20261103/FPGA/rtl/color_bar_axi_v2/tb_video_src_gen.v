`timescale 1ns / 1ps

module tb_video_src_gen;
    localparam VID_WIDTH = 24;
    localparam FIFO_DIPTH = 512;
    localparam  FIFO_ALMOST_FULL= 510;
    localparam MAX_H_VALID = 1920;
    localparam MAX_V_VALID = 1080;
    localparam	H_FRONT_PORCH 	= 13'd20; 
    localparam	H_SYNC 			= 13'd20; 
    localparam	H_VALID 		= 13'd1920; 
    localparam	H_BACK_PORCH 	= 13'd20; 
    localparam	V_FRONT_PORCH 	= 13'd5; 
    localparam	V_SYNC 			= 13'd5; 
    localparam	V_VALID 		= 13'd10; 
    localparam	V_BACK_PORCH 	= 13'd20;
    // 信号声明
    reg axi_clk = 1'b0;
    reg rst_n = 1'b0;
    reg sync_clk = 1'b0;
    reg sync_rst_n = 1'b0;
    reg mode = 1'b0;


  wire [23:0] m_axis_tdata ;
  wire m_axis_tvalid;
  wire m_axis_tready;
  wire m_axis_tuser ;
  wire m_axis_tlast ;

    wire 	[VID_WIDTH-1:0] 				vout ;
	wire									o_hs ;
	wire									o_vs ;
	wire									o_de ;
    // 时钟生成
        always #5 axi_clk = ~axi_clk; // 10ns周期，即100MHz时钟
        always #6 sync_clk = ~sync_clk; // 10ns周期，即100MHz时钟
    

    // 实例化待测模块
  video_gen_top # (
    .SYMBOL_WIDTH(8),
    .SYMBOL_NUM(3),
    .PAR_PIXEL_NUM(1),
    .MAX_WIDTH(1920),
    .MAX_HEIGTH(1080),
    .H_FRONT_PORCH(H_FRONT_PORCH),
    .H_SYNC(H_SYNC),
    .H_VALID(H_VALID),
    .H_BACK_PORCH(H_BACK_PORCH),
    .V_FRONT_PORCH(V_FRONT_PORCH),
    .V_SYNC(V_SYNC),
    .V_VALID(V_VALID),
    .V_BACK_PORCH(V_BACK_PORCH)
  )
  video_gen_top_inst (
    .axi_clk(axi_clk),
    .rst_n(rst_n),
    .mode(1'b0),
    .src_width(H_VALID),
    .src_height(V_VALID),


    
    // .m_axis_tdata(m_axis_tdata),
    // .m_axis_tvalid(m_axis_tvalid),
    // .m_axis_tready(m_axis_tready),
    // .m_axis_tuser(m_axis_tuser),
    // .m_axis_tlast(m_axis_tlast),
     .vout(vout),
    .o_hs(o_hs),
    .o_vs(o_vs),
    .o_de(o_de)

  );


  // cvo_axi # (
  //   .SYMBOL_WIDTH(8),
  //   .SYMBOL_NUM(3),
  //   .PIXEL_NUM(1),
  //   .HSYNC_POL(1'b1),
  //   .VSYNC_POL(1'b1),
  //   .FIFO_DEPTH(FIFO_DIPTH),
  //    .MAX_H_VALID(MAX_H_VALID),
  //   .MAX_V_VALID(MAX_V_VALID),
  //   .FIFO_ALMOST_FULL(500)
  // )
  // cvo_axi_inst (
  //   .rst_n(rst_n),
  //   .fifo_rd_period(fifo_rd_period),
  //   .fifo_rd_underflow(fifo_rd_underflow),
  //   .s_axi_clk(axi_clk),
  //   .s_axis_tdata (m_axis_tdata),
  //   .s_axis_tvalid(m_axis_tvalid),
  //   .s_axis_tready(m_axis_tready),
  //   .s_axis_tlast (m_axis_tlast),
  //   .s_axis_tuser (m_axis_tuser),

  //   .o_clk(sync_clk ),
  //   .vout(vout),
  //   .o_hs(o_hs),
  //   .o_vs(o_vs),
  //   .o_de(o_de)
  // );

  // vid_check  vid_check_inst (
  //   .clk(sync_clk),
  //   .rst_n(rst_n),
  //   .i_hs(o_hs),
  //   .i_vs(o_vs),
  //   .i_de(o_de),
  //   .vin(vout),
  //   .check_fail(check_fail)
  // );
    // 测试序列
    initial begin
        // 初始化信号
        rst_n = 0;
        #20;
        rst_n = 1;
        #20;
    end 

endmodule

