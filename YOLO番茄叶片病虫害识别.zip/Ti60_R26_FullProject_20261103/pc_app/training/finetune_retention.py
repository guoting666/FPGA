"""Replay labelled foregrounds and public training IDs; update output layer only.

This preserves visual features after the overlay adaptation. Original HWD
validation writers choose the checkpoint. No public test IDs enter fitting.
"""
from pathlib import Path
import os,sys,json,hashlib,argparse,time
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL','2')
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'training')]
from digit_common import normalize_digit
from finetune_hard import augmented
from train_digits import negative

def main():
 p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);a=p.parse_args()
 import tensorflow as tf
 tf.config.threading.set_intra_op_parallelism_threads(4);tf.config.threading.set_inter_op_parallelism_threads(2);tf.keras.utils.set_random_seed(2535);cv2.setNumThreads(1);rng=np.random.default_rng(2535);out=ROOT/'model/digits'
 meta=json.loads((out/'metadata.json').read_text(encoding='utf8'));initial_sha=meta['sha256'];model=tf.keras.models.load_model(out/'clay_deploy_best.keras')
 for layer in model.layers[:-1]:layer.trainable=False
 model.compile(optimizer=tf.keras.optimizers.Adam(.0002),loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),metrics=['accuracy'])
 mn=np.load(a.data/'mnist.npz');ms=np.load(out/'split_indices.npz');ids=rng.choice(ms['train'],20000,replace=False);mx=np.stack([normalize_digit(im) for im in mn['x_train'][ids]])
 hwd=np.load(a.data/'HWD/Images28.npy');info=np.load(a.data/'HWD/WriterInfo.npy');hs=np.load(out/'hwd_split_indices.npz');hx=np.stack([normalize_digit(np.clip(255-im,0,255).astype('uint8')) for im in hwd])
 f=ROOT/'tests/fixtures/clay_all';samples=json.loads((f/'source.json').read_text(encoding='utf8'))['samples'];sources=[cv2.imread(str(f/s['file']),0) for s in samples];hard=np.stack([augmented(rng,sources[i%len(samples)]) for i in range(8500)]);hy=np.array([samples[i%len(samples)]['label'] for i in range(len(hard))])
 older=[cv2.imread(str(ROOT/'tests/fixtures/clay'/name),0) for name in ['hard_one_foreground.png','hard_nine_foreground.png']];replay=np.stack([augmented(rng,older[i%2]) for i in range(5000)])
 neg=np.stack([negative(rng) for _ in range(4000)]);x=np.concatenate([mx,hx[hs['train']],hard,replay,neg]);y=np.concatenate([mn['y_train'][ids],info[hs['train'],0],hy,np.tile([1,9],2500),np.full(len(neg),10)])
 vx=hx[hs['validation']][...,None].astype('float32')/255;vy=info[hs['validation'],0];started=time.time();history=[]
 for epoch in range(3):
  fit=model.fit(x[...,None].astype('float32')/255,y,validation_data=(vx,vy),epochs=1,batch_size=256,verbose=0);row=dict(epoch=epoch+1,seconds=time.time()-started,**{k:float(v[0]) for k,v in fit.history.items()});history.append(row);print(row,flush=True)
  if row['val_loss']==min(r['val_loss'] for r in history):model.save(out/'retention_best.keras')
 model=tf.keras.models.load_model(out/'retention_best.keras');conv=tf.lite.TFLiteConverter.from_keras_model(model);conv.optimizations=[tf.lite.Optimize.DEFAULT];blob=conv.convert();(out/'digit_cnn.tflite').write_bytes(blob)
 meta['sha256']=hashlib.sha256(blob).hexdigest();meta['retention_finetune']=dict(examples=len(x),epochs=3,trainable='last Dense layer only',previous_one_nine_replay=5000,clay_all_replay=8500,public_mnist_training=20000,public_hwd_training=9800,generated_rejects=4000,validation='1960 original HWD validation-writer examples, minimum loss checkpoint',initial_model_sha256=initial_sha,test_used_for_training=False,history=history)
 (out/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf8');(ROOT/'reports/retention_training_history.json').write_text(json.dumps(meta['retention_finetune'],indent=2));print('RETENTION_COMPLETE',meta['sha256'],flush=True)
if __name__=='__main__':main()
