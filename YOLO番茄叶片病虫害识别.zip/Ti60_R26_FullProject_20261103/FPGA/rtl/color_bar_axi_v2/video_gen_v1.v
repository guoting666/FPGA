`timescale 1ns / 1ps

module video_gen #(
    parameter SYMBOL_WIDTH = 'd10,
	parameter SYMBOL_NUM	= 'd3,
    parameter PAR_PIXEL_NUM = 'd1,

    parameter MAX_WIDTH = 1920,
    parameter MAX_HEIGTH = 1080,
    parameter FRAME_WIDTH = 1920,
    parameter FRAME_HEIGHT = 1080,
    parameter DATA_WIDTH = SYMBOL_WIDTH*SYMBOL_NUM*PAR_PIXEL_NUM,
    parameter H_WIDTH = $clog2(MAX_WIDTH),
    parameter C_WIDTH = $clog2(MAX_HEIGTH)
)(
    input wire clk,
    input wire rst_n,
    input wire mode,
        
    input wire [H_WIDTH-1:0] src_width,
    input wire [C_WIDTH-1:0] src_height,
    // AXI Stream 发送接口
    output reg [DATA_WIDTH-1:0] m_axis_tdata,
    output reg                  m_axis_tvalid,
    input wire                  m_axis_tready,
    output reg                  m_axis_tuser,
    output reg                  m_axis_tlast
);
//=========================================================
//
//=========================================================
localparam WHITE_R 		= 8'hff;
localparam WHITE_G 		= 8'hff;
localparam WHITE_B 		= 8'hff;
localparam YELLOW_R 	= 8'hff;
localparam YELLOW_G 	= 8'hff;
localparam YELLOW_B 	= 8'h00;                              	
localparam CYAN_R 		= 8'h00;
localparam CYAN_G 		= 8'hff;
localparam CYAN_B 		= 8'hff;                             	
localparam GREEN_R 		= 8'h00;
localparam GREEN_G 		= 8'hff;
localparam GREEN_B 		= 8'h00;
localparam MAGENTA_R 	= 8'hff;
localparam MAGENTA_G 	= 8'h00;
localparam MAGENTA_B 	= 8'hff;
localparam RED_R 		= 8'hff;
localparam RED_G 		= 8'h00;
localparam RED_B 		= 8'h00;
localparam BLUE_R 		= 8'h00;
localparam BLUE_G 		= 8'h00;
localparam BLUE_B 		= 8'hff;
localparam BLACK_R 		= 8'h00;
localparam BLACK_G 		= 8'h00;
localparam BLACK_B 		= 8'h00;
wire [H_WIDTH-1:0] h_cnt ;
wire [C_WIDTH-1:0] v_cnt ;
    assign h_cnt = src_width/PAR_PIXEL_NUM;
    assign v_cnt = src_height;


    // 行和列计数器
    reg [15:0] col_index;
    reg [15:0] row_index;
    reg [DATA_WIDTH-1:0] m_axis_tdata_r = 'd0;
    always @(*) begin
        if (m_axis_tready & m_axis_tvalid) begin
                case (mode)
                    1'b0: begin
                        // 累加模式
                        m_axis_tdata = m_axis_tdata_r;//m_axis_tlast ? 0 :m_axis_tdata + 1'b1;
                    end
                    1'b1: begin
                         // 8 条彩条模式
                        if (col_index < h_cnt / 8) begin
                            m_axis_tdata =  {{PAR_PIXEL_NUM}{WHITE_R,WHITE_G,WHITE_B}};// 红色
                        end else if (col_index < 2 * h_cnt / 8) begin
                            m_axis_tdata = {{PAR_PIXEL_NUM}{YELLOW_R,YELLOW_G,YELLOW_B}};
                        end else if (col_index < 3 * h_cnt / 8) begin
                            m_axis_tdata = {{PAR_PIXEL_NUM}{CYAN_R,CYAN_G,CYAN_B}};
                        end else if (col_index < 4 * h_cnt / 8) begin
                            m_axis_tdata = {{PAR_PIXEL_NUM}{GREEN_R,GREEN_G,GREEN_B}};
                        end else if (col_index < 5 * h_cnt / 8) begin
                            m_axis_tdata = {{PAR_PIXEL_NUM}{MAGENTA_R,MAGENTA_G,MAGENTA_B}};
                        end else if (col_index < 6 * h_cnt / 8) begin
                            m_axis_tdata ={{PAR_PIXEL_NUM}{RED_R,RED_G,RED_B}}; 
                        end else if (col_index < 7 * h_cnt / 8) begin
                            m_axis_tdata = {{PAR_PIXEL_NUM}{BLUE_R,BLUE_G,BLUE_B}};
                        end else begin
                            m_axis_tdata = {{PAR_PIXEL_NUM}{BLACK_R,BLACK_G,BLACK_B}};
                        end
                    end
                    default: begin
                        m_axis_tdata = 24'h000000;
                    end
                endcase
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) 
            m_axis_tdata_r <= 24'h000000;
        else if (m_axis_tready & m_axis_tvalid) begin
                if(mode == 0)
                        m_axis_tdata_r <= m_axis_tlast ? 0 :m_axis_tdata_r + 1'b1;
        end 
    end 

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)    
            m_axis_tvalid <= 0;
        else if( m_axis_tready )
            m_axis_tvalid <= 1'b1;
        else 
            m_axis_tvalid <= 1'b0;
    end 

    
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            col_index <= 0;
            row_index <= 0;
        end else if( m_axis_tready & m_axis_tvalid )begin
            if (col_index == h_cnt - 1) begin
                    if (row_index == src_height - 1) begin
                        col_index <= 0;
                        row_index <= 0;
                    end else begin
                        col_index <= 0;
                        row_index <= row_index + 1;
                    end
                end else begin
                    col_index <= col_index + 1;
                end
        end 
    end 


    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            m_axis_tlast <= 0;
        else if( m_axis_tready & m_axis_tvalid ) begin 
            if ( (col_index == h_cnt - 2) ) //&& (row_index == src_height - 1)
                m_axis_tlast <= 1;
            else if( (col_index == h_cnt - 1) )//&& (row_index == src_height - 1)
                m_axis_tlast <= 1'b0;
        end 
    end


    always @( posedge clk or negedge rst_n )
    begin
        if( !rst_n )
            m_axis_tuser <= 1'b1;
        else if(col_index == h_cnt - 1 && row_index == v_cnt-1  && m_axis_tready & m_axis_tvalid  )
            m_axis_tuser <= 1'b1;
        else if(col_index == 0 && row_index == 'd0 && m_axis_tready && m_axis_tvalid )
            m_axis_tuser <= 1'b0;
    end
//========================================================== 
//
//==========================================================
  

endmodule