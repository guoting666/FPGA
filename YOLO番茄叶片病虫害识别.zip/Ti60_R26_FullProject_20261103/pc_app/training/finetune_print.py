"""Extend font coverage without training on the user's gold-digit screenshot.

Windows font files are used locally and are not redistributed. Test font families
are excluded from both training and checkpoint selection. HWD writer split stays
unchanged. All image labels are retained; no shape/digit threshold is lowered.
"""
import os
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL','2')
from pathlib import Path
import sys,json,time,hashlib,argparse
import cv2,numpy as np
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from digit_common import normalize_digit
from train_digits import negative

TRAIN_FONTS=['arial.ttf','arialbd.ttf','calibri.ttf','consola.ttf','comic.ttf','segoeui.ttf',
 'times.ttf','timesbd.ttf','timesi.ttf','georgia.ttf','georgiab.ttf','cour.ttf','courbd.ttf',
 'BOD_R.TTF','BOD_B.TTF','BOD_I.TTF','MOD20.TTF','CURLZ___.TTF','BOOKOS.TTF','BOOKOSB.TTF',
 'BASKVILL.TTF','GARA.TTF','GARABD.TTF','COOPBL.TTF','BRITANIC.TTF','ALGER.TTF',
 'ELEPHNT.TTF','CALIST.TTF','CALISTB.TTF','PER_____.TTF','PERB____.TTF','STENCIL.TTF',
 'BAUHS93.TTF','HARNGTON.TTF','JOKERMAN.TTF','OCRAEXT.TTF','ONYX.TTF','GOTHIC.TTF']
TEST_FONTS=['BELL.TTF','ROCK.TTF','GOUDOS.TTF','BERNHC.TTF','BROADW.TTF','CENTURY.TTF']

def glyph(rng,text,font,augment=True):
    image=Image.new('L',(120,120));draw=ImageDraw.Draw(image)
    face=ImageFont.truetype(str(Path('C:/Windows/Fonts')/font),int(rng.integers(65,101)))
    box=draw.textbbox((0,0),text,font=face)
    draw.text(((120-box[2]+box[0])/2-box[0],(120-box[3]+box[1])/2-box[1]),text,font=face,fill=255)
    raw=np.array(image)
    if augment:
        if rng.random()<.25:
            raw=cv2.dilate(raw,np.ones((2,2),np.uint8)) if rng.random()<.5 else cv2.erode(raw,np.ones((2,2),np.uint8))
        if rng.random()<.4:
            # Shading/highlights preserve glyph topology; strong outline-only
            # lettering is intentionally outside this classifier's scope.
            yy,xx=np.indices(raw.shape);shade=.65+.35*np.sin(xx/rng.uniform(9,25)+yy/rng.uniform(18,50))
            raw=(raw*shade).astype(np.uint8)
        if rng.random()<.25:raw=cv2.GaussianBlur(raw,(3,3),.7)
        if rng.random()<.4:
            shear=rng.uniform(-.1,.1);raw=cv2.warpAffine(raw,np.float32([[rng.uniform(.85,1.15),shear,-shear*60],[0,1,0]]),(120,120))
    return normalize_digit(raw)

def main():
    p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);p.add_argument('--epochs',type=int,default=8);a=p.parse_args()
    import tensorflow as tf
    tf.config.threading.set_intra_op_parallelism_threads(4);tf.config.threading.set_inter_op_parallelism_threads(2)
    tf.keras.utils.set_random_seed(2504);cv2.setNumThreads(1);rng=np.random.default_rng(2504)
    out=ROOT/'model/digits';meta=json.loads((out/'metadata.json').read_text(encoding='utf8'))
    assert not set(TRAIN_FONTS)&set(TEST_FONTS)
    mn=np.load(a.data/'mnist.npz',allow_pickle=False);ms=np.load(out/'split_indices.npz',allow_pickle=False)
    ids=rng.choice(ms['train'],26000,replace=False);m=np.stack([normalize_digit(im) for im in mn['x_train'][ids]])
    hwd=np.load(a.data/'HWD/Images28.npy',allow_pickle=False);info=np.load(a.data/'HWD/WriterInfo.npy',allow_pickle=False)
    hs=np.load(out/'hwd_split_indices.npz',allow_pickle=False)
    h=np.stack([normalize_digit(np.clip(255-im,0,255).astype(np.uint8)) for im in hwd])
    count=25000;extra=np.stack([glyph(rng,str(i%10),TRAIN_FONTS[int(rng.integers(len(TRAIN_FONTS)))]) for i in range(count)])
    rejects=np.stack([negative(rng) if i%2 else glyph(rng,str(rng.choice(list('AHKMNRTXZ+*=/BCDEFGPQSU'))),TRAIN_FONTS[int(rng.integers(len(TRAIN_FONTS)))]) for i in range(12000)])
    vf=np.stack([glyph(rng,str(i%10),TRAIN_FONTS[int(rng.integers(len(TRAIN_FONTS)))]) for i in range(2500)])
    vn=np.stack([negative(rng) for _ in range(1000)])
    x=np.concatenate([m,h[hs['train']],extra,rejects]);y=np.concatenate([mn['y_train'][ids],info[hs['train'],0],np.arange(count)%10,np.full(len(rejects),10)])
    vx=np.concatenate([h[hs['validation']],vf,vn]);vy=np.concatenate([info[hs['validation'],0],np.arange(len(vf))%10,np.full(len(vn),10)])
    model=tf.keras.models.load_model(out/'hwd_best.keras')
    model.compile(optimizer=tf.keras.optimizers.Adam(.00022),loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),metrics=['accuracy'])
    started=time.time();history=[]
    class Progress(tf.keras.callbacks.Callback):
        def on_epoch_end(self,epoch,logs=None):
            row=dict(epoch=epoch+1,seconds=time.time()-started,**{k:float(v) for k,v in logs.items()});history.append(row)
            (ROOT/'reports/print_training_history.json').write_text(json.dumps(history,indent=2));print(json.dumps(row),flush=True)
    model.fit(x[...,None].astype(np.float32)/255,y,validation_data=(vx[...,None].astype(np.float32)/255,vy),epochs=a.epochs,batch_size=256,verbose=0,callbacks=[Progress(),tf.keras.callbacks.ModelCheckpoint(str(out/'print_best.keras'),monitor='val_loss',save_best_only=True),tf.keras.callbacks.ReduceLROnPlateau(monitor='val_loss',patience=2,factor=.5)])
    model=tf.keras.models.load_model(out/'print_best.keras');conv=tf.lite.TFLiteConverter.from_keras_model(model);conv.optimizations=[tf.lite.Optimize.DEFAULT]
    blob=conv.convert();(out/'digit_cnn.tflite').write_bytes(blob)
    meta.update(sha256=hashlib.sha256(blob).hexdigest(),source=meta['source']+' + expanded serif/decorative font fine-tuning',print_train_fonts=TRAIN_FONTS,print_test_fonts=TEST_FONTS,print_finetune=dict(examples=len(x),epochs=a.epochs,generated_digits=count,generated_rejects=len(rejects),mnist_replay=len(m),hwd_train=len(hs['train']),validation=len(vx),seconds=time.time()-started,checkpoint='minimum validation loss; validation uses train font families with new renders and HWD validation writers',user_screenshot_in_training=False,heldout_fonts_used_for_checkpoint_selection=False))
    (out/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(meta),flush=True)
if __name__=='__main__':main()
