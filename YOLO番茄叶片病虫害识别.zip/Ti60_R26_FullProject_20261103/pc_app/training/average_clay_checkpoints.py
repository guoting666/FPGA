from pathlib import Path
import sys,os,json,hashlib,argparse
os.environ['TF_CPP_MIN_LOG_LEVEL']='2'
import cv2,numpy as np,tensorflow as tf
A=Path(__file__).resolve().parents[1];sys.path[:0]=[str(A),str(A/'training')]
parser=argparse.ArgumentParser();parser.add_argument('--data',type=Path,required=True);args=parser.parse_args()
from digit_common import normalize_digit
tf.config.threading.set_intra_op_parallelism_threads(4);tf.config.threading.set_inter_op_parallelism_threads(2);cv2.setNumThreads(1)
out=A/'model/digits';latest=tf.keras.models.load_model(out/'clay_all_best.keras');previous=tf.keras.models.load_model(out/'clay_initial_best.keras');lw=latest.get_weights();pw=previous.get_weights()
f=A/'tests/fixtures/clay_all';prov=json.loads((f/'source.json').read_text(encoding='utf8'));samples=[(f/s['file'],s['label']) for s in prov['samples']]+[(A/'tests/fixtures/clay/hard_one_foreground.png',1),(A/'tests/fixtures/clay/hard_nine_foreground.png',9)]
tx=np.stack([normalize_digit(cv2.imread(str(p),0)) for p,y in samples])[...,None].astype('float32')/255;ty=np.array([y for p,y in samples])
hs=np.load(out/'hwd_split_indices.npz');hwd=np.load(args.data/'HWD/Images28.npy');info=np.load(args.data/'HWD/WriterInfo.npy');vx=np.stack([normalize_digit(np.clip(255-im,0,255).astype('uint8')) for im in hwd[hs['validation']]])[...,None].astype('float32')/255;vy=info[hs['validation'],0]
rows=[];eligible=[]
for ratio in [.1,.15,.2,.25,.3]:
 latest.set_weights([a*(1-ratio)+b*ratio for a,b in zip(lw,pw)]);logits=latest.predict(tx,verbose=0);prob=tf.nn.softmax(logits).numpy();accepted=np.all(prob.argmax(1)==ty) and np.min(prob[np.arange(len(ty)),ty])>=.935
 vl=latest.predict(vx,verbose=0);loss=float(tf.keras.losses.sparse_categorical_crossentropy(vy,vl,from_logits=True).numpy().mean());row=dict(previous_weight_fraction=ratio,training_template_min_probability=float(prob[np.arange(len(ty)),ty].min()),weakest_training_template=str(samples[int(prob[np.arange(len(ty)),ty].argmin())][0].name),passes_training_template_retention=bool(accepted),hwd_validation_loss=loss);rows.append(row);print(row,flush=True)
 if accepted:eligible.append((loss,ratio))
assert eligible,'No candidate preserves all training labels at threshold'
loss,ratio=min(eligible);latest.set_weights([a*(1-ratio)+b*ratio for a,b in zip(lw,pw)]);latest.save(out/'clay_deploy_best.keras');conv=tf.lite.TFLiteConverter.from_keras_model(latest);conv.optimizations=[tf.lite.Optimize.DEFAULT];blob=conv.convert();(out/'digit_cnn.tflite').write_bytes(blob)
meta=json.loads((out/'metadata.json').read_text(encoding='utf8'));meta['sha256']=hashlib.sha256(blob).hexdigest();meta['clay_checkpoint_averaging']=dict(selected_previous_weight_fraction=ratio,selection='Keep labelled training templates >=0.935, then minimize original HWD validation-writer loss among five checkpoint averages; no test images used.',candidates=rows,previous_tflite_sha256='c63b3e3f2e7aebd1fe95eccf52e0bea2f54a045904431272765621b3b04b1907',overlay_tflite_sha256='607309f16ea7d4cbab0943eed1a7aaea8167402b59f1ca98df4ed4842ea64811')
(out/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf8');(A/'reports/clay_checkpoint_averaging.json').write_text(json.dumps(meta['clay_checkpoint_averaging'],indent=2));print('DEPLOY_MODEL',meta['sha256'],flush=True)

