// All status inputs must already be synchronized to clk.
// Capture and network read never overlap; startup requires two DDR writes; steady captures require one complete write.
module ge_live_control #(
    parameter USE_FRAME_BANKS=0,
    parameter BOOT_CYCLES=200000000, SETTLE_CYCLES=100000,
    parameter WATCHDOG_CYCLES=250000000
)(
    input clk, rst_n, frame_start,
    input capture_ready, output reg frame_publish,
    input write_done_toggle, writer_idle,
    input sender_busy, reader_done,
    output capture_en, output reg send_toggle, output fault,
    output reg [2:0] fault_stage, output [2:0] debug_state, output [1:0] debug_writes
);
localparam BOOT=0, ALIGN=1, CAPTURE=2, DRAIN=3, SETTLE=4,
           WAIT_BUSY=5, WAIT_FINISH=6, FAULT=7;
reg [2:0] state;
reg [31:0] timer;
reg [1:0] frame_count, write_count;
reg [2:0] warm_frames;
reg warming;
reg [1:0] required_writes;
reg write_seen;
assign capture_en=state==CAPTURE;
assign fault=state==FAULT;
assign debug_state=state;
assign debug_writes=write_count;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        frame_publish<=0;fault_stage<=0; state<=BOOT; timer<=0; frame_count<=0; write_count<=0;
        write_seen<=0; send_toggle<=0; warming<=1; warm_frames<=0; required_writes<=2;
    end else begin
        frame_publish<=0;
        write_seen<=write_done_toggle;
        if((state==CAPTURE || state==DRAIN) && write_done_toggle!=write_seen && write_count<2)
            write_count<=write_count+1'b1;
        if(state!=FAULT) fault_stage<=state;
        case(state)
          BOOT: begin
              if(timer==BOOT_CYCLES-1) begin state<=ALIGN; timer<=0; end
              else timer<=timer+1'b1;
          end
          ALIGN: begin
              if(frame_start && (!USE_FRAME_BANKS || capture_ready)) begin
                  required_writes<=warming ? 2 : 1;
                  state<=CAPTURE; frame_count<=0; warm_frames<=0; write_count<=0; timer<=0;
              end else if(timer==WATCHDOG_CYCLES-1) state<=FAULT;
              else timer<=timer+1'b1;
          end
          CAPTURE: begin
              if(frame_start) begin
                  if((warming && warm_frames==4) || (!warming && frame_count==0)) begin
                      state<=DRAIN; timer<=0; warming<=0;
                  end else begin
                      frame_count<=frame_count+1'b1; warm_frames<=warm_frames+1'b1;
                  end
              end
              if(timer==WATCHDOG_CYCLES-1) state<=FAULT;
              else timer<=timer+1'b1;
          end
          DRAIN: begin
              if(write_count>=required_writes && writer_idle) begin frame_publish<=1; state<=SETTLE; timer<=0; end
              else if(timer==WATCHDOG_CYCLES-1) state<=FAULT;
              else timer<=timer+1'b1;
          end
          SETTLE: begin
              if(timer==SETTLE_CYCLES-1) begin
                  send_toggle<=~send_toggle; state<=WAIT_BUSY; timer<=0;
              end else timer<=timer+1'b1;
          end
          WAIT_BUSY: begin
              if(sender_busy) begin state<=WAIT_FINISH; timer<=0; end
              else if(timer==WATCHDOG_CYCLES-1) state<=FAULT;
              else timer<=timer+1'b1;
          end
          WAIT_FINISH: begin
              if(!sender_busy && reader_done) begin state<=ALIGN; timer<=0; end
              else if(timer==WATCHDOG_CYCLES-1) state<=FAULT;
              else timer<=timer+1'b1;
          end
          default: state<=FAULT;
        endcase
    end
end
endmodule

// Two completed-frame slots shared by the camera, HDMI and frozen UDP read.
// The writer uses a private slot. Publish only after all DDR write responses.
// The HDMI reader latches the published base at its existing frame start.
// Recycle the old slot only after that switch AND all old AXI reads drain.
module ge_frame_banks #(
 parameter ADDR_WIDTH=32,BANK_SHIFT=21,READ_RELEASE_GUARD=32
)(
 input capture_clk,axi_clk,rst_n,
 input capture_en,frame_publish,
 input hdmi_read_bank,hdmi_reads_idle,
 output capture_ready,output [ADDR_WIDTH-1:0]write_base,published_base,
 output reg display_ready
);
reg [2:0] capture_reset=0,axi_reset=0;
always @(posedge capture_clk or negedge rst_n)
 if(!rst_n)capture_reset<=0;else capture_reset<={capture_reset[1:0],1'b1};
always @(posedge axi_clk or negedge rst_n)
 if(!rst_n)axi_reset<=0;else axi_reset<={axi_reset[1:0],1'b1};
wire capture_rst_n=capture_reset[2],axi_rst_n=axi_reset[2];
reg write_bank,publish_bank,publish_valid,publish_toggle;
reg [1:0] confirmed_capture;
reg confirmed_bank;
always @(posedge capture_clk or negedge capture_rst_n)begin
 if(!capture_rst_n)begin
  write_bank<=0;publish_bank<=1;publish_valid<=0;publish_toggle<=0;confirmed_capture<=2'b11;
 end else begin
  confirmed_capture<={confirmed_capture[0],confirmed_bank};
  if(!capture_en&&!frame_publish)write_bank<=~publish_bank;
  if(frame_publish)begin publish_bank<=write_bank;publish_valid<=1;publish_toggle<=~publish_toggle;end
 end
end
assign capture_ready=capture_rst_n&&(write_bank!=confirmed_capture[1])&&
                     (!publish_valid||confirmed_capture[1]==publish_bank);
reg [1:0] write_sync,publish_data_sync;
reg [2:0] publish_event_sync;
reg publish_event_seen,published_axi,published_valid_axi,read_bank_seen;
reg [7:0] release_guard;
always @(posedge axi_clk or negedge axi_rst_n)begin
 if(!axi_rst_n)begin
  write_sync<=0;publish_data_sync<=2'b11;publish_event_sync<=0;publish_event_seen<=0;
  published_axi<=1;published_valid_axi<=0;read_bank_seen<=1;confirmed_bank<=1;
  release_guard<=READ_RELEASE_GUARD;display_ready<=0;
 end else begin
  write_sync<={write_sync[0],write_bank};publish_data_sync<={publish_data_sync[0],publish_bank};
  publish_event_sync<={publish_event_sync[1:0],publish_toggle};
  if(publish_event_sync[2]!=publish_event_seen)begin
   published_axi<=publish_data_sync[1];published_valid_axi<=1;publish_event_seen<=publish_event_sync[2];
  end
  if(hdmi_read_bank!=read_bank_seen)begin
   read_bank_seen<=hdmi_read_bank;release_guard<=READ_RELEASE_GUARD;
  end else if(release_guard!=0)release_guard<=release_guard-1'b1;
  else if(hdmi_reads_idle)confirmed_bank<=read_bank_seen;
  if(published_valid_axi&&confirmed_bank==published_axi&&read_bank_seen==confirmed_bank&&release_guard==0)
   display_ready<=1;
 end
end
assign write_base={{(ADDR_WIDTH-1){1'b0}},write_sync[1]}<<BANK_SHIFT;
assign published_base={{(ADDR_WIDTH-1){1'b0}},published_axi}<<BANK_SHIFT;
endmodule

// Four private 2-MiB slots. The AXI owner grants camera writes, publishes
// committed frames, and pins a separate completed snapshot for the network.
// HDMI's active frame and each outstanding physical read are protected.
module ge_video_engine #(
 parameter ADDR_WIDTH=32,BANK_SHIFT=21,BOOT_CYCLES=200000000,
 SETTLE_CYCLES=100000,NETWORK_INTERVAL_CYCLES=13333333,WATCHDOG_CYCLES=250000000
)(
 input capture_clk,axi_clk,rst_n,frame_start,write_done_toggle,writer_idle,
 input sender_busy,reader_done,input[1:0]hdmi_read_bank,input[3:0]hdmi_protected,
 output capture_en,output reg frame_publish,output capture_ready,
 output reg send_toggle,output fault,output reg[2:0]fault_stage,
 output[2:0]debug_state,output[1:0]debug_writes,
 output[ADDR_WIDTH-1:0]write_base,published_base,network_base,
 output reg display_ready,output reg network_reserved,
 output reg[31:0]published_count,network_count
);
reg[2:0]cr=0,ar=0;
always @(posedge capture_clk or negedge rst_n)
 if(!rst_n)cr<=0;else cr<={cr[1:0],1'b1};
always @(posedge axi_clk or negedge rst_n)
 if(!rst_n)ar<=0;else ar<={ar[1:0],1'b1};
wire cam_rst=cr[2],axi_rst=ar[2];
reg[1:0]grant_bank,published_bank,network_bank;
reg grant_active,grant_toggle,commit_toggle;
reg[2:0]grant_sync,commit_sync;
reg grant_seen,commit_seen,grant_available;
always @(posedge capture_clk or negedge cam_rst)begin
 if(!cam_rst)begin grant_sync<=0;grant_seen<=0;grant_available<=0;commit_toggle<=0;end
 else begin
  grant_sync<={grant_sync[1:0],grant_toggle};
  if(grant_sync[2]!=grant_seen)begin grant_seen<=grant_sync[2];grant_available<=1;end
  if(capture_en)grant_available<=0;
  if(frame_publish)commit_toggle<=~commit_toggle;
 end
end
assign capture_ready=cam_rst&&grant_available;
localparam BOOT=0,ALIGN=1,CAPTURE=2,DRAIN=3,FAULT=7;
reg[2:0]state,warm_frames;
reg[31:0]camera_timer;
reg[1:0]writes,required_writes;
reg warming,write_seen;
assign capture_en=state==CAPTURE;
assign debug_state=state;assign debug_writes=writes;
always @(posedge capture_clk or negedge cam_rst)begin
 if(!cam_rst)begin
  state<=BOOT;camera_timer<=0;warming<=1;warm_frames<=0;
  writes<=0;required_writes<=2;write_seen<=0;frame_publish<=0;fault_stage<=0;
 end else begin
  frame_publish<=0;write_seen<=write_done_toggle;
  if(state!=FAULT)fault_stage<=state;
  if((state==CAPTURE||state==DRAIN)&&write_done_toggle!=write_seen&&writes<2)writes<=writes+1'b1;
  case(state)
   BOOT:if(camera_timer==BOOT_CYCLES-1)begin state<=ALIGN;camera_timer<=0;end
        else camera_timer<=camera_timer+1'b1;
   ALIGN:if(frame_start&&capture_ready)begin
     state<=CAPTURE;camera_timer<=0;writes<=0;warm_frames<=0;required_writes<=warming?2:1;
    end else if(camera_timer==WATCHDOG_CYCLES-1)state<=FAULT;
    else camera_timer<=camera_timer+1'b1;
   CAPTURE:begin
    // Steady-state commit follows the last write response, during camera
    // blanking. The next camera VS can therefore start another full frame.
    if(!warming&&writes>=1)begin state<=DRAIN;camera_timer<=0;end
    else if(warming&&frame_start)begin
     if(warm_frames==4)begin state<=DRAIN;warming<=0;camera_timer<=0;end
     else warm_frames<=warm_frames+1'b1;
    end
    if(camera_timer==WATCHDOG_CYCLES-1)state<=FAULT;
    else camera_timer<=camera_timer+1'b1;
   end
   DRAIN:if(writes>=required_writes&&writer_idle)begin frame_publish<=1;state<=ALIGN;camera_timer<=0;end
    else if(camera_timer==WATCHDOG_CYCLES-1)state<=FAULT;
    else camera_timer<=camera_timer+1'b1;
   default:state<=FAULT;
  endcase
 end
end
reg published_valid,net_fault;
reg[1:0]sender_sync,reader_sync;
reg[2:0]network_state;
reg[31:0]network_timer,network_spacing,last_sent_generation,reserved_generation;
integer candidate,i;
always @*begin
 candidate=-1;
 for(i=3;i>=0;i=i-1)
  if(!hdmi_protected[i]&&i!=hdmi_read_bank&&(!published_valid||i!=published_bank)&&
     (!network_reserved||i!=network_bank))candidate=i;
end
always @(posedge axi_clk or negedge axi_rst)begin
 if(!axi_rst)begin
  grant_bank<=0;published_bank<=0;network_bank<=0;grant_active<=0;grant_toggle<=0;
  commit_sync<=0;commit_seen<=0;published_valid<=0;display_ready<=0;
  sender_sync<=0;reader_sync<=0;network_state<=0;network_timer<=0;
  network_reserved<=0;send_toggle<=0;net_fault<=0;published_count<=0;network_count<=0;
  network_spacing<=NETWORK_INTERVAL_CYCLES-1;last_sent_generation<=0;reserved_generation<=0;
 end else begin
  commit_sync<={commit_sync[1:0],commit_toggle};
  if(network_spacing<NETWORK_INTERVAL_CYCLES-1)network_spacing<=network_spacing+1'b1;
  sender_sync<={sender_sync[0],sender_busy};reader_sync<={reader_sync[0],reader_done};
  if(commit_sync[2]!=commit_seen)begin
   commit_seen<=commit_sync[2];published_bank<=grant_bank;published_valid<=1;
   published_count<=published_count+1'b1;grant_active<=0;
  end else if(!grant_active&&candidate>=0)begin
   grant_bank<=candidate;grant_toggle<=~grant_toggle;grant_active<=1;
  end
  if(published_valid&&hdmi_read_bank==published_bank)display_ready<=1;
  case(network_state)
   0:if(published_valid&&published_count!=last_sent_generation&&network_spacing==NETWORK_INTERVAL_CYCLES-1)begin
     network_bank<=published_bank;reserved_generation<=published_count;network_reserved<=1;network_timer<=0;network_state<=1;
    end
   1:if(network_timer==SETTLE_CYCLES-1)begin
     send_toggle<=~send_toggle;network_spacing<=0;last_sent_generation<=reserved_generation;network_count<=network_count+1'b1;network_state<=2;network_timer<=0;
    end else network_timer<=network_timer+1'b1;
   2:if(sender_sync[1])begin network_state<=3;network_timer<=0;end
    else if(network_timer==WATCHDOG_CYCLES-1)begin net_fault<=1;network_state<=7;end
    else network_timer<=network_timer+1'b1;
   3:if(!sender_sync[1]&&reader_sync[1])begin network_reserved<=0;network_state<=0;network_timer<=0;end
    else if(network_timer==WATCHDOG_CYCLES-1)begin net_fault<=1;network_state<=7;end
    else network_timer<=network_timer+1'b1;
   default:net_fault<=1;
  endcase
 end
end
assign fault=state==FAULT||net_fault;
assign write_base={{(ADDR_WIDTH-2){1'b0}},grant_bank}<<BANK_SHIFT;
assign published_base={{(ADDR_WIDTH-2){1'b0}},published_bank}<<BANK_SHIFT;
assign network_base={{(ADDR_WIDTH-2){1'b0}},network_bank}<<BANK_SHIFT;
endmodule

// A completed frame is identified by its physical final DDR burst, rather
// than the phase of a free-running beat counter carried across captures.
module ge_write_commit #(
 parameter ADDR_WIDTH=32,BANK_SHIFT=21,FRAME_BYTES=2073600,AXI_BYTES=16
)(input clk,rst_n,input[ADDR_WIDTH-1:0]awaddr,input[7:0]awlen,
 input awvalid,awready,wvalid,wready,wlast,output reg done_toggle);
reg final_burst;
wire[ADDR_WIDTH-1:0]offset=awaddr&((1<<BANK_SHIFT)-1);
wire[ADDR_WIDTH-1:0]burst_end=offset+(({24'd0,awlen}+32'd1)*AXI_BYTES);
always @(posedge clk or negedge rst_n)begin
 if(!rst_n)begin final_burst<=0;done_toggle<=0;end
 else begin
  if(awvalid&&awready)final_burst<=burst_end==FRAME_BYTES;
  if(wvalid&&wready&&wlast&&final_burst)done_toggle<=~done_toggle;
 end
end
endmodule
