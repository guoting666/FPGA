"""Conservative contour evidence for simple, complete geometric targets.

Fit scores are geometric similarity measures, never neural probabilities.
"""
import time
import cv2
import numpy as np

NAMES = ("三角形", "矩形", "圆形")


def iou(a, b):
    a, b = np.asarray(a), np.asarray(b)
    inter = np.maximum(np.minimum(a[2:], b[2:]) - np.maximum(a[:2], b[:2]), 0).prod()
    return float(inter / (np.maximum(a[2:] - a[:2], 0).prod() +
                          np.maximum(b[2:] - b[:2], 0).prod() - inter + 1e-8))


def edge_error(contour, polygon):
    """Distance to finite straight sides; protects against curved impostors."""
    points = contour[:, 0].astype(float)
    starts = polygon[:, 0].astype(float)
    edges = np.roll(starts, -1, axis=0) - starts
    delta = points[:, None, :] - starts[None, :, :]
    along = np.clip(np.sum(delta * edges, axis=2) /
                    np.maximum(np.sum(edges * edges, axis=1), 1), 0, 1)
    distances = np.linalg.norm(delta - along[:, :, None] * edges, axis=2).min(axis=1)
    _, _, w, h = cv2.boundingRect(contour)
    return float(np.sqrt(np.mean(distances ** 2)) / max(np.hypot(w, h), 1))


def classify(contour):
    perimeter = cv2.arcLength(contour, True)
    area = abs(cv2.contourArea(contour))
    if perimeter <= 0 or area <= 0:
        return None
    hull_area = cv2.contourArea(cv2.convexHull(contour))
    if hull_area <= 0 or area / hull_area < .945:
        return None
    poly = cv2.approxPolyDP(contour, .018 * perimeter, True)
    if not cv2.isContourConvex(poly):
        return None
    p = poly[:, 0].astype(float)
    if len(p) in (3, 4):
        if len(p) == 3:
            # A coarse polygon clips blurry triangle tips. Fit the outer three
            # straight sides instead, then demand close contour support.
            triangle_area, triangle = cv2.minEnclosingTriangle(contour)
            fill = area / max(triangle_area, 1)
            if fill >= .90 and edge_error(contour, triangle) <= .02:
                return 0, float(fill)
            return None
        # Curved sides must not turn a circle into a coarse triangle/rectangle.
        residual = abs(area - cv2.contourArea(poly)) / area
        if residual > .075 or edge_error(contour, poly) > .018:
            return None
        v = p - np.roll(p, 1, axis=0)
        lengths = np.linalg.norm(v, axis=1)
        cosines = np.abs(np.sum(v * np.roll(v, 1, axis=0), axis=1) /
                         np.maximum(lengths * np.roll(lengths, 1), 1e-6))
        if max(cosines) < .34:
            return 1, float(1 - max(cosines))
        return None
    fine = cv2.approxPolyDP(contour, .009 * perimeter, True)
    # Reject exact pentagons/hexagons/octagons rather than labeling them circles.
    if len(fine) < 10 or len(contour) < 16:
        return None
    (_, _), axes, _ = cv2.fitEllipse(contour)
    if min(axes) <= 0 or min(axes) / max(axes) < .78:
        return None
    (cx, cy), axes, angle = cv2.fitEllipse(contour)
    theta = np.deg2rad(angle)
    delta = contour[:, 0].astype(float) - (cx, cy)
    rotated = delta @ np.array([[np.cos(theta), -np.sin(theta)],
                                [np.sin(theta), np.cos(theta)]])
    radius = np.linalg.norm(rotated / (np.array(axes) / 2), axis=1)
    radial_error = float(np.sqrt(np.mean((radius - 1) ** 2)))
    ellipse_fill = area / (np.pi * axes[0] * axes[1] / 4)
    if radial_error > .04 or not .94 < ellipse_fill < 1.04:
        return None
    return 2, float(min(ellipse_fill, 1 - radial_error, 1.))


def find_shapes(bgr):
    h, w = bgr.shape[:2]
    factor = min(1., 960 / w, 720 / h)
    small = cv2.resize(bgr, (round(w * factor), round(h * factor)), interpolation=cv2.INTER_AREA)
    sh, sw = small.shape[:2]
    # An even box filter suppresses the RAW8 Bayer checkerboard in the board feed.
    # Keep the source image intact; use this only for contour extraction.
    blurred = cv2.GaussianBlur(cv2.blur(small, (2, 2)), (3, 3), .7)
    gray = cv2.cvtColor(blurred, cv2.COLOR_BGR2GRAY)
    hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)
    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    masks = [binary, 255 - binary, cv2.inRange(hsv, (0, 65, 38), (179, 255, 255)),
             cv2.Canny(gray, 45, 130)]
    found = []
    min_area = max(140, sh * sw * .0008)
    for mask in masks:
        contours, _ = cv2.findContours(mask, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        # Bound work on highly textured camera frames.
        for c in sorted(contours, key=cv2.contourArea, reverse=True)[:180]:
            area = abs(cv2.contourArea(c))
            if area < min_area or area > sh * sw * .7:
                continue
            x, y, bw, bh = cv2.boundingRect(c)
            if min(bw, bh) < 18 or x <= 1 or y <= 1 or x + bw >= sw - 1 or y + bh >= sh - 1:
                continue
            result = classify(c)
            if result is None:
                continue
            cls, fit = result
            polygon = None
            if cls == 1:
                polygon = cv2.approxPolyDP(c, .018 * cv2.arcLength(c, True), True)[:, 0]
            elif cls == 0:
                polygon = cv2.minEnclosingTriangle(c)[1][:, 0]
            points = (np.clip(polygon / factor, [0, 0], [w-1, h-1]).tolist()
                      if polygon is not None else None)
            found.append({"polygon": points, "class_id": cls, "name": NAMES[cls], "confidence": None,
                          "geometry_score": fit, "source": "geometry",
                          "xyxy": [x / factor, y / factor, (x + bw) / factor, (y + bh) / factor]})
    # Collapse inner/outer ring contours, including conflicting coarse candidates.
    found.sort(key=lambda p: (p["xyxy"][2] - p["xyxy"][0]) *
                            (p["xyxy"][3] - p["xyxy"][1]), reverse=True)
    keep = []
    for item in found:
        if not any(iou(item["xyxy"], k["xyxy"]) > .65 for k in keep):
            keep.append(item)
    return keep[:60]


class ShapePipeline:
    def __init__(self, detector):
        self.detector = detector
        self.previous = []

    def predict(self, bgr, confidence, mode="verified", roi=None, stable=False, targets="shapes", digit_confidence=.93, tomato_confidence=.40):
        start = time.perf_counter()
        h, w = bgr.shape[:2]
        roi = roi or [0, 0, 100, 100]
        x1, y1 = round(w * roi[0] / 100), round(h * roi[1] / 100)
        x2, y2 = round(w * (roi[0] + roi[2]) / 100), round(h * (roi[1] + roi[3]) / 100)
        crop = bgr[y1:y2, x1:x2]
        if targets == "tomato":
            predictions,timing=self.detector.tomato.predict(crop,tomato_confidence)
        else:
            yolo, timing = (self.detector.predict(crop, confidence) if mode != "geometry" and targets != "digits" else
                            ([], {"invoke_ms": 0., "preprocess_ms": 0., "postprocess_ms": 0.}))
            for p in yolo:
                p["source"] = "yolo"
            if mode == "yolo":
                predictions = yolo
            else:
                shapes = find_shapes(crop) if targets != "digits" else []
                for shape in shapes:
                    matches = [p for p in yolo if iou(p["xyxy"], shape["xyxy"]) > .40]
                    if matches:
                        best = max(matches, key=lambda p: iou(p["xyxy"], shape["xyxy"]))
                        shape["yolo_class_id"] = best["class_id"]
                        shape["yolo_confidence"] = best["confidence"]
                        shape["source"] = "yolo+geometry" if best["class_id"] == shape["class_id"] else "geometry-corrected"
                predictions = shapes
            if targets in {"both","digits"}:
                digit_predictions,digit_timing=self.detector.digits.predict(crop,digit_confidence)
                timing.update(digit_timing)
                # Shape and digit tasks are independent: the user explicitly wants
                # a digit 4 and its triangular inner contour to remain visible.
                predictions=predictions+digit_predictions
        for p in predictions:
            p["xyxy"] = [p["xyxy"][0] + x1, p["xyxy"][1] + y1,
                         p["xyxy"][2] + x1, p["xyxy"][3] + y1]
            if p.get("polygon"):
                p["polygon"] = [[px + x1, py + y1] for px, py in p["polygon"]]
        # Confirm two consecutive processed frames; never draw a previous frame's box.
        current = predictions
        if stable:
            predictions = [p for p in current if any(p["class_id"] == old["class_id"] and
                           iou(p["xyxy"], old["xyxy"]) > .45 for old in self.previous)]
        self.previous = current
        timing["inference_total_ms"] = (time.perf_counter() - start) * 1000
        timing["mode"] = mode
        return predictions, timing
