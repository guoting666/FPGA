from pathlib import Path
import argparse,sys,json,time
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from digits import DigitDetector
from digit_common import normalize_digit

def metrics(model,images,labels,threshold):
    probs=np.stack([model.classify(im) for im in images]);pred=probs.argmax(1);order=np.sort(probs,axis=1)
    accept=(pred<10)&(order[:,-1]>=threshold)&(order[:,-1]-order[:,-2]>=.2)
    good=pred==labels;cm=np.zeros((11,11),int)
    np.add.at(cm,(labels,pred),1)
    return dict(examples=len(labels),top1_accuracy=float(good.mean()),accepted=int(accept.sum()),correct_accepted=int((accept&good).sum()),accepted_precision=float((accept&good).sum()/max(accept.sum(),1)),correct_and_accepted_rate=float((accept&good).mean()),threshold=threshold,per_digit=[dict(digit=int(k),examples=int((labels==k).sum()),top1_accuracy=float(good[labels==k].mean()),correct_and_accepted_rate=float((accept&good)[labels==k].mean())) for k in range(10)],confusion_matrix_true_rows_pred_columns=cm.tolist())

def main():
    pa=argparse.ArgumentParser();pa.add_argument('--hwd',type=Path,required=True);pa.add_argument('--mnist',type=Path,required=True);a=pa.parse_args()
    cv2.setNumThreads(1);d=DigitDetector();split=np.load(ROOT/'model/digits/hwd_split_indices.npz',allow_pickle=False);images=np.load(a.hwd/'Images28.npy',allow_pickle=False);info=np.load(a.hwd/'WriterInfo.npy',allow_pickle=False)
    report=dict(model_sha256=d.sha256,threshold=.93,scope='Classification of isolated normalized digit crops. Not full-image detection mAP, real-camera accuracy or FPGA testing.',test_used_for_training=False,board_tested=False)
    report['hwd_writer_disjoint_test']=metrics(d,[np.clip(255-images[i],0,255).astype(np.uint8) for i in split['test']],info[split['test'],0],.93)
    mn=np.load(a.mnist,allow_pickle=False);report['mnist_official_test']=metrics(d,mn['x_test'],mn['y_test'],.93)
    (ROOT/'reports/digit_evaluation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({k:{m:r[m] for m in ['examples','top1_accuracy','accepted_precision','correct_and_accepted_rate']} for k,r in report.items() if isinstance(r,dict)},indent=2))
if __name__=='__main__':main()
