"""Send local video as T6V1 UDP frames. PC loopback test; not FPGA firmware."""
import argparse
from pathlib import Path
import socket
import sys
import time
import cv2

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from udp_video import packetize, RGB565_LE, RGB888, GRAY8, JPEG


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--video", type=Path)
    parser.add_argument("--fps", type=float, default=10)
    parser.add_argument("--width", type=int, default=320)
    parser.add_argument("--format", choices=["rgb565", "rgb", "gray", "jpeg"], default="rgb565")
    parser.add_argument("--frames", type=int, default=0, help="0 means until Ctrl+C")
    args = parser.parse_args()
    if not 0 < args.fps <= 60 or not 32 <= args.width <= 1920:
        parser.error("fps must be (0,60], width must be 32..1920")
    path = args.video or Path(__file__).resolve().parents[1] / "samples/demo.avi"
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        parser.error("video cannot be opened")
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    fmt = {"rgb565": RGB565_LE, "rgb": RGB888, "gray": GRAY8, "jpeg": JPEG}[args.format]
    fid = 0
    print(f"T6V1 test sender -> {args.host}:{args.port}; {args.format}; Ctrl+C to stop", flush=True)
    try:
        while args.frames == 0 or fid < args.frames:
            started = time.monotonic()
            ok, frame = cap.read()
            if not ok:
                cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                ok, frame = cap.read()
                if not ok:
                    raise RuntimeError("empty video")
            height = round(frame.shape[0] * args.width / frame.shape[1])
            if height > 1080:
                raise ValueError("resized frame exceeds 1080 rows")
            frame = cv2.resize(frame, (args.width, height), interpolation=cv2.INTER_AREA)
            for index, packet in enumerate(packetize(frame, fid, fmt)):
                sock.sendto(packet, (args.host, args.port))
                # Pace bursts so this also exercises a realistic bounded receive queue.
                if index % 16 == 15:
                    time.sleep(.001)
            fid += 1
            time.sleep(max(0, started + 1 / args.fps - time.monotonic()))
    except KeyboardInterrupt:
        pass
    finally:
        cap.release()
        sock.close()


if __name__ == "__main__":
    main()
