"""Loss, ACK, ordering and expiry tests for physical HDMI feedback delivery."""
from pathlib import Path
import sys,json,socket
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hdmi_delivery import HDMIDelivery
from hdmi_feedback import decode_polygons
from udp_video import UDPReceiver

def main():
 checks=[];now=[0.];packets=[]
 d=HDMIDelivery(packets.append,clock=lambda:now[0])
 p=[dict(class_id=14,confidence=.9,xyxy=[10,20,60,80])]
 d.submit(10,640,360,p,2,(9,0,27));assert decode_polygons(packets[-1])[0]==10
 now[0]=.08;d.pump();assert packets[0]==packets[1] and d.state()['retries']==1
 d.observe((10,1,31));assert d.pending is not None # expired is not displayed
 d.observe((9,1,27));assert d.pending is not None
 d.observe((10,2,27));assert d.pending is not None
 d.observe((10,1,27));assert d.pending is None and d.state()['acknowledged']==1
 now[0]=.3;d.pump();assert len(packets)==2
 checks.append('dropped first datagram retried byte-for-byte; only matching unexpired frame/count ACK stops retries')
 d.submit(11,640,360,p,2,(10,1,27));d.submit(12,640,360,[],2,(10,1,27))
 n=len(packets);now[0]=.38;d.pump()
 assert len(packets)==n+1 and decode_polygons(packets[-1])==(12,[])
 a=d.state()['acknowledged'];d.observe((11,1,27));assert d.pending['frame_id']==12 and d.state()['acknowledged']==a+1
 d.observe((11,1,27));assert d.state()['acknowledged']==a+1
 d.observe((12,0,27));assert d.pending is None
 checks.append('newest result supersedes older pending box; empty result clears immediately and never retries an old box')
 d.submit(13,640,360,p,2,(12,0,27));n=len(packets)
 for t in [.46,.54,.62,.8,.9]:now[0]=t;d.pump()
 assert len(packets)-n==2 and d.pending is None and d.state()['unacknowledged']==1
 checks.append('three total attempts and 450ms lifetime bound: no unbounded retransmit or stale-box retention')
 d.submit(14,640,360,[dict(p[0],class_id=21)],2,(13,1,27))
 assert decode_polygons(packets[-1])==(14,[]) and d.state()['unsupported_count']==1
 checks.append('unsupported firmware classes reported explicitly, never relabeled as another disease')
 count=[0]
 def failing(packet):count[0]+=1;raise OSError('test send failure')
 e=HDMIDelivery(failing,clock=lambda:now[0]);e.submit(15,640,360,p,2,(0,0,27))
 now[0]=1.;e.pump();assert e.state()['errors']==2 and e.state()['sent']==0
 checks.append('socket send errors counted; successful-send count is not mistaken for an HDMI ACK')
 # A real loopback socket verifies UDPReceiver uses the delivery controller.
 board=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);board.bind(('127.0.0.2',0));board.settimeout(1)
 port=board.getsockname()[1];r=UDPReceiver(dict(bind_ip='127.0.0.1',source_ip='127.0.0.2',port=port))
 try:
  r.assembler.last_version=2;r.assembler.last_feedback=(0,0,27)
  r.send_results(16,640,360,p)
  data,peer=board.recvfrom(2048)
  assert decode_polygons(data)[0]==16 and peer==('127.0.0.1',port)
  assert r.state()['hdmi_feedback']['last_sent_count']==1
 finally:r.close();board.close()
 checks.append('actual UDP receiver integration keeps correct endpoint, wire frame and polygon coordinates')
 report=dict(passed=True,checks=checks,count=len(checks),scope='Deterministic delivery logic and real loopback UDP, not physical HDMI visual acceptance')
 dest=Path(__file__).resolve().parents[1]/'reports/hdmi_delivery_verification.json'
 dest.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 print(json.dumps(report))

if __name__=='__main__':main()
