# 模型与训练数据来源

模型 ShapeYOLO-32K-v1：自定义轻量 YOLO 风格检测器，32,632 参数，输入 RGB 192×192，INT8 TFLite；不是官方 Ultralytics YOLOv8。

权重由本任务此前完成的 Mendeley 训练版复制，本次不改权重。原训练数据包含：

Anas, EL KORCHI (2020), “2D geometric shapes dataset”, Mendeley Data, V1.
DOI: https://doi.org/10.17632/wzr2yv7r53.1
License: CC BY 4.0, https://creativecommons.org/licenses/by/4.0/
Source: https://data.mendeley.com/datasets/wzr2yv7r53/1

修改：选取 Triangle/Square/Circle，映射为三角形/矩形/圆形，Square 归入矩形；生成目标框；补充非正方形矩形、组合目标、其他形状负样本与空背景；按来源像素 hash 分割训练/验证/测试。

旧纯 YOLO INT8 合成测试集 mAP50 82.70%，mAP50:95 55.51%；阈值 .96 时 P 75.54%、R 69.27%。这些指标来自此前纯模型测试，**不适用于新增轮廓模式或真实板卡画面**。完整训练包位于同级 `ShapeYOLO_Mendeley_Training`，本次未重复训练。
