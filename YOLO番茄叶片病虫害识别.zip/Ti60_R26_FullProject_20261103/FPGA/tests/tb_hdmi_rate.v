`timescale 1ns/1ps
module tb_hdmi_rate;
reg axi=0,clk=0,rst=0,reset=1,period=0,ready=0;always #5 axi=~axi;always #6.734 clk=~clk;
localparam WIDTH=960,HEIGHT=16,TOTAL=WIDTH*HEIGHT;
wire empty,full,read,valid,sof,eol;wire[127:0]fifo_data;wire[15:0]data;
reg[127:0]input_data=0;reg we=0;integer producer=0,k,accepted=0,cycles=0,last_cycle=0,bubbles=0,trial=0,recovery=32;
ge_hdmi_stream #(.FRAME_WIDTH(WIDTH),.FRAME_HEIGHT(HEIGHT)) stream(.clk(clk),.rst_n(rst),.frame_period(period),
 .fifo_empty(empty),.fifo_data(fifo_data),.fifo_read(read),.axis_data(data),.axis_valid(valid),.axis_ready(ready),.axis_sof(sof),.axis_eol(eol));
DC_FIFO #(.DATA_WIDTH(128),.FIFO_DEPTH(64)) fifo(.Reset(reset),.WrClk(axi),.WrEn(we),.WrData(input_data),.WrFull(full),
 .RdClk(clk),.RdEn(read),.RdData(fifo_data),.RdEmpty(empty));
always @(negedge axi)begin
 we=0;
 if(reset)recovery=32;
 else if(recovery!=0)recovery=recovery-1;
 else if(rst&&!full&&producer<TOTAL/8)begin
  we=1;for(k=0;k<8;k=k+1)input_data[127-k*16-:16]=(producer*8+k)&65535;
  producer=producer+1;
 end
end
reg stalled=0;reg[15:0]held=0;reg held_sof=0,held_eol=0;
always @(posedge clk)begin
 cycles=cycles+1;
 if(rst&&!reset)begin
  if(stalled&&(data!==held||!valid||sof!==held_sof||eol!==held_eol))$fatal(1,"AXI payload changed under backpressure");
  stalled=valid&&!ready;held=data;held_sof=sof;held_eol=eol;
  if(valid&&ready)begin
   if(data!==(accepted&65535)||sof!=(accepted==0)||eol!=(accepted%WIDTH==WIDTH-1))
    $fatal(1,"HDMI unpacker word mismatch %0d %h sof %b eol %b",accepted,data,sof,eol);
   if(trial==0&&accepted>0&&cycles!=last_cycle+1)bubbles=bubbles+1;
   accepted=accepted+1;last_cycle=cycles;
  end
 end else stalled=0;
end
initial begin
 repeat(20)@(negedge clk);rst=1;period=1;
 repeat(40)@(negedge clk);reset=0;ready=1;
 repeat(200)@(negedge clk);period=0;
 wait(accepted==TOTAL);repeat(20)@(negedge clk);
 if(valid||bubbles!=0)$fatal(1,"HDMI full-rate frame had bubbles %0d or extra words",bubbles);
 trial=1;ready=0;reset=1;period=1;accepted=0;producer=0;
 repeat(40)@(negedge clk);reset=0;
 repeat(200)begin @(negedge clk);ready=cycles%7!=0;end
 period=0;
 while(accepted<TOTAL)begin @(negedge clk);ready=(cycles%7!=0&&cycles%11!=0);end
 ready=0;repeat(20)@(negedge clk);
 if(valid)$fatal(1,"Extra words after frame");
 trial=2;ready=0;reset=1;period=1;accepted=0;producer=0;
 repeat(40)@(negedge clk);reset=0;ready=1;
 repeat(200)@(negedge clk);period=0;
 wait(accepted>411);@(negedge clk);ready=0;reset=1;
 repeat(40)@(negedge clk);period=1;accepted=0;producer=0;
 repeat(40)@(negedge clk);reset=0;ready=1;
 repeat(200)@(negedge clk);period=0;
 wait(accepted==TOTAL);repeat(20)@(negedge clk);
 if(valid)$fatal(1,"Extra words after abandoned-frame recovery");
 $display("PASS three 960x16 frames, one word/clock without bubbles, backpressure, short VS and abandoned-frame recovery");$finish;
end
initial begin #3000000;$fatal(1,"timeout");end
endmodule
