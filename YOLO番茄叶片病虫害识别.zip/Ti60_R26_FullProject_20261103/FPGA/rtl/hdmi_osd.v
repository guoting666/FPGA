// Cyclic polygon borders. Coefficients are prepared in VS blanking using two
// shared multipliers; raster evaluation uses additions, never pixel multipliers.
// RGB, DE, HS and VS all have the same four clock pipeline latency.
module hdmi_osd #(parameter MAX_BOXES=16, WIDTH=1920,HEIGHT=1080,TTL_FRAMES=45)(
 input clk,rst_n,input in_vs,in_hs,in_de,input [23:0] in_bgr,
 input [MAX_BOXES*128-1:0] mailbox_boxes,input [4:0] mailbox_count,
 input request_toggle,output reg acknowledge_toggle,output reg display_expired,
 output out_vs,out_hs,out_de,output reg [23:0] out_bgr);
localparam EDGES=MAX_BOXES*4;
reg [MAX_BOXES*5-1:0] active_classes;reg [4:0] active_count;
reg [1:0] req_sync;reg vs_d,de_d;reg [10:0] x,y;localparam AGE_BITS=$clog2(TTL_FRAMES+1);reg [AGE_BITS-1:0] age;
wire frame_edge=in_vs&&!vs_d;
reg building,pending_toggle;reg [1:0] build_state;reg [5:0] edge_index;
reg signed [23:0] origin[0:EDGES-1],line_e[0:EDGES-1],pixel_e[0:EDGES-1];
reg signed [11:0] dx[0:EDGES-1],dy[0:EDGES-1];
reg [12:0] tolerance[0:EDGES-1];reg axis_x[0:EDGES-1];
reg [10:0] lo[0:EDGES-1],hi[0:EDGES-1];reg edge_valid[0:EDGES-1];
reg [10:0] label_x[0:MAX_BOXES-1],label_y[0:MAX_BOXES-1];
reg signed [11:0] work_dx,work_dy,work_x,work_y;
reg signed [23:0] product_a,product_b;
reg [10:0] work_lo,work_hi;reg work_axis;reg [12:0] work_tolerance;
reg [127:0] build_box;reg [21:0] pa,pb;reg signed [11:0] delta_x,delta_y;
reg [11:0] abs_dx,abs_dy;reg [10:0] min_x,min_y;integer j,q;
always @*begin
 // Parser holds the mailbox stable until coefficient preparation is ACKed.
 build_box=mailbox_boxes[(edge_index>>2)*128+:128];
 case(edge_index[1:0])
  0:begin pa=build_box[87:66];pb=build_box[65:44];end
  1:begin pa=build_box[65:44];pb=build_box[43:22];end
  2:begin pa=build_box[43:22];pb=build_box[21:0];end
  default:begin pa=build_box[21:0];pb=build_box[87:66];end
 endcase
 delta_x=$signed({1'b0,pb[21:11]})-$signed({1'b0,pa[21:11]});
 delta_y=$signed({1'b0,pb[10:0]})-$signed({1'b0,pa[10:0]});
 abs_dx=delta_x<0?-delta_x:delta_x;abs_dy=delta_y<0?-delta_y:delta_y;
 min_x=build_box[87:77];min_y=build_box[76:66];
 for(q=0;q<4;q=q+1)begin
  if(build_box[q*22+11+:11]<min_x)min_x=build_box[q*22+11+:11];
  if(build_box[q*22+:11]<min_y)min_y=build_box[q*22+:11];
 end
end
always @(posedge clk or negedge rst_n)begin
 if(!rst_n)begin
  req_sync<=0;acknowledge_toggle<=0;active_classes<=0;active_count<=0;display_expired<=1;
  age<=TTL_FRAMES;vs_d<=0;de_d<=0;x<=0;y<=0;building<=0;pending_toggle<=0;build_state<=0;edge_index<=0;
  work_dx<=0;work_dy<=0;work_x<=0;work_y<=0;product_a<=0;product_b<=0;work_lo<=0;work_hi<=0;work_axis<=0;work_tolerance<=0;
  for(j=0;j<EDGES;j=j+1)begin origin[j]<=0;line_e[j]<=0;pixel_e[j]<=0;dx[j]<=0;dy[j]<=0;tolerance[j]<=0;axis_x[j]<=0;lo[j]<=0;hi[j]<=0;edge_valid[j]<=0;end
  for(j=0;j<MAX_BOXES;j=j+1)begin label_x[j]<=0;label_y[j]<=0;end
 end else begin
  req_sync<={req_sync[0],request_toggle};vs_d<=in_vs;de_d<=in_de;
  if(frame_edge)begin
   x<=0;y<=0;
   for(j=0;j<EDGES;j=j+1)begin line_e[j]<=origin[j];pixel_e[j]<=origin[j];end
   if(req_sync[1]!=acknowledge_toggle && !building)begin
    for(j=0;j<MAX_BOXES;j=j+1)active_classes[j*5+:5]<=mailbox_boxes[j*128+123+:5];
    active_count<=mailbox_count;pending_toggle<=req_sync[1];age<=0;display_expired<=1;building<=1;build_state<=0;edge_index<=0;
   end else if(age<TTL_FRAMES)age<=age+1'b1;
   else if(!building)begin active_count<=0;display_expired<=1;end
  end else if(in_de)begin
   if(x<WIDTH-1)x<=x+1'b1;
   for(j=0;j<EDGES;j=j+1)pixel_e[j]<=pixel_e[j]+dy[j];
  end else if(de_d)begin
   x<=0;if(y<HEIGHT-1)y<=y+1'b1;
   for(j=0;j<EDGES;j=j+1)begin line_e[j]<=line_e[j]-dx[j];pixel_e[j]<=line_e[j]-dx[j];end
  end
  if(building)case(build_state)
   0:begin
    work_dx<=delta_x;work_dy<=delta_y;work_x<=$signed({1'b0,pa[21:11]});work_y<=$signed({1'b0,pa[10:0]});
    work_axis<=abs_dx>=abs_dy;work_tolerance<=({1'b0,abs_dx}+{1'b0,abs_dy})<<1;
    if(abs_dx>=abs_dy)begin work_lo<=pa[21:11]<pb[21:11]?pa[21:11]:pb[21:11];work_hi<=pa[21:11]>pb[21:11]?pa[21:11]:pb[21:11];end
    else begin work_lo<=pa[10:0]<pb[10:0]?pa[10:0]:pb[10:0];work_hi<=pa[10:0]>pb[10:0]?pa[10:0]:pb[10:0];end
    if(edge_index[1:0]==0)begin label_x[edge_index>>2]<=min_x;label_y[edge_index>>2]<=min_y;end
    build_state<=1;
   end
   1:begin product_a<=work_dx*work_y;product_b<=work_dy*work_x;build_state<=2;end
   2:begin
    origin[edge_index]<=product_a-product_b;line_e[edge_index]<=product_a-product_b;pixel_e[edge_index]<=product_a-product_b;
    dx[edge_index]<=work_dx;dy[edge_index]<=work_dy;tolerance[edge_index]<=work_tolerance;axis_x[edge_index]<=work_axis;
    lo[edge_index]<=work_lo>2?work_lo-2:0;hi[edge_index]<=work_hi+2;edge_valid[edge_index]<=work_dx!=0 || work_dy!=0;
    build_state<=0;
    if(edge_index==EDGES-1)begin building<=0;display_expired<=0;acknowledge_toggle<=pending_toggle;end
    else edge_index<=edge_index+1'b1;
   end
  endcase
 end
end
function [23:0] color;input [4:0] c;begin case(c)
 0:color=24'h80e020;1:color=24'hff9050;2:color=24'h00d8ff;15:color=24'h88c93a;13,14,16,17,18,19,20:color=24'h4987f4;default:color=24'hff90e0;
endcase end endfunction
function [3:0] label_chars;input [4:0] cls;begin case(cls)
 1,2:label_chars=2;
 13:label_chars=3;
 14:label_chars=3;
 15:label_chars=4;
 16:label_chars=6;
 17:label_chars=3;
 18:label_chars=5;
 19:label_chars=5;
 20:label_chars=3;
 default:label_chars=3;endcase end endfunction
function [5:0] glyph;input [4:0] cls;input [2:0] slot;begin
 if(cls==0)begin case(slot)0:glyph=0;1:glyph=1;default:glyph=2;endcase end
 else if(cls==1)glyph=slot==0?3:2;
 else if(cls==2)glyph=slot==0?4:2;
 else if(cls<=12)glyph=slot==0?5:slot==1?6:7+cls-3;
 else case(cls)
 13:begin case(slot)0:glyph=17;1:glyph=18;2:glyph=19;default:glyph=19;endcase end
 14:begin case(slot)0:glyph=20;1:glyph=21;2:glyph=19;default:glyph=19;endcase end
 15:begin case(slot)0:glyph=22;1:glyph=23;2:glyph=24;3:glyph=25;default:glyph=25;endcase end
 16:begin case(slot)0:glyph=26;1:glyph=27;2:glyph=28;3:glyph=20;4:glyph=29;5:glyph=19;default:glyph=19;endcase end
 17:begin case(slot)0:glyph=30;1:glyph=18;2:glyph=19;default:glyph=19;endcase end
 18:begin case(slot)0:glyph=31;1:glyph=24;2:glyph=19;3:glyph=32;4:glyph=19;default:glyph=19;endcase end
 19:begin case(slot)0:glyph=33;1:glyph=34;2:glyph=19;3:glyph=32;4:glyph=19;default:glyph=19;endcase end
 20:begin case(slot)0:glyph=24;1:glyph=35;2:glyph=19;default:glyph=19;endcase end
 default:glyph=0;endcase
end endfunction
reg [MAX_BOXES-1:0] border_now,label_now,border0,label0;
reg [10:0] x0,y0,lx,ly,lw,coord;reg [23:0] rgb0;
reg [127:0] box;integer i,e;reg signed [23:0] limit_e;
always @*begin
 border_now=0;label_now=0;lx=0;ly=0;lw=0;coord=0;box=0;limit_e=0;
 for(i=0;i<MAX_BOXES;i=i+1)begin
  box=0;box[127:123]=active_classes[i*5+:5];lw=label_chars(box[127:123])*11'd32;
  lx=label_x[i]>WIDTH-lw?WIDTH-lw:label_x[i];ly=label_y[i]>=34?label_y[i]-34:label_y[i];
  if(i<active_count && in_de && !display_expired && !building)begin
   for(e=0;e<4;e=e+1)begin
    coord=axis_x[i*4+e]?x:y;limit_e=$signed({11'd0,tolerance[i*4+e]});
    if(edge_valid[i*4+e] && coord>=lo[i*4+e] && coord<=hi[i*4+e] && pixel_e[i*4+e]>=-limit_e && pixel_e[i*4+e]<=limit_e)border_now[i]=1;
   end
   if(x>=lx && x<lx+lw && y>=ly && y<ly+32)label_now[i]=1;
  end
 end
end
reg hit_border,hit_label;reg [23:0] selected_color;reg [5:0] selected_glyph;reg [3:0] selected_row,selected_col;
reg [127:0] select_box;reg [10:0] slx,sly,slw;integer s;
always @*begin
 hit_border=0;hit_label=0;selected_color=0;selected_glyph=0;selected_row=0;selected_col=0;select_box=0;slx=0;sly=0;slw=0;
 for(s=MAX_BOXES-1;s>=0;s=s-1)begin
  select_box=0;select_box[127:123]=active_classes[s*5+:5];slw=label_chars(select_box[127:123])*11'd32;
  slx=label_x[s]>WIDTH-slw?WIDTH-slw:label_x[s];sly=label_y[s]>=34?label_y[s]-34:label_y[s];
  if(border0[s])begin hit_border=1;selected_color=color(select_box[127:123]);end
  if(label0[s])begin
   hit_label=1;selected_color=color(select_box[127:123]);selected_glyph=glyph(select_box[127:123],(x0-slx)>>5);
   selected_row=(y0-sly)>>1;selected_col=(x0-slx)>>1;
  end
 end
end
(* syn_ramstyle="block_ram" *) reg [15:0] font[0:575];
initial $readmemh("osd_font.mem",font);
reg [3:0] pipe_vs,pipe_hs,pipe_de;reg [23:0] rgb1,rgb2,color1,color2;reg border1,border2,label1,label2;reg [3:0] col1,col2;reg [9:0] font_addr;reg [15:0] font_row;
assign out_vs=pipe_vs[3];assign out_hs=pipe_hs[3];assign out_de=pipe_de[3];
always @(posedge clk)begin
 if(!rst_n)begin pipe_vs<=0;pipe_hs<=0;pipe_de<=0;rgb0<=0;x0<=0;y0<=0;border0<=0;label0<=0;rgb1<=0;rgb2<=0;color1<=0;color2<=0;border1<=0;border2<=0;label1<=0;label2<=0;col1<=0;col2<=0;font_addr<=0;font_row<=0;out_bgr<=0;end
 else begin
  pipe_vs<={pipe_vs[2:0],in_vs};pipe_hs<={pipe_hs[2:0],in_hs};pipe_de<={pipe_de[2:0],in_de};
  rgb0<=in_bgr;x0<=x;y0<=y;border0<=border_now;label0<=label_now;
  rgb1<=rgb0;color1<=selected_color;border1<=hit_border;label1<=hit_label;col1<=selected_col;font_addr<=selected_glyph*16+selected_row;
  rgb2<=rgb1;color2<=color1;border2<=border1;label2<=label1;col2<=col1;font_row<=font[font_addr];
  out_bgr<=label2 ? (font_row[15-col2] ? color2 : 24'h101010) : border2 ? color2 : rgb2;
 end
end
endmodule
