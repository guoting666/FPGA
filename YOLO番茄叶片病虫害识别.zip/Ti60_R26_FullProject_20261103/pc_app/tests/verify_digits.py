"""End-to-end digit integration using isolated localhost sockets, never the board."""
from pathlib import Path
import sys,json,cv2,numpy as np,socket,tempfile,threading,time
from http.server import ThreadingHTTPServer
from urllib.request import Request,urlopen
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from detector import Detector
from geometry import ShapePipeline
from app import Application,make_handler,validate_digits
from udp_video import packetize,RGB888

def main():
 cv2.setNumThreads(1);d=Detector();checks=[]
 def passed(name):checks.append(name);print('PASS',name,flush=True)
 image=cv2.imdecode(np.fromfile(str(ROOT/'samples/图形与数字示例.png'),np.uint8),1)
 p,t=ShapePipeline(d).predict(image,.96,targets='both')
 assert sorted(x['class_id'] for x in p)==list(range(13)),[(x['name'],x['xyxy']) for x in p]
 passed('one scene simultaneously detects all three shapes and all ten digits')
 for target,expected in [('shapes',list(range(3))),('digits',list(range(3,13)))]:
  p,_=ShapePipeline(d).predict(image,.96,targets=target);assert sorted(x['class_id'] for x in p)==expected
 passed('shape-only and digit-only tasks isolate the intended classes')
 pipe=ShapePipeline(d);assert not pipe.predict(image,.96,targets='both',stable=True)[0]
 assert len(pipe.predict(image,.96,targets='both',stable=True)[0])==13
 assert not pipe.predict(np.full_like(image,238),.96,targets='both',stable=True)[0]
 passed('digits require consecutive frames and disappear when removed')
 for name in ['three_shapes_a','three_shapes_b','three_shapes_c','three_shapes_d','rectangle_only','desk_negative','clipped_shapes']:
  im=cv2.imread(str(ROOT/'tests/fixtures'/f'{name}.png'));p,_=ShapePipeline(d).predict(im,.96,targets='both')
  assert not [x for x in p if x['class_id']>=3],(name,p)
 passed('seven saved camera shape/desk fixtures do not become digit false positives')
 for bad in [{'targets':'bad'},{'digit_confidence':True},{'digit_confidence':float('nan')},{'digit_confidence':.2}]:
  try:validate_digits(bad)
  except ValueError:pass
  else:raise AssertionError(bad)
 passed('digit task and threshold inputs reject malformed settings')
 with tempfile.TemporaryDirectory(prefix='digits_http_') as tmp:
  app=Application(d,tmp);server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(app));threading.Thread(target=server.serve_forever,daemon=True).start()
  base=f'http://127.0.0.1:{server.server_port}'
  def req(path,body=None):
   with urlopen(Request(base+path,data=None if body is None else json.dumps(body).encode()),timeout=10) as response:
    data=response.read();return json.loads(data) if data else None
  probe=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);probe.bind(('127.0.0.1',0));port=probe.getsockname()[1];probe.close()
  sender=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
  try:
   req('/api/start',dict(kind='udp',bind_ip='127.0.0.1',source_ip='127.0.0.1',port=port,skip=1,targets='both'))
   time.sleep(.15)
   for fid in range(4):
    for i,payload in enumerate(packetize(image,fid,RGB888)):
     sender.sendto(payload,('127.0.0.1',port))
     if i%16==15:time.sleep(.001)
    time.sleep(.08)
   due=time.monotonic()+5;frame=None
   while time.monotonic()<due:
    frame=req('/api/frame')
    if frame and len(frame['predictions'])==13:break
    time.sleep(.03)
   assert frame and len(frame['predictions'])==13
   saved=Path(req('/api/save',{})['saved_to']);record=json.loads((saved/'result.json').read_text(encoding='utf8'))
   assert record['digit_model_sha256']==d.digits.sha256 and record['targets']=='both'
   assert (saved/'original.png').exists() and (saved/'detection.jpg').exists()
   assert req('/api/state')['app_id']=='Ti60_Ethernet_ShapeDigits_v1'
   req('/api/stop',{})
  finally:sender.close();app.stop();server.shutdown();server.server_close()
 passed('actual loopback UDP -> combined inference -> HTTP -> matched saved frame and digit model hash')
 report=dict(passed=True,count=len(checks),checks=checks,scope='Development fixture, saved camera negatives and local UDP integration. No live board access.',digit_model_sha256=d.digits.sha256,board_tested=False)
 (ROOT/'reports/digit_integration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
if __name__=='__main__':main()
