"""Local PC viewer: Ethernet images, local files, matched-frame inference."""
import argparse
import base64
from collections import deque
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import threading
import time
from urllib.parse import parse_qs, urlparse
import uuid
import webbrowser

import cv2
import numpy as np
from detector import Detector, ROOT
from geometry import ShapePipeline
from udp_video import UDPReceiver, validate_udp

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".webp"}
VIDEO_EXTENSIONS = {".mp4", ".avi", ".mov", ".mkv", ".m4v"}


class Session:
    def __init__(self, detector, kind, source, skip, confidence, loop, mode="verified", roi=None, targets="both", digit_confidence=.93, tomato_confidence=.40):
        self.detector, self.kind, self.source = detector, kind, source
        self.skip, self.confidence, self.loop = skip, confidence, loop
        self.mode, self.roi = mode, roi or [0, 0, 100, 100]
        self.targets,self.digit_confidence=targets,digit_confidence
        self.tomato_confidence=tomato_confidence
        self.pipeline = ShapePipeline(detector)
        self.snapshot_udp = kind == "udp" and source.get("delivery") == "snapshot"
        self.receiver = None
        self.last_udp_frame = 0
        self.input_epoch = 0
        self.stop_event = threading.Event()
        self.condition = threading.Condition()
        self.latest = None
        self.output = None
        self.raw_output = None
        self.annotated_output = None
        self.error = ""
        self.phase = "opening"
        self.finished_reading = False
        self.captured = 0
        self.processed = 0
        self.capture_times = deque(maxlen=90)
        self.process_times = deque(maxlen=30)
        self.reader = threading.Thread(target=self.capture, daemon=True, name="capture")
        self.worker = threading.Thread(target=self.infer, daemon=True, name="inference")

    def start(self):
        self.reader.start()
        self.worker.start()

    def publish_input(self, frame, transport_id=None):
        # Exactly one slot: slow inference never queues old video frames.
        with self.condition:
            self.captured += 1
            now = time.monotonic()
            self.capture_times.append(now)
            self.latest = (self.captured, now, frame, transport_id)
            self.phase = "running"
            self.condition.notify_all()

    def capture(self):
        cap = None
        try:
            if self.kind == "udp":
                self.receiver = UDPReceiver(self.source)
                self.phase = "waiting"
                while not self.stop_event.is_set():
                    frame = self.receiver.read()
                    if frame is not None:
                        self.last_udp_frame = time.monotonic()
                        self.publish_input(frame,self.receiver.assembler.last_id)
                    elif not self.snapshot_udp and time.monotonic() - self.last_udp_frame > 1:
                        with self.condition:
                            if self.phase != "waiting":
                                self.input_epoch += 1
                            self.phase = "waiting"
                            self.output = self.raw_output = self.annotated_output = None
                            self.latest = None
                return
            path = Path(str(self.source))
            if self.kind == "upload" and path.suffix.lower() in IMAGE_EXTENSIONS:
                frame = cv2.imdecode(np.fromfile(str(path), np.uint8), cv2.IMREAD_COLOR)
                if frame is None:
                    raise ValueError("图片无法解码，请选择 PNG、JPG 或 BMP 图片")
                self.publish_input(frame)
                return
            cap = cv2.VideoCapture(str(self.source))
            if not cap.isOpened():
                raise ValueError("视频无法打开或编码不受支持，请试用 MP4(H.264) 或 AVI(MJPEG)")
            fps = cap.get(cv2.CAP_PROP_FPS)
            fps = fps if 1 <= fps <= 120 else 30
            due = time.monotonic()
            failures = 0
            while not self.stop_event.is_set():
                ok, frame = cap.read()
                if not ok:
                    if self.loop:
                        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                        ok, frame = cap.read()
                        if not ok:
                            raise ValueError("视频为空或无法循环读取")
                        due = time.monotonic()
                    else:
                        break
                failures = 0
                self.publish_input(frame)
                due += 1 / fps
                self.stop_event.wait(max(0, due - time.monotonic()))
        except Exception as exc:
            with self.condition:
                self.error = str(exc)
                self.phase = "error"
                self.output = None
        finally:
            if cap is not None:
                cap.release()
            if self.receiver is not None:
                self.receiver.close()
            with self.condition:
                self.finished_reading = True
                self.condition.notify_all()

    def infer(self):
        last = 0
        try:
            while not self.stop_event.is_set():
                with self.condition:
                    self.condition.wait_for(lambda: self.stop_event.is_set() or self.finished_reading or
                                            (self.latest is not None and
                                             (last == 0 or self.latest[0] - last >= (1 if self.snapshot_udp else self.skip))))
                    if self.stop_event.is_set() or self.error:
                        break
                    if self.latest is None or self.latest[0] <= last:
                        if self.finished_reading:
                            break
                        continue
                    number, captured_at, frame, transport_id = self.latest
                    confidence = self.confidence
                    mode, roi, epoch = self.mode, self.roi[:], self.input_epoch
                    targets,digit_confidence=self.targets,self.digit_confidence
                    tomato_confidence=self.tomato_confidence
                predictions, timing = self.pipeline.predict(frame, confidence, mode, roi,
                    stable=not (self.snapshot_udp or (self.kind == "upload" and Path(str(self.source)).suffix.lower() in IMAGE_EXTENSIONS)),targets=targets,digit_confidence=digit_confidence,tomato_confidence=tomato_confidence)
                # Retain smoothing for the older grayscale firmware only.
                gray_udp = self.kind == "udp" and np.array_equal(frame[:, :, 0], frame[:, :, 1]) and np.array_equal(frame[:, :, 1], frame[:, :, 2])
                preview = cv2.blur(frame, (2, 2)) if gray_udp else frame
                annotated = self.detector.annotate(preview, predictions)
                ok, jpg = cv2.imencode(".jpg", annotated, [cv2.IMWRITE_JPEG_QUALITY, 88])
                if not ok:
                    raise RuntimeError("识别画面编码失败")
                now = time.monotonic()
                packet = {"source_frame": number, "width": frame.shape[1], "height": frame.shape[0],
                          "predictions": predictions, "timing": timing,
                          "capture_to_result_ms": (now - captured_at) * 1000,
                          "confidence": confidence, "mode": mode, "roi": roi,
                          "targets":targets,"digit_confidence":digit_confidence,"tomato_confidence":tomato_confidence,
                          "preview_filter": "2x2 gray smoothing" if gray_udp else "none",
                          "udp_pixel_format": self.receiver.assembler.last_format if self.receiver else None,
                          "udp_frame_id": transport_id,
                          "image": "data:image/jpeg;base64," +
                          base64.b64encode(jpg).decode("ascii")}
                with self.condition:
                    if self.stop_event.is_set() or self.error:
                        break
                    if epoch != self.input_epoch or (self.kind == "udp" and self.phase == "waiting"):
                        last = number
                        continue
                    self.output = packet
                    if self.receiver:
                        self.receiver.send_results(transport_id,frame.shape[1],frame.shape[0],predictions)
                    self.raw_output, self.annotated_output = frame, annotated
                    if self.snapshot_udp:
                        self.phase = "snapshot"
                    self.processed += 1
                    self.process_times.append(now)
                    self.condition.notify_all()
                last = number
        except Exception as exc:
            with self.condition:
                self.error = str(exc)
                self.phase = "error"
                self.output = None
            self.stop_event.set()
        finally:
            with self.condition:
                if not self.error:
                    self.phase = "stopped" if self.stop_event.is_set() else "ended"
                self.condition.notify_all()

    def stop(self):
        self.stop_event.set()
        with self.condition:
            self.condition.notify_all()
        # Never start another inference interpreter user while this one runs.
        self.worker.join(timeout=10)
        self.reader.join(timeout=3)
        if self.worker.is_alive() or self.reader.is_alive():
            raise RuntimeError("输入线程尚未结束，请稍后再次停止")
        self.phase = "stopped"

    def state(self):
        def rate(values):
            if len(values) < 2 or time.monotonic() - values[-1] > 2:
                return 0.0
            return round((len(values) - 1) / max(0.001, values[-1] - values[0]), 1)
        with self.condition:
            return {"phase": self.phase, "error": self.error, "kind": self.kind,
                    "captured_frames": self.captured, "processed_frames": self.processed,
                    "capture_fps": rate(self.capture_times), "detection_fps": rate(self.process_times),
                    "skip": self.skip, "confidence": self.confidence, "mode": self.mode, "roi": self.roi,
                    "targets":self.targets,"digit_confidence":self.digit_confidence,"tomato_confidence":self.tomato_confidence,
                    "udp": self.receiver.state() if self.receiver else None,
                    "source_options": self.source if self.kind == "udp" else None,
                    "upload_id": Path(str(self.source)).name if self.kind == "upload" else None}


class Application:
    def __init__(self, detector, data_dir):
        self.detector, self.data_dir = detector, Path(data_dir)
        self.upload_dir = self.data_dir / "uploads"
        self.snapshot_dir = self.data_dir / "snapshots"
        self.session = None
        self.session_id = 0
        self.control = threading.RLock()

    def state(self):
        with self.control:
            state = self.session.state() if self.session else {"phase": "idle", "error": "", "kind": "udp",
                "capture_fps": 0, "detection_fps": 0, "captured_frames": 0, "processed_frames": 0,
                "skip": 1, "confidence": self.detector.config["confidence"], "mode": "verified", "roi": [0,0,100,100],"targets":"both","digit_confidence":.93,"tomato_confidence":self.detector.tomato.state().get('default_confidence',.40)}
            return dict(state, app_id="Ti60_Ethernet_ShapeDigitsTomato_R11", session_id=self.session_id, model_sha256=self.detector.sha256,digit_model_sha256=self.detector.digits.sha256,tomato_model=self.detector.tomato.state())

    def start(self, options):
        kind = options.get("kind", "demo")
        if kind not in {"demo", "upload", "udp"}:
            raise ValueError("无效的视频来源")
        skip, confidence = validate_settings(options, self.detector.config["confidence"])
        mode, roi = validate_vision(options)
        targets,digit_confidence=validate_digits(options)
        tomato_confidence=validate_tomato(options,self.detector.tomato.state().get('default_confidence',.40))
        if targets=="tomato" and not self.detector.tomato.state()["ready"]:raise ValueError("番茄叶片模型尚未就绪，请先完成训练")
        if kind == "demo":
            source = ROOT / ("samples/tomato_demo.avi" if targets=="tomato" else "samples/digits_demo.avi")
        elif kind == "udp":
            source = validate_udp(options)
        else:
            upload_id = options.get("upload_id", "")
            # Server-generated IDs only, no client-selected filesystem paths.
            if not isinstance(upload_id, str) or Path(upload_id).name != upload_id:
                raise ValueError("请先选择并上传图片或视频")
            source = self.upload_dir / upload_id
            if not source.is_file() or source.suffix.lower() not in IMAGE_EXTENSIONS | VIDEO_EXTENSIONS:
                raise ValueError("上传的文件不存在，请重新选择")
        with self.control:
            self.stop()
            self.session_id += 1
            self.session = Session(self.detector, kind, source, skip, confidence, bool(options.get("loop", True)), mode, roi,targets,digit_confidence,tomato_confidence)
            self.session.start()
            return self.state()

    def stop(self):
        with self.control:
            if self.session:
                self.session.stop()
            return self.state()

    def settings(self, options):
        skip, confidence = validate_settings(options, self.detector.config["confidence"])
        mode, roi = validate_vision(options)
        targets,digit_confidence=validate_digits(options)
        tomato_confidence=validate_tomato(options,self.detector.tomato.state().get('default_confidence',.40))
        if targets=="tomato" and not self.detector.tomato.state()["ready"]:raise ValueError("番茄叶片模型尚未就绪，请先完成训练")
        with self.control:
            if self.session:
                # A still-image worker has finished; a task change must run the
                # same uploaded image again. Demo tasks also select their own source.
                if self.session.kind=="upload" and Path(str(self.session.source)).suffix.lower() in IMAGE_EXTENSIONS:
                    return self.start(dict(options,kind="upload",upload_id=Path(str(self.session.source)).name))
                if self.session.kind=="demo" and ((targets=="tomato") != (self.session.targets=="tomato")):
                    return self.start(dict(options,kind="demo",loop=True))
                with self.session.condition:
                    self.session.skip, self.session.confidence = skip, confidence
                    self.session.mode, self.session.roi = mode, roi
                    self.session.targets,self.session.digit_confidence=targets,digit_confidence
                    self.session.tomato_confidence=tomato_confidence
                    self.session.input_epoch += 1
                    self.session.output = None
                    self.session.condition.notify_all()
            return self.state()

    def frame(self, after):
        with self.control:
            if not self.session:
                return None
            with self.session.condition:
                packet = self.session.output
                if packet is None:
                    return None
                key = f'{self.session_id}:{packet["source_frame"]}'
                return None if key == after else dict(packet, key=key, session_id=self.session_id)

    def save(self):
        with self.control:
            if not self.session:
                raise ValueError("请先开始识别")
            with self.session.condition:
                if self.session.output is None:
                    raise ValueError("当前没有可以保存的识别画面")
                raw, annotated = self.session.raw_output, self.session.annotated_output
                result = {k: v for k, v in self.session.output.items() if k != "image"}
                result.update(source_kind=self.session.kind, model_sha256=self.detector.sha256,digit_model_sha256=self.detector.digits.sha256,
                              synthetic=self.session.kind == "demo" and self.session.targets != "tomato",
                              dataset_demo=self.session.kind == "demo" and self.session.targets == "tomato",
                              tomato_model=self.detector.tomato.state())
                if self.session.receiver:
                    # A diagnostic observation at save time, not a claim that
                    # the HDMI acknowledgement belongs to this exact picture.
                    result["receiver_state_at_save"] = self.session.receiver.state()
            stem = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            folder = self.snapshot_dir / stem
            folder.mkdir(parents=True)
            for name, image in [("original.png", raw), ("detection.jpg", annotated)]:
                ok, encoded = cv2.imencode(Path(name).suffix, image)
                if not ok:
                    raise RuntimeError("保存图片失败")
                encoded.tofile(str(folder / name))
            (folder / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
            return {"saved_to": str(folder.resolve())}


def validate_settings(options, default_confidence=0.95):
    skip, confidence = options.get("skip", 5), options.get("confidence", default_confidence)
    if type(skip) is not int or not 1 <= skip <= 30:
        raise ValueError("检测间隔应为 1 到 30 帧")
    if type(confidence) not in (float, int) or not 0.05 <= confidence <= 0.99:
        raise ValueError("置信度应在 0.05 到 0.99 之间")
    return skip, float(confidence)


def validate_vision(options):
    mode = options.get("mode", "verified")
    if mode not in {"verified", "yolo", "geometry"}:
        raise ValueError("无效的识别模式")
    roi = options.get("roi", [0, 0, 100, 100])
    if not isinstance(roi, list) or len(roi) != 4 or any(type(v) not in (int, float) or
            not 0 <= v <= 100 for v in roi) or min(roi[2:]) < 5 or roi[0]+roi[2] > 100 or roi[1]+roi[3] > 100:
        raise ValueError("检测区域使用百分比：左、上、宽、高；宽高至少 5，且区域不能超出画面")
    return mode, roi


def validate_digits(options):
    targets=options.get('targets','both');threshold=options.get('digit_confidence',.93)
    if targets not in {'both','shapes','digits','tomato'}:raise ValueError('无效的识别任务')
    if type(threshold) not in (float,int) or not .5<=threshold<=.995:raise ValueError('数字阈值应在 50% 到 99.5%')
    return targets,float(threshold)


def validate_tomato(options,default=.40):
    value=options.get("tomato_confidence",default)
    if type(value) not in (int,float) or not .05<=value<=.99:raise ValueError("叶片检测阈值应在 5% 到 99%")
    return float(value)

def make_handler(app):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            if args and str(args[0]).startswith("POST"):
                super().log_message(fmt, *args)

        def reply(self, value, status=200):
            data = json.dumps(value, ensure_ascii=False).encode("utf-8")
            self.send_bytes(data, "application/json; charset=utf-8", status)

        def send_bytes(self, data, mime, status=200):
            self.send_response(status)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; frame-ancestors 'none'")
            self.end_headers()
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass

        def do_GET(self):
            route = urlparse(self.path)
            if route.path == "/api/state":
                return self.reply(app.state())
            if route.path == "/api/frame":
                packet = app.frame(parse_qs(route.query).get("after", [""])[0])
                return self.reply(packet) if packet else self.send_bytes(b"", "application/json", 204)
            files = {"/": ("index.html", "text/html; charset=utf-8"),
                     "/style.css": ("style.css", "text/css; charset=utf-8"),
                     "/app.js": ("app.js", "text/javascript; charset=utf-8")}
            if route.path not in files:
                return self.reply({"error": "页面不存在"}, 404)
            name, mime = files[route.path]
            self.send_bytes((ROOT / "web" / name).read_bytes(), mime)

        def do_POST(self):
            # Only this local page can control inputs; command-line clients may omit Origin.
            host = self.headers.get("Host", "")
            expected = f"127.0.0.1:{self.server.server_port}"
            if host not in {expected, f"localhost:{self.server.server_port}"} or self.headers.get("Origin", f"http://{host}") != f"http://{host}":
                return self.reply({"error": "请从本机打开识别页面"}, 403)
            try:
                size = int(self.headers.get("Content-Length", "0"))
                route = urlparse(self.path)
                limit = 256 * 1024 * 1024 if route.path == "/api/upload" else 8192
                if not 0 < size <= limit:
                    return self.reply({"error": "视频/图片上限为 256MB，设置请求不能为空"}, 413)
                if route.path == "/api/upload":
                    name = parse_qs(route.query).get("name", [""])[0]
                    extension = Path(name).suffix.lower()
                    if extension not in IMAGE_EXTENSIONS | VIDEO_EXTENSIONS:
                        raise ValueError("请选择常见图片或 MP4、AVI、MOV、MKV 视频")
                    upload_id = uuid.uuid4().hex + extension
                    app.upload_dir.mkdir(parents=True, exist_ok=True)
                    dest = app.upload_dir / upload_id
                    try:
                        with dest.open("wb") as stream:
                            remaining = size
                            while remaining:
                                block = self.rfile.read(min(1024 * 1024, remaining))
                                if not block:
                                    raise ValueError("文件上传中断，请重试")
                                stream.write(block)
                                remaining -= len(block)
                    except Exception:
                        dest.unlink(missing_ok=True)
                        raise
                    return self.reply({"upload_id": upload_id, "name": Path(name).name})
                options = json.loads(self.rfile.read(size))
                if not isinstance(options, dict):
                    raise ValueError("无效的设置")
                if route.path == "/api/start":
                    result = app.start(options)
                elif route.path == "/api/stop":
                    result = app.stop()
                elif route.path == "/api/settings":
                    result = app.settings(options)
                elif route.path == "/api/save":
                    result = app.save()
                elif route.path == "/api/shutdown":
                    result = app.stop()
                    self.reply(dict(result, phase="exited"))
                    threading.Thread(target=self.server.shutdown, daemon=True).start()
                    return
                else:
                    return self.reply({"error": "接口不存在"}, 404)
                self.reply(result)
            except (ValueError, TypeError) as exc:
                self.reply({"error": str(exc)}, 400)
            except Exception as exc:
                self.reply({"error": str(exc)}, 500)
    return Handler


def main():
    parser = argparse.ArgumentParser(description="Ti60 图形、数字与叶片 PC 识别")
    parser.add_argument("--port", type=int, default=18792)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--resume-upload", metavar="UPLOAD_ID", help="Resume an existing local upload after a service restart")
    parser.add_argument("--resume-task", choices=['both','shapes','digits','tomato'], default='both', help="Task used with an existing upload")
    parser.add_argument("--resume-udp", action="store_true", help="Start the validated default board Ethernet source")
    parser.add_argument("--data-dir", type=Path, default=ROOT / "user_data")
    args = parser.parse_args()
    cv2.setNumThreads(1)
    print("正在加载图形与数字模型；叶片模型在使用时加载。", flush=True)
    detector = Detector()
    detector.predict(np.full((192, 192, 3), 114, np.uint8))
    application = Application(detector, args.data_dir)
    server = ThreadingHTTPServer(("127.0.0.1", args.port), make_handler(application))
    if args.resume_upload:
        application.start(dict(kind="upload", upload_id=args.resume_upload, targets=args.resume_task, mode="verified", digit_confidence=.93, skip=1, loop=True))
    elif args.resume_udp:
        application.start(dict(kind="udp",bind_ip="192.168.0.3",source_ip="192.168.0.2",port=8080,delivery="stream",targets="both",mode="verified",digit_confidence=.93,skip=1))
    url = f"http://127.0.0.1:{server.server_port}"
    print(f"识别页面：{url}\n关闭本窗口或按 Ctrl+C 退出。", flush=True)
    if not args.no_browser:
        webbrowser.open(url)
    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        pass
    finally:
        application.stop()
        server.server_close()


if __name__ == "__main__":
    main()
