"""Small launcher checks kept out of shell strings for Windows PowerShell 5."""
import importlib.util
import sys

if sys.argv[1] == "available":
    raise SystemExit(0 if all(importlib.util.find_spec(m) for m in
                             ["tensorflow", "numpy", "cv2", "PIL"]) else 1)
if sys.argv[1] == "version":
    raise SystemExit(0 if sys.version_info[:2] == (3, 11) else 1)
if sys.argv[1] == "model":
    from detector import Detector
    detector=Detector()
    print("MODEL_OK", detector.sha256)
    print("DIGIT_MODEL_OK",detector.digits.sha256)
    import numpy as np
    tomato = detector.tomato.state()
    if not tomato['ready']:
        raise SystemExit(tomato['error'] or 'TOMATO_MODEL_MISSING')
    detector.tomato.predict(np.full((384,384,3),114,np.uint8),.99)
    print("TOMATO_MODEL_OK",tomato['sha256'])
