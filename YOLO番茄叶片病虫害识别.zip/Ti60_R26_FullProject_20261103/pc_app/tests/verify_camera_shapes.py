"""Camera regressions are tuning samples, not an independent accuracy benchmark."""
from pathlib import Path
import sys,json
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from geometry import find_shapes,ShapePipeline
from udp_video import decode_frame,BAYER_BGGR8,TI60_COLOR_GAINS

def main():
    checks=[]
    for name,expected in [('three_shapes_a',[0,1,2]),('three_shapes_b',[0,1,2]),('three_shapes_c',[0,1,2]),('three_shapes_d',[0,1,2]),('rectangle_only',[1]),('desk_negative',[]),('clipped_shapes',[1])]:
        im=cv2.imread(str(ROOT/'tests/fixtures'/f'{name}.png'))
        assert im is not None
        color=decode_frame(im[:,:,0].tobytes(),BAYER_BGGR8,im.shape[1],im.shape[0])
        color=np.minimum((color.astype(np.uint32)*TI60_COLOR_GAINS+128)>>8,255).astype(np.uint8)
        for variant in [im,cv2.GaussianBlur(im,(3,3),.8),np.clip(im.astype(float)*.85+12,0,255).astype(np.uint8),color]:
            got=sorted(p['class_id'] for p in find_shapes(variant))
            assert got==expected,(name,got,expected)
        checks.append(name+' original, mild blur, brightness change, calibrated Bayer color')
    for axes in [(50,50),(50,44),(50,41)]:
        im=np.full((180,180,3),230,np.uint8)
        cv2.ellipse(im,(90,90),axes,23,0,360,(20,20,20),-1)
        assert [p['class_id'] for p in find_shapes(im)]==[2],axes
    checks.append('round and modest perspective ellipses remain circles')
    for n in [5,6,7,8]:
        for angle in [0,.17,.4]:
            im=np.full((180,180,3),230,np.uint8)
            pts=np.array([[90+55*np.cos(t),90+55*np.sin(t)] for t in np.arange(n)*2*np.pi/n+angle],np.int32)
            cv2.fillPoly(im,[pts],(20,20,20))
            assert not find_shapes(im),(n,angle,find_shapes(im))
    checks.append('rotated pentagons through octagons are not circles')
    for dims in [(100,70),(110,50)]:
        im=np.full((180,180,3),230,np.uint8)
        x,y=90-dims[0]//2,90-dims[1]//2
        cv2.rectangle(im,(x,y),(x+dims[0],y+dims[1]),(20,20,20),-1)
        assert [p['class_id'] for p in find_shapes(im)]==[1]
    checks.append('rectangles remain rectangles after circular fit changes')
    report=dict(passed=True,checks=checks,count=len(checks),
                scope='Seven saved Ti60 camera tuning samples and controlled perturbations. Not held-out accuracy.',retrained=False)
    (ROOT/'reports/camera_shape_regression.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
