from pathlib import Path
import sys,json,random,socket
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from udp_video import Reassembler,packetize,BAYER_CODES,HEADER,UDPReceiver,TI60_COLOR_GAINS
from app import Application

checks=[]
image=np.zeros((80,240,3),np.uint8)
image[:,:80]=(20,40,220);image[:,80:160]=(30,210,50);image[:,160:]=(230,50,20)
for fmt in BAYER_CODES:
 packets=list(packetize(image,1,fmt));random.Random(4).shuffle(packets);a=Reassembler();frames=[]
 for p in packets:
  f=a.feed(p)
  if f is not None:frames.append(f)
 assert len(frames)==1
 for x in [30,110,190]:assert np.max(np.abs(frames[0][10:70,x:x+20].astype(int)-image[10:70,x:x+20].astype(int)))<=1,fmt
 checks.append('Bayer format '+str(fmt)+' red/green/blue channel fidelity and shuffled reassembly')
# Malformed Bayer dimensions must be refused before OpenCV demosaicing.
packet=next(packetize(image,2,5));fields=list(HEADER.unpack_from(packet));fields[5]=3;fields[6]=80;fields[7]=240
a=Reassembler();assert a.feed(HEADER.pack(*fields)+packet[28:]) is None and a.stats['invalid_packets']==1
checks.append('undersized Bayer image rejected')
# Actual UDP receiver applies exactly the same rounded, saturating Q8.8 gains
# as the HDMI RTL. Use an isolated loopback port, never the board's port.
probe=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);probe.bind(('127.0.0.1',0));port=probe.getsockname()[1];probe.close()
receiver=UDPReceiver(dict(bind_ip='127.0.0.1',source_ip='127.0.0.1',port=port))
sender=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
try:
    packets=list(packetize(image,4,6))
    for packet in packets:sender.sendto(packet,('127.0.0.1',port))
    frame=None
    for _ in packets:
        frame=receiver.read()
        if frame is not None:break
    assert frame is not None
    expected=np.minimum((image.astype(np.uint32)*TI60_COLOR_GAINS+128)>>8,255).astype(np.uint8)
    for x in [30,110,190]:assert np.max(np.abs(frame[10:70,x:x+20].astype(int)-expected[10:70,x:x+20].astype(int)))<=1
finally:sender.close();receiver.close()
checks.append('real UDP Bayer frame uses HDMI-matched Q8.8 white balance and saturation')
try: Application(None,ROOT/'user_data').start({'kind':'camera'})
except ValueError as exc:assert '无效' in str(exc)
else:raise AssertionError('removed camera input accepted')
checks.append('removed UVC source cannot be started through API')
for text in [(ROOT/'app.py').read_text(encoding='utf8'),(ROOT/'web/app.js').read_text(encoding='utf8'),(ROOT/'web/index.html').read_text(encoding='utf8')]:
 assert 'CAP_DSHOW' not in text and 'enumerate_cameras' not in text and 'value="camera"' not in text
checks.append('no DirectShow enumeration or capture UI path remains')
report=dict(passed=True,count=len(checks),checks=checks,scope='Synthetic channel fidelity and UVC source removal. Camera color phase requires physical reference.')
(ROOT/'reports/color_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(report,ensure_ascii=False,indent=2))
