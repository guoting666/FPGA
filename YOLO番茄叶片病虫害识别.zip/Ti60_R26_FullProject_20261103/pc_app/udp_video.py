"""T6V1 UDP image transport; custom protocol, not the vendor demo's wire format."""
from collections import Counter, OrderedDict
from dataclasses import dataclass, field
import ipaddress
import math
import socket
import select
import struct
import time

import cv2
import numpy as np

HEADER = struct.Struct("!4sBBHIHHIIHH")
OSD_EXTENSION = struct.Struct("!IHH4s")
AWB_EXTENSION = struct.Struct('!8H')
SENSOR_REGISTERS=(0x3107,0x3108,0x0100,0x3221,0x3208,0x3209,0x320a,0x320b,0x320e,0x320f,0x3e00,0x3e01,0x3e02,0x3e06,0x3e07,0x3e08,0x3e09,0x3202,0x3203,0x3212,0x3213,0x3301,0x36e9,0x37f9)

def sensor_state(data):
    if data is None or data==bytes(32):return None
    r=dict(zip(SENSOR_REGISTERS,data[8:]))
    return dict(chip_id=(r[0x3107]<<8)|r[0x3108],width=(r[0x3208]<<8)|r[0x3209],height=(r[0x320a]<<8)|r[0x320b],
                vts=(r[0x320e]<<8)|r[0x320f],exposure_half_lines=((r[0x3e00]&15)<<12)|(r[0x3e01]<<4)|(r[0x3e02]>>4),
                digital_gain=r[0x3e06],digital_fine_gain=r[0x3e07],analog_gain=r[0x3e08],analog_fine_gain=r[0x3e09],
                mirror=r[0x3221],stream=r[0x0100],i2c_nack_transactions=data[6],registers={f'{k:04x}':v for k,v in r.items()},source='physical sensor I2C readback, periodically sampled')

MAGIC, VERSION, CHUNK = b"T6V1", 1, 1280
RGB565_LE, RGB888, GRAY8, JPEG = 1, 2, 3, 4
BAYER_RGGB8, BAYER_BGGR8, BAYER_GRBG8, BAYER_GBRG8 = 5, 6, 7, 8
BAYER_CODES = {BAYER_RGGB8: cv2.COLOR_BayerRGGB2BGR,
               BAYER_BGGR8: cv2.COLOR_BayerBGGR2BGR,
               BAYER_GRBG8: cv2.COLOR_BayerGRBG2BGR,
               BAYER_GBRG8: cv2.COLOR_BayerGBRG2BGR}
# Fixed first-pass neutral-paper calibration, Q8.8 B,G,R; matches FPGA HDMI.
TI60_COLOR_GAINS = np.array([491, 256, 418], np.uint32)
MAX_W, MAX_H, MAX_BYTES = 1920, 1080, 1920 * 1080 * 3


def validate_udp(options):
    bind = str(options.get("bind_ip", "192.168.0.3"))
    source = str(options.get("source_ip", "192.168.0.2"))
    try:
        ipaddress.IPv4Address(bind)
        ipaddress.IPv4Address(source)
    except ipaddress.AddressValueError as exc:
        raise ValueError("请输入有效的电脑 IPv4 地址和板卡 IPv4 地址") from exc
    port = options.get("port", 8080)
    if type(port) is not int or not 1024 <= port <= 65535:
        raise ValueError("UDP 端口应为 1024 到 65535")
    if bind == "0.0.0.0" or source == "0.0.0.0" or ipaddress.IPv4Address(source).is_multicast:
        raise ValueError("请填写具体网卡和板卡地址，不使用全部接口或组播地址")
    delivery = options.get("delivery", "stream")
    if delivery not in {"stream", "snapshot"}:
        raise ValueError("UDP 接收方式应为连续视频或单张图片")
    return {"bind_ip": bind, "source_ip": source, "port": port, "delivery": delivery}


def newer(a, b):
    return 0 < ((a - b) & 0xffffffff) < 0x80000000


@dataclass
class Partial:
    fmt: int
    width: int
    height: int
    total: int
    created: float
    wire_info: tuple = (1, None)
    chunks: dict = field(default_factory=dict)


class Reassembler:
    def __init__(self, timeout=.6, max_inflight=3):
        self.timeout, self.max_inflight = timeout, max_inflight
        self.pending = OrderedDict()
        self.last_id = None
        self.last_format = None
        self.last_version = 1
        self.last_feedback = None
        self.last_awb = None
        self.last_sensor = None
        self.last_raw = None
        self.stats = Counter(packets=0, complete_frames=0, invalid_packets=0, duplicate_packets=0,
                             dropped_frames=0, stale_packets=0, foreign_packets=0, received_bytes=0)

    def expire(self, now=None):
        now = time.monotonic() if now is None else now
        for key, frame in list(self.pending.items()):
            if now - frame.created >= self.timeout:
                del self.pending[key]
                self.stats["dropped_frames"] += 1

    def feed(self, packet, now=None):
        now = time.monotonic() if now is None else now
        self.expire(now)
        self.stats["packets"] += 1
        self.stats["received_bytes"] += len(packet)
        try:
            if len(packet) < HEADER.size:
                raise ValueError()
            magic, version, fmt, size, fid, width, height, total, offset, length, reserved = HEADER.unpack_from(packet)
            if magic != MAGIC or (version,size) not in {(1,28),(2,40),(3,56),(4,88)} or reserved != 0:
                raise ValueError()
            feedback=None
            awb=None
            sensor=None
            if version in (2,3,4):
                if len(packet)<size:raise ValueError()
                applied_id,count,flags,build=OSD_EXTENSION.unpack_from(packet,28)
                if build!={2:b'T6O2',3:b'T6O3',4:b'T6O4'}[version] or count>16 or flags&~31:raise ValueError()
                feedback=(applied_id,count,flags)
                if version in (3,4):
                    awb=AWB_EXTENSION.unpack_from(packet,40)
                    protocol=awb[7]&255
                    allowed_flags=127 if protocol==2 else 31
                    if protocol not in (1,2) or awb[7]>>8&~allowed_flags or not all(6554<=g<=40960 for g in awb[4:7]):raise ValueError()
                if version==4:
                    sensor=bytes(packet[56:88])
                    if sensor!=bytes(32) and (sensor[:6]!=b'SC01\x01\x18' or sensor[7]!=1):raise ValueError()

            if not 1 <= width <= MAX_W or not 1 <= height <= MAX_H or not 1 <= total <= MAX_BYTES:
                raise ValueError()
            bpp = {RGB565_LE: 2, RGB888: 3, GRAY8: 1, **dict.fromkeys(BAYER_CODES, 1)}.get(fmt)
            if fmt not in {RGB565_LE, RGB888, GRAY8, JPEG, *BAYER_CODES} or (bpp and total != width * height * bpp):
                raise ValueError()
            if fmt in BAYER_CODES and (width < 4 or height < 4 or width % 2 or height % 2):
                raise ValueError()
            if fmt == JPEG and total > 2 * 1024 * 1024:
                raise ValueError()
            if offset >= total or offset % CHUNK or length != min(CHUNK, total - offset) or len(packet) != size + length:
                raise ValueError()
        except (ValueError, struct.error):
            self.stats["invalid_packets"] += 1
            return None
        if self.last_id is not None and not newer(fid, self.last_id):
            self.stats["stale_packets"] += 1
            return None
        frame = self.pending.get(fid)
        if frame and (frame.fmt, frame.width, frame.height, frame.total,frame.wire_info) != (fmt, width, height, total,(version,feedback,awb,sensor)):
            self.stats["invalid_packets"] += 1
            del self.pending[fid]
            return None
        if frame is None:
            while len(self.pending) >= self.max_inflight:
                self.pending.popitem(last=False)
                self.stats["dropped_frames"] += 1
            frame = self.pending[fid] = Partial(fmt, width, height, total, now,(version,feedback,awb,sensor))
        payload = packet[size:]
        if offset in frame.chunks:
            self.stats["duplicate_packets"] += 1
            if frame.chunks[offset] != payload:
                del self.pending[fid]
                self.stats["invalid_packets"] += 1
                self.stats["dropped_frames"] += 1
            return None
        frame.chunks[offset] = payload
        if len(frame.chunks) != math.ceil(total / CHUNK):
            return None
        data = b"".join(frame.chunks[i] for i in range(0, total, CHUNK))
        del self.pending[fid]
        image = decode_frame(data, fmt, width, height)
        if image is None:
            self.stats["invalid_packets"] += 1
            self.stats["dropped_frames"] += 1
            return None
        self.last_id = fid
        self.last_format = fmt
        self.last_version=version
        self.last_feedback=feedback
        self.last_awb=awb
        self.last_sensor=sensor
        self.last_raw=data if fmt in BAYER_CODES else None
        for key in list(self.pending):
            if not newer(key, fid):
                del self.pending[key]
                self.stats["dropped_frames"] += 1
        self.stats["complete_frames"] += 1
        return image


def decode_frame(data, fmt, width, height):
    if fmt == RGB565_LE:
        pixels = np.frombuffer(data, "<u2").reshape(height, width)
        b = ((pixels & 31) * 255 // 31).astype(np.uint8)
        g = (((pixels >> 5) & 63) * 255 // 63).astype(np.uint8)
        r = (((pixels >> 11) & 31) * 255 // 31).astype(np.uint8)
        return np.stack((b, g, r), -1)
    if fmt == RGB888:
        return cv2.cvtColor(np.frombuffer(data, np.uint8).reshape(height, width, 3), cv2.COLOR_RGB2BGR)
    if fmt == GRAY8:
        return cv2.cvtColor(np.frombuffer(data, np.uint8).reshape(height, width), cv2.COLOR_GRAY2BGR)
    if fmt in BAYER_CODES:
        raw = np.frombuffer(data, np.uint8).reshape(height, width)
        return cv2.cvtColor(raw, BAYER_CODES[fmt])
    # Check JPEG SOF dimensions before allocation/decoding, then check decoded size.
    if jpeg_dimensions(data) != (width, height):
        return None
    try:
        image = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    except cv2.error:
        return None
    return image if image is not None and image.shape[:2] == (height, width) else None


def jpeg_dimensions(data):
    if not data.startswith(b"\xff\xd8"):
        return None
    i = 2
    while i + 3 < len(data):
        if data[i] != 0xff:
            return None
        while i < len(data) and data[i] == 0xff:
            i += 1
        if i >= len(data):
            return None
        marker = data[i]
        i += 1
        if marker in {0xda, 0xd9}:
            return None
        if marker in {0xd8, 0x01} or 0xd0 <= marker <= 0xd7:
            continue
        if i + 2 > len(data):
            return None
        length = int.from_bytes(data[i:i+2], "big")
        if length < 2 or i + length > len(data):
            return None
        if marker in {0xc0, 0xc1, 0xc2} and length >= 8:
            return int.from_bytes(data[i+5:i+7], "big"), int.from_bytes(data[i+3:i+5], "big")
        i += length
    return None


def packetize(bgr, frame_id, fmt=RGB565_LE):
    height, width = bgr.shape[:2]
    if fmt == RGB565_LE:
        p = bgr.astype(np.uint16)
        data = (((p[..., 2] >> 3) << 11) | ((p[..., 1] >> 2) << 5) | (p[..., 0] >> 3)).astype("<u2").tobytes()
    elif fmt == RGB888:
        data = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB).tobytes()
    elif fmt == GRAY8:
        data = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY).tobytes()
    elif fmt in BAYER_CODES:
        if width % 2 or height % 2 or min(width, height) < 4:
            raise ValueError("Bayer 图像宽高应为不小于 4 的偶数")
        pattern = {BAYER_RGGB8: ((2,1),(1,0)), BAYER_BGGR8: ((0,1),(1,2)),
                   BAYER_GRBG8: ((1,2),(0,1)), BAYER_GBRG8: ((1,0),(2,1))}[fmt]
        raw = np.empty((height, width), np.uint8)
        for y in range(2):
            for x in range(2):
                raw[y::2, x::2] = bgr[y::2, x::2, pattern[y][x]]
        data = raw.tobytes()
    elif fmt == JPEG:
        ok, encoded = cv2.imencode(".jpg", bgr, [cv2.IMWRITE_JPEG_QUALITY, 90])
        if not ok:
            raise ValueError("JPEG 编码失败")
        data = encoded.tobytes()
    else:
        raise ValueError("不支持的图像格式")
    for offset in range(0, len(data), CHUNK):
        payload = data[offset:offset + CHUNK]
        yield HEADER.pack(MAGIC, VERSION, fmt, HEADER.size, frame_id & 0xffffffff,
                          width, height, len(data), offset, len(payload), 0) + payload


class UDPReceiver:
    def __init__(self, options):
        self.options = validate_udp(options)
        # A paced 1080p snapshot takes about one second over the board link.
        # Video retains its short deadline; incomplete photos are also bounded.
        self.assembler = Reassembler(timeout=2.0 if self.options["delivery"] == "snapshot" else .6)
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.skipped_previews=0
        try:
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 4 * 1024 * 1024)
            self.socket.bind((self.options["bind_ip"], self.options["port"]))
            self.socket.settimeout(.1)
        except OSError as exc:
            self.socket.close()
            raise ValueError(f'无法监听 {self.options["bind_ip"]}:{self.options["port"]}：'
                             '确认该 IP 已配置在电脑有线网卡上，且端口没有被占用。') from exc
        from hdmi_delivery import HDMIDelivery
        self.feedback = HDMIDelivery(lambda packet: self.socket.sendto(packet, (self.options['source_ip'], self.options['port'])))

    def read(self):
        self.feedback.pump()
        try:
            packet, peer = self.socket.recvfrom(65535)
        except socket.timeout:
            self.assembler.expire()
            self.feedback.pump()
            return None
        # Drain a bounded batch already in the OS queue before doing expensive
        # V36 color/inference. Keep the latest complete frame, including when
        # the newest queued frame is incomplete. Snapshot behavior is unchanged.
        batch=[(packet,peer)];size=len(packet)
        if self.options['delivery']=='stream':
            while len(batch)<4096 and size<8*1024*1024 and select.select([self.socket],[],[],0)[0]:
                item=self.socket.recvfrom(65535);batch.append(item);size+=len(item[0])
        image=None
        for packet,peer in batch:
            if peer[0] != self.options["source_ip"]:
                self.assembler.stats["foreign_packets"] += 1
                continue
            completed=self.assembler.feed(packet)
            if completed is not None:
                self.feedback.observe(self.assembler.last_feedback)
                if image is not None:self.skipped_previews+=1
                image=completed
        if image is not None and self.assembler.last_format in BAYER_CODES:
            # Board RAW data has no ISP white balance. Keep generic reassembly
            # unmodified; apply the board profile only in the live receiver.
            if self.assembler.last_version in (2,3,4):
                from v36_color import decode_bayer
                awb=self.assembler.last_awb
                wb=(awb[6],awb[5],awb[4]) if awb is not None else None
                bank=((awb[7]>>13)&3) if awb is not None and awb[7]&255==2 else None
                image=decode_bayer(np.frombuffer(self.assembler.last_raw,np.uint8).reshape(image.shape[:2]),BAYER_CODES[self.assembler.last_format],wb,bank)
            else:
                image = np.minimum((image.astype(np.uint32) * TI60_COLOR_GAINS + 128) >> 8, 255).astype(np.uint8)
        self.feedback.pump()
        return image

    def send_results(self,frame_id,width,height,predictions):
        self.feedback.submit(frame_id,width,height,predictions,self.assembler.last_version,self.assembler.last_feedback)

    def close(self):
        self.send_results(self.assembler.last_id,1920,1080,[])
        self.socket.close()

    def state(self):
        a=self.assembler.last_awb
        awb=None if a is None else dict(enabled=bool(a[7]&256),settled=bool(a[7]&512),busy=bool(a[7]&1024),rejected=bool(a[7]&2048),limited=bool(a[7]&4096),gains_q14=[a[6],a[5],a[4]],updates=a[1],rejected_frames=a[0],color_bank=((a[7]>>13)&3) if a[7]&255==2 else None,color_protocol_version=a[7]&255,source='FPGA V36 AWB metadata for this UDP frame')
        return dict(self.assembler.stats, **self.options, protocol="T6V1",skipped_previews=self.skipped_previews,
                    pixel_format=self.assembler.last_format,
                    wire_version=self.assembler.last_version,
                    awb=awb,sensor=sensor_state(self.assembler.last_sensor),
                    hdmi_feedback=dict(supports_tomato=bool(self.assembler.last_feedback and self.assembler.last_feedback[2]&16),enabled=self.assembler.last_version in (2,3,4),**self.feedback.state(),board_applied=self.assembler.last_feedback),
                    color_profile=("V36 automatic WB / board gains" if self.assembler.last_version in (3,4) else "V36 saved BLC/WB/Gamma/CCM/saturation" if self.assembler.last_version==2 else "Ti60 Q8.8 BGR 491/256/418") if self.assembler.last_format in BAYER_CODES else None)
