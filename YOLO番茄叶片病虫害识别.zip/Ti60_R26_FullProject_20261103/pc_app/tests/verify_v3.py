"""Executable offline checks, including real UDP sockets and the loaded model."""
from http.server import ThreadingHTTPServer
import json
from pathlib import Path
import random
import socket
import sys
import tempfile
import threading
import time
from urllib.request import Request, urlopen
from urllib.error import HTTPError

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from udp_video import Reassembler, packetize, RGB565_LE, RGB888, GRAY8, JPEG, HEADER, validate_udp
from geometry import find_shapes, ShapePipeline, iou
from detector import Detector
from app import Application, make_handler, validate_vision


def wait_for(fn, timeout=8):
    due = time.monotonic() + timeout
    while time.monotonic() < due:
        result = fn()
        if result:
            return result
        time.sleep(.02)
    raise AssertionError("timeout")


def main():
    cv2.setNumThreads(1)
    checks = []
    def passed(name):
        checks.append(name)
        print("PASS", name, flush=True)
    rng = np.random.default_rng(71)
    image = rng.integers(0, 256, (64, 80, 3), dtype=np.uint8)
    for fmt in (RGB565_LE, RGB888, GRAY8, JPEG):
        packets = list(packetize(image, 42, fmt))
        random.Random(9).shuffle(packets)
        receiver = Reassembler()
        frames = [f for p in packets if (f := receiver.feed(p)) is not None]
        assert len(frames) == 1 and frames[0].shape == image.shape
        if fmt == RGB888:
            assert np.array_equal(frames[0], image)
        if fmt == RGB565_LE:
            assert np.max(np.abs(frames[0].astype(int) - image.astype(int))) <= 8
    passed("four image formats, shuffled packets, RGB fidelity")
    packets = list(packetize(image, 1))
    a = Reassembler()
    assert a.feed(packets[0]) is None and a.feed(packets[0]) is None
    frames = [f for p in packets[1:] if (f := a.feed(p)) is not None]
    assert len(frames) == 1 and a.stats["duplicate_packets"] == 1
    assert a.feed(packets[-1]) is None and a.stats["stale_packets"] == 1
    passed("duplicates and completed-frame replay do not republish")
    a = Reassembler(timeout=.6)
    for p in packets[:-1]:
        assert a.feed(p, now=1.) is None
    a.expire(now=1.7)
    assert not a.pending and a.stats["dropped_frames"] == 1
    passed("missing packet discards whole frame at deadline")
    a = Reassembler(max_inflight=3)
    for fid in range(20):
        a.feed(next(packetize(image, fid)))
    assert len(a.pending) == 3 and a.stats["dropped_frames"] == 17
    passed("inflight allocation is bounded")
    a = Reassembler()
    a.feed(packets[0]);bad=bytearray(packets[0]);bad[-1]^=1
    assert a.feed(bytes(bad)) is None and a.stats["dropped_frames"] == 1
    assert a.stats["invalid_packets"] == 1
    passed("conflicting duplicate invalidates partial frame")
    a = Reassembler()
    for fid in (0xfffffffe, 0xffffffff, 0):
        frames = [f for p in packetize(image, fid) if (f := a.feed(p)) is not None]
        assert len(frames) == 1
    assert a.feed(next(packetize(image, 0xfffffffd))) is None
    passed("uint32 rollover and stale frame ordering")
    a = Reassembler()
    old = list(packetize(image, 1));new = list(packetize(image, 2))
    a.feed(old[0])
    for p in new:
        f = a.feed(p)
    assert f is not None
    for p in old[1:]:
        assert a.feed(p) is None
    passed("late old frame cannot replace a newer completed frame")
    a = Reassembler()
    bads = [b"",b"text from vendor example",packets[0][:-1],b"BAD!"+packets[0][4:]]
    values = list(HEADER.unpack_from(packets[0]))
    for index, value in [(2, 9),(3, 29),(5, 0),(5, 65535),(7, 0xffffffff),(8, 1),(10, 1)]:
        changed=values[:];changed[index]=value;bads.append(HEADER.pack(*changed)+packets[0][28:])
    for p in bads:
        assert a.feed(p) is None
    assert a.stats["invalid_packets"] == len(bads) and not a.pending
    passed("malformed lengths, dimensions, offsets, versions and formats rejected")
    jpg=list(packetize(image, 5, JPEG));a=Reassembler()
    for p in jpg:
        v=list(HEADER.unpack_from(p));v[5]+=1
        assert a.feed(HEADER.pack(*v)+p[28:]) is None
    assert a.stats["complete_frames"] == 0
    passed("JPEG dimension mismatch rejected before image decode")
    for options in ({"bind_ip":"bad"},{"port":True},{"port":80},{"source_ip":"0.0.0.0"}):
        try: validate_udp(options)
        except ValueError: pass
        else: raise AssertionError(options)
    for options in ({"roi":[0,0,101,100]},{"roi":[0,0,0,2]},{"mode":"bad"}):
        try: validate_vision(options)
        except ValueError: pass
        else: raise AssertionError(options)
    passed("UI network and region settings validated")
    shapes=np.full((480,800,3),235,np.uint8)
    cv2.fillPoly(shapes,[np.array([[60,320],[140,130],[230,320]])],(25,90,180))
    cv2.rectangle(shapes,(320,150),(490,315),(30,170,70),-1)
    cv2.circle(shapes,(650,235),88,(200,100,30),-1)
    found=find_shapes(shapes)
    assert sorted(p["class_id"] for p in found)==[0,1,2],found
    passed("independent three-shape fixture correctly classified")
    for n in (5,6,7,8):
        blank=np.zeros((400,400,3),np.uint8)
        pts=np.array([[200+110*np.cos(t),200+110*np.sin(t)] for t in np.arange(n)*2*np.pi/n],np.int32)
        cv2.fillPoly(blank,[pts],(100,220,180))
        assert not find_shapes(blank),(n,find_shapes(blank))
    assert not find_shapes(np.full((400,400,3),128,np.uint8))
    passed("blank, pentagon, hexagon, heptagon and octagon rejected")
    detector=Detector();pipeline=ShapePipeline(detector)
    pred,_=pipeline.predict(shapes,.96,"verified",stable=True)
    assert not pred
    pred,_=pipeline.predict(shapes,.96,"verified",stable=True)
    assert sorted(p["class_id"] for p in pred)==[0,1,2]
    shifted=np.roll(shapes,4,axis=1)
    pred,_=pipeline.predict(shifted,.96,"verified",stable=True)
    assert len(pred)==3
    pred,_=pipeline.predict(np.zeros_like(shapes),.96,"verified",stable=True)
    assert not pred
    passed("temporal confirmation uses current boxes and never holds vanished targets")
    pred,_=ShapePipeline(detector).predict(shapes,.96,"verified",[65,0,35,100])
    assert len(pred)==1 and pred[0]["class_id"]==2 and pred[0]["xyxy"][0]>520
    passed("ROI inference returns correct full-frame coordinates")
    with tempfile.TemporaryDirectory(prefix="shapev3_") as temp:
        application=Application(detector,temp)
        server=ThreadingHTTPServer(("127.0.0.1",0),make_handler(application))
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        base=f"http://127.0.0.1:{server.server_port}"
        def req(path,body=None,raw=None):
            data=raw if raw is not None else (None if body is None else json.dumps(body).encode())
            with urlopen(Request(base+path,data=data),timeout=10) as response:
                content=response.read()
            return json.loads(content) if content else None
        # Let the OS choose an available local UDP port; release it before app bind.
        probe=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);probe.bind(("127.0.0.1",0));port=probe.getsockname()[1];probe.close()
        try:
            req("/api/start",{"kind":"udp","bind_ip":"127.0.0.1","source_ip":"127.0.0.1","port":port,"mode":"verified","skip":1})
            wait_for(lambda:req("/api/state")["phase"]=="waiting")
            sender=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
            wire_image=cv2.resize(shapes,(320,192),interpolation=cv2.INTER_AREA)
            for fid in range(5):
                for index,p in enumerate(packetize(wire_image,fid,RGB888)):
                    sender.sendto(p,("127.0.0.1",port))
                    if index % 16 == 15: time.sleep(.001)
                time.sleep(.05)
            frame=wait_for(lambda:req("/api/frame"))
            assert sorted(p["class_id"] for p in frame["predictions"])==[0,1,2],frame["predictions"]
            saved=req("/api/save",{})
            assert all((Path(saved["saved_to"])/n).is_file() for n in ("original.png","detection.jpg","result.json"))
            passed("actual UDP socket -> reassembly -> actual YOLO/geometry -> HTTP -> paired snapshot")
            wait_for(lambda:req("/api/state")["phase"]=="waiting",timeout=4)
            assert req("/api/frame") is None
            passed("one-second stream interruption clears stale output")
            for index,p in enumerate(packetize(wire_image,8,RGB888)):
                sender.sendto(p,("127.0.0.1",port))
                if index % 16 == 15: time.sleep(.001)
            wait_for(lambda:req("/api/frame"))
            req("/api/stop",{})
            assert req("/api/state")["phase"]=="stopped"
            req("/api/start",{"kind":"udp","bind_ip":"127.0.0.1","source_ip":"127.0.0.1","port":port})
            wait_for(lambda:req("/api/state")["phase"]=="waiting")
            req("/api/stop",{})
            passed("UDP resumes after gap and bind port is reusable after stop")
            req("/api/start",{"kind":"udp","bind_ip":"127.0.0.1","source_ip":"127.0.0.1","port":port,
                              "delivery":"snapshot","mode":"verified","skip":5})
            wait_for(lambda:req("/api/state")["phase"]=="waiting")
            # Exactly one image must produce all shapes, even with the video skip setting.
            for index,p in enumerate(packetize(wire_image,10,GRAY8)):
                # A paced board photo can exceed the 600 ms video deadline.
                if index == 1: time.sleep(.75)
                sender.sendto(p,("127.0.0.1",port))
                if index % 16 == 15: time.sleep(.001)
            frame=wait_for(lambda:req("/api/frame"))
            assert sorted(p["class_id"] for p in frame["predictions"])==[0,1,2]
            assert req("/api/state")["phase"]=="snapshot"
            time.sleep(1.2)
            assert req("/api/frame")["source_frame"]==1 and req("/api/state")["phase"]=="snapshot"
            # A second isolated photo replaces the first, without temporal confirmation.
            for index,p in enumerate(packetize(wire_image,11,GRAY8)):
                sender.sendto(p,("127.0.0.1",port))
                if index % 16 == 15: time.sleep(.001)
            wait_for(lambda:req("/api/frame")["source_frame"]==2)
            req("/api/stop",{})
            passed("paced UDP photo exceeds 600ms, bypasses video skipping/temporal delay, persists, next photo replaces it")
            raw=cv2.imencode('.png',shapes)[1].tobytes()
            upload=req("/api/upload?name=shapes.png",raw=raw)
            req("/api/start",{"kind":"upload","upload_id":upload["upload_id"],"mode":"verified"})
            frame=wait_for(lambda:req("/api/frame"))
            assert len(frame["predictions"])==3
            req("/api/stop",{})
            passed("single image bypasses temporal delay and source switch clears UDP")
            # The same HTTP server still rejects a different Origin.
            try:
                urlopen(Request(base+"/api/stop",data=b"{}",headers={"Origin":"https://example.com"}))
            except HTTPError as exc:
                assert exc.code==403
            else:
                raise AssertionError("cross origin accepted")
            passed("existing localhost control restriction preserved")
            sender.close()
        finally:
            application.stop();server.shutdown();server.server_close()
    report={"passed":True,"checks":checks,"count":len(checks),"model_sha256":detector.sha256,
            "scope":"Offline fixtures and real PC loopback UDP. No Ti60 Ethernet or physical camera test.",
            "physical_ethernet_validated":False,"retrained":False}
    (ROOT/'reports/verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')


if __name__=="__main__":
    main()
