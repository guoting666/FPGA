"""Contour proposals + trained 0-9/reject CNN; independent from shape YOLO."""
from pathlib import Path
import hashlib,json,time
import cv2,numpy as np
from digit_common import normalize_digit
from geometry import classify as classify_shape

class DigitDetector:
    def __init__(self,model_dir=None):
        import tensorflow as tf
        folder=Path(model_dir or Path(__file__).parent/'model/digits')
        self.meta=json.loads((folder/'metadata.json').read_text(encoding='utf8'))
        model=folder/'digit_cnn.tflite';self.sha256=hashlib.sha256(model.read_bytes()).hexdigest()
        if self.sha256!=self.meta['sha256']:raise ValueError('数字模型校验失败')
        self.interpreter=tf.lite.Interpreter(model_path=str(model),num_threads=2)
        self.interpreter.allocate_tensors();self.inp=self.interpreter.get_input_details()[0];self.out=self.interpreter.get_output_details()[0]
        if tuple(self.inp['shape'])!=(1,32,32,1) or tuple(self.out['shape'])!=(1,11) or self.inp['dtype']!=np.float32:raise ValueError('数字模型格式不匹配')

    def classify(self,patch):
        self.interpreter.set_tensor(self.inp['index'],normalize_digit(patch)[None,:,:,None].astype(np.float32)/255)
        self.interpreter.invoke();logits=self.interpreter.get_tensor(self.out['index'])[0]
        prob=np.exp(logits-logits.max());return prob/prob.sum()

    def predict(self,bgr,confidence=.93):
        started=time.perf_counter();h,w=bgr.shape[:2];scale=min(1.,960/w,720/h)
        small=cv2.resize(bgr,(round(w*scale),round(h*scale)),interpolation=cv2.INTER_AREA)
        gray=cv2.cvtColor(small,cv2.COLOR_BGR2GRAY);gray=cv2.GaussianBlur(cv2.blur(gray,(2,2)),(3,3),.65)
        _,bright=cv2.threshold(gray,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
        # Dark outlined glyphs can merge into a colored background in Otsu
        # and chroma masks. Reconstruct only closed ink outlines with a bright
        # surrounding halo; preserve nested digit holes (0/6/8/9).
        candidates=_outlined_candidates(small,scale);sh,sw=gray.shape
        hsv=cv2.cvtColor(small,cv2.COLOR_BGR2HSV)
        chroma=cv2.inRange(hsv,(0,70,50),(179,255,255))
        # Use complete connected foregrounds. Local adaptive thresholding can
        # split a textured hand/desk edge into confident digit-1 fragments.
        # Chroma is independent of luminance: yellow/gold lettering can be
        # almost as bright as its checkerboard background. Keep real holes.
        for mask,is_dark in [(chroma,None),(255-bright,True),(bright,False)]:
            closed=cv2.morphologyEx(mask,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
            contours,_=cv2.findContours(closed,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
            for c in sorted(contours,key=cv2.contourArea,reverse=True)[:100]:
                x,y,bw,bh=cv2.boundingRect(c);area=cv2.contourArea(c)
                if bh<14 or bw<3 or bw/bh<.07 or area<12:continue
                oversized=bh>sh*.75 or bw>sw*.45 or bw/bh>1.7
                container=oversized and is_dark is None and bw<sw*.80 and bh<sh*.85 and bw*bh<sw*sh*.70
                if oversized and not container:continue
                border=max(4,round(min(sw,sh)*.02))
                if x<=border or y<=border or x+bw>=sw-border or y+bh>=sh-border:continue
                patch=mask[y:y+bh,x:x+bw]
                if np.count_nonzero(patch)<20:continue
                margin=max(3,round(min(bw,bh)*.20))
                ext=mask[max(0,y-margin):min(sh,y+bh+margin),max(0,x-margin):min(sw,x+bw+margin)]
                ring=np.concatenate([ext[0],ext[-1],ext[:,0],ext[:,-1]])
                # Neighboring complete colored objects need not have an empty
                # rectangular ring (e.g. a 7 beside a 6). They are isolated by
                # their connected component below. Retain the context guard on
                # luminance proposals, where background fragments are common.
                if is_dark is not None and np.count_nonzero(ring)/len(ring)>.30:continue
                if is_dark is None:
                    component=np.zeros((bh,bw),np.uint8)
                    cv2.drawContours(component,[c],-1,255,-1,offset=(-x,-y))
                    # Bounding rectangles may also contain disconnected shadow
                    # specks or another color component. Preserve actual holes,
                    # but never feed unrelated foreground into the digit crop.
                    patch=cv2.bitwise_and(closed[y:y+bh,x:x+bw],component)
                else:
                    crop=gray[y:y+bh,x:x+bw]
                    extended_gray=gray[max(0,y-margin):min(sh,y+bh+margin),max(0,x-margin):min(sw,x+bw+margin)]
                    background=float(np.median(np.concatenate([extended_gray[0],extended_gray[-1],extended_gray[:,0],extended_gray[:,-1]])))
                    foreground=float(np.percentile(crop,15 if is_dark else 85))
                    contrast=(background-foreground) if is_dark else (foreground-background)
                    if contrast<30:continue
                    soft=(background-crop.astype(float)) if is_dark else (crop.astype(float)-background)
                    patch=np.clip(soft*255/max(contrast,1),0,255).astype(np.uint8)
                box=[x/scale,y/scale,(x+bw)/scale,(y+bh)/scale]
                if any(_iou(box,p[0])>.8 for p in candidates):continue
                candidates.append((box,patch.copy(),c,small[y:y+bh,x:x+bw] if is_dark is None else None,container))
        predictions=[]
        for box,patch,contour,color_crop,container in candidates[:48]:
            if container:
                # This box is a cluster, not a valid single-character proposal.
                cls,score,margin=10,1.,1.
            else:
                prob=self.classify(patch);order=np.argsort(prob);cls=int(order[-1]);score=float(prob[cls]);margin=score-float(prob[order[-2]])
            rejected=cls==10 or score<confidence or margin<self.meta.get('minimum_margin',.2)
            if rejected or color_crop is not None:
                # Check mixed-color proposals for a shaded foreground after
                # removing flat captions or a touching overlay. An accepted
                # parent is replaced only by a more confident child; preserve
                # strong intact glyphs and avoid global caption fragments.
                separated=[]
                if color_crop is not None:
                    for child,child_box,child_contour in _split_colors(patch,color_crop):
                        cp=self.classify(child);co=np.argsort(cp);cc=int(co[-1]);cs=float(cp[cc])
                        # Fragments recovered from a touching overlay need
                        # stronger evidence than a complete original proposal.
                        if cc==10 or cs<max(confidence,.98) or cs-float(cp[co[-2]])<self.meta.get('minimum_margin',.2):continue
                        if not rejected and cs<score+.00005:continue
                        if _caption_mixture(child,color_crop[child_box[1]:child_box[3],child_box[0]:child_box[2]]):continue
                        shape=classify_shape(child_contour) if cc==4 else None
                        if shape is not None and shape[0]==0:continue
                        xx,yy,xx2,yy2=child_box;scale_x=(box[2]-box[0])/patch.shape[1];scale_y=(box[3]-box[1])/patch.shape[0]
                        cb=[box[0]+xx*scale_x,box[1]+yy*scale_y,box[0]+xx2*scale_x,box[1]+yy2*scale_y]
                        separated.append(dict(class_id=cc+3,digit=str(cc),name='数字 '+str(cc),confidence=cs,xyxy=cb,source='digit-cnn',group='digit',proposal='separated-touching-colors'))
                if separated:
                    predictions.extend(separated);continue
                if rejected:continue
                # Do not label an inseparable physical-object/caption mixture
                # as one confident character. Occlusion should yield a miss,
                # rather than e.g. a 9 joined to TEN becoming a spurious 3.
                if color_crop is not None and _caption_mixture(patch,color_crop):continue
            # A whole, convex three-sided component is not a glyph 4. This
            # checks the digit's OUTER component; an inner triangle in a real
            # digit 4 remains independently detectable by the shape branch.
            if cls==4:
                shape=classify_shape(contour)
                if shape is not None and shape[0]==0:continue
            predictions.append(dict(class_id=cls+3,digit=str(cls),name='数字 '+str(cls),confidence=score,xyxy=box,source='digit-cnn',group='digit'))
        # Prefer complete glyphs to smaller shading fragments inside them.
        # IoU alone does not remove a narrow highlight mistaken for digit 1.
        predictions.sort(key=lambda p:-(p['xyxy'][2]-p['xyxy'][0])*(p['xyxy'][3]-p['xyxy'][1]));keep=[]
        for p in predictions:
            a=p['xyxy'];area=max((a[2]-a[0])*(a[3]-a[1]),1)
            if not any(_iou(a,old['xyxy'])>.4 or _intersection(a,old['xyxy'])/area>.9 or
                       (area<.15*(old['xyxy'][2]-old['xyxy'][0])*(old['xyxy'][3]-old['xyxy'][1]) and _intersection(a,old['xyxy'])/area>.65) for old in keep):keep.append(p)
        keep.sort(key=lambda p:-p['confidence'])
        return keep[:24],dict(digit_total_ms=(time.perf_counter()-started)*1000,digit_proposals=min(len(candidates),48),digit_model_sha256=self.sha256,digit_localization_revision='outlined-halo-r1')

def _outlined_candidates(bgr,scale):
    gray=cv2.GaussianBlur(cv2.cvtColor(bgr,cv2.COLOR_BGR2GRAY),(3,3),.65)
    ink=np.uint8(gray<64)*255
    contours,hierarchy=cv2.findContours(ink,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    if hierarchy is None:return []
    hierarchy=hierarchy[0];h,w=gray.shape;found=[]
    for i in sorted(range(len(contours)),key=lambda j:cv2.contourArea(contours[j]),reverse=True):
        c=contours[i];x,y,bw,bh=cv2.boundingRect(c);area=cv2.contourArea(c)
        child=hierarchy[i][2]
        if hierarchy[i][3]!=-1 or child<0 or bh<22 or bw<5 or not .07<bw/bh<1.7:continue
        if bh>h*.75 or bw>w*.45 or area<60 or x<4 or y<4 or x+bw>w-4 or y+bh>h-4:continue
        children=[]
        while child>=0:
            children.append(child);child=hierarchy[child][0]
        if max(cv2.contourArea(contours[j]) for j in children)<area*.12:continue
        # Requiring a bright halo and a substantial enclosed fill prevents
        # this extra proposal path from treating arbitrary texture as text.
        outer=np.zeros((bh+8,bw+8),np.uint8)
        cv2.drawContours(outer,[c],-1,255,-1,offset=(4-x,4-y))
        surround=(cv2.dilate(outer,np.ones((9,9),np.uint8))>0)&(cv2.dilate(outer,np.ones((5,5),np.uint8))==0)
        local=gray[y-4:y+bh+4,x-4:x+bw+4]
        if np.count_nonzero(surround)<20 or np.mean(local[surround]>=170)<.65:continue
        patch=outer[4:4+bh,4:4+bw].copy()
        # Depth 1 is the colored stroke enclosed by the dark outline; depth 2
        # contains semantic holes, unlike filling every contour as a solid blob.
        for j in children:
            hole=hierarchy[j][2]
            while hole>=0:
                cv2.drawContours(patch,[contours[hole]],-1,0,-1,offset=(-x,-y))
                hole=hierarchy[hole][0]
        box=[x/scale,y/scale,(x+bw)/scale,(y+bh)/scale]
        found.append((box,patch,c,None,False))
        if len(found)>=24:break
    return found


def _iou(a,b):
    inter=_intersection(a,b)
    return inter/max((a[2]-a[0])*(a[3]-a[1])+(b[2]-b[0])*(b[3]-b[1])-inter,1)

def _intersection(a,b):
    return max(0,min(a[2],b[2])-max(a[0],b[0]))*max(0,min(a[3],b[3])-max(a[1],b[1]))

def _split_colors(mask,bgr):
    total=np.count_nonzero(mask)
    # A flat video caption can touch a shaded object even when their hues are
    # similar (red TWO against a red 2, brown TEN against an orange 9).
    # Remove a genuinely repeated RGB fill only within a rejected/uncertain
    # component, and retain only sufficiently large, shaded residuals.
    core=cv2.erode(mask,np.ones((5,5),np.uint8))>0
    colors=bgr[core]
    if len(colors)>=80:
        quant=colors.astype(np.int32)//4;keys=quant[:,0]*4096+quant[:,1]*64+quant[:,2];values,counts=np.unique(keys,return_counts=True);chosen=values[counts.argmax()]
        if counts.max()/len(colors)>=.15:
            fill=np.median(colors[keys==chosen],axis=0);flat=np.max(np.abs(bgr.astype(float)-fill),axis=2)<=8
            flat=cv2.dilate(flat.astype(np.uint8),np.ones((3,3),np.uint8))>0
            residual=np.uint8((mask>0)&~flat)*255
            for component,box,c in _shaded_parts(residual,bgr,total):yield component,box,c
    hsv=cv2.cvtColor(bgr,cv2.COLOR_BGR2HSV);hue=hsv[:,:,0].astype(np.int16)
    valid=(mask>0)&(hsv[:,:,1]>=100)&(hsv[:,:,2]>=45)
    if np.count_nonzero(valid)<80:return
    hist=np.bincount(hue[valid],minlength=180).astype(float);mass=sum(np.roll(hist,i) for i in range(-2,3))
    peaks=[]
    for peak in np.argsort(mass)[::-1]:
        if mass[peak]<mass.max()*.12:break
        if any(min(abs(int(peak)-p),180-abs(int(peak)-p))<8 for p in peaks):continue
        peaks.append(int(peak))
        if len(peaks)==5:break
    if len(peaks)<2:return
    distances=np.stack([np.minimum(np.abs(hue-p),180-np.abs(hue-p)) for p in peaks]);labels=distances.argmin(0)
    foreground=mask>0;total=np.count_nonzero(foreground)
    fractions=[np.count_nonzero(foreground&(labels==i))/max(total,1) for i in range(len(peaks))]
    if sum(f>.12 for f in fractions)<2:return
    for i in range(len(peaks)):
        if fractions[i]<.08:continue
        selection=labels==i
        child=np.uint8(foreground&selection)*255;child=cv2.morphologyEx(child,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
        yield from _shaded_parts(child,bgr,total)

def _shaded_parts(child,bgr,total):
    contours,_=cv2.findContours(child,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    for c in contours:
        x,y,w,h=cv2.boundingRect(c)
        if h<14 or w<3 or w/h>1.35 or cv2.contourArea(c)<12:continue
        component=np.zeros_like(child);cv2.drawContours(component,[c],-1,255,-1);component=cv2.bitwise_and(component,child)
        if np.count_nonzero(component)<total*.08:continue
        core=cv2.erode(component,np.ones((5,5),np.uint8))>0;colors=bgr[core]
        if len(colors)<20 or float(np.max(np.percentile(colors,75,axis=0)-np.percentile(colors,25,axis=0)))<12:continue
        yield component[y:y+h,x:x+w],[x,y,x+w,y+h],c

def _caption_mixture(mask,bgr):
    colors=bgr[cv2.erode(mask,np.ones((5,5),np.uint8))>0]
    if len(colors)<80 or np.max(np.percentile(colors,75,axis=0)-np.percentile(colors,25,axis=0))<35:return False
    q=colors.astype(np.int32)//4;keys=q[:,0]*4096+q[:,1]*64+q[:,2];values,counts=np.unique(keys,return_counts=True)
    if counts.max()/len(colors)<.15:return False
    fill=np.median(colors[keys==values[counts.argmax()]],axis=0);fraction=np.mean(np.max(np.abs(colors.astype(float)-fill),axis=1)<=8)
    return .15<=fraction<=.85
