@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0pc_app\launch.ps1" -Check
if errorlevel 1 pause
