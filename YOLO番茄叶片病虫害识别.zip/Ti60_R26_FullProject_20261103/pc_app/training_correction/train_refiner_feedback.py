from pathlib import Path
import json,time,hashlib,math,copy
import cv2,numpy as np,torch
from torch import nn
from torch.utils.data import DataLoader,ConcatDataset,WeightedRandomSampler
from torchvision.models import mobilenet_v3_large
from train_leaf_refiner import crop_input,Crops,Cached,metrics
R=Path(__file__).resolve().parent;B=R.parent/'tomato_feature';torch.set_num_threads(3);torch.manual_seed(20261026);started=time.time()
def publish(**x):
 x['elapsed_seconds']=round(time.time()-started,1);p=R/'correction_refiner_progress.json';t=p.with_suffix('.json.tmp');t.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf8');t.replace(p)
def main():
 groups=json.loads((B/'data/image_groups.json').read_text(encoding='utf8'));demo=json.loads((B/'app/samples/TOMATO_DEMO_ATTRIBUTION.json').read_text(encoding='utf8'));known=[x for x in demo['examples'] if x['selected_for_class'] in [0,1,3,5]]
 net=mobilenet_v3_large(weights=None);net.classifier[-1]=nn.Linear(1280,9);net.load_state_dict(torch.load(R/'leaf_refiner_best.pt',map_location='cpu',weights_only=False)['state_dict']);prefix=net.features[:13].eval();tail=nn.Sequential(net.features[13:],net.avgpool,nn.Flatten(),net.classifier)
 for p in prefix.parameters():p.requires_grad=False
 rows=[];exact=[]
 for entry in known:
  paths=[B/'app/samples'/entry['file']]+[B/'data/raw_short'/x['short'] for x in groups[entry['source_group']][:6]]
  seen=set()
  for path in paths:
   digest=hashlib.sha256(path.read_bytes()).hexdigest()
   if digest in seen:continue
   seen.add(digest);image=cv2.imread(str(path));h,w=image.shape[:2];label=path.with_suffix('.txt') if path.parent.name=='samples' else path.parent.parent/'labels'/(path.stem+'.txt')
   for line in label.read_text().splitlines():
    c,x,y,bw,bh=map(float,line.split());box=(np.array([x-bw/2,y-bh/2,x+bw/2,y+bh/2])*[w,h,w,h]).tolist()
    if min(box[2]-box[0],box[3]-box[1])<12:continue
    for margin in [0.,.08,.16]:rows.append(dict(path=str(path),box=box,label=int(c),split='feedback_train',group=entry['source_group'],margin=margin))
    if path.parent.name=='samples':exact.append(dict(path=str(path),box=box,label=int(c),group=entry['source_group'],margin=.08))
 def extract(items):
  result=[]
  with torch.inference_mode():
   for at in range(0,len(items),32):
    batch=items[at:at+32];x=np.stack([crop_input(cv2.imread(r['path']),r['box'],r['margin']) for r in batch]);result.append(prefix(torch.from_numpy(x)).numpy().astype(np.float16))
  return np.concatenate(result)
 np.save(R/'feedback_prefix.npy',extract(rows));np.save(R/'feedback_check_prefix.npy',extract(exact))
 original=json.loads((R/'crop_records.json').read_text(encoding='utf8'));oldtrain=[x for x in original if x['split']=='train'];oldval=[x for x in original if x['split']=='val']
 feedback_groups={x['group'] for x in rows};assert not feedback_groups&{x['group'] for x in oldtrain+oldval}
 train=Cached(R/'train_prefix.npy',oldtrain,True);feedback=Cached(R/'feedback_prefix.npy',rows,True);val=Cached(R/'val_prefix.npy',oldval,False);check=Cached(R/'feedback_check_prefix.npy',exact,False)
 joined=ConcatDataset([train,feedback]);count=np.bincount(train.y,minlength=9);a=(1/np.sqrt(count))[train.y];a=a/a.sum()*.75;b=np.array([1/max(1,sum(y['label']==r['label'] for y in rows)) for r in rows]);b=b/b.sum()*.25
 sampler=WeightedRandomSampler(torch.from_numpy(np.r_[a,b]),len(train),replacement=True);loader=DataLoader(joined,batch_size=64,sampler=sampler,num_workers=0);valloader=DataLoader(val,batch_size=64);checkloader=DataLoader(check,batch_size=64)
 optimizer=torch.optim.AdamW([dict(params=tail[0].parameters(),lr=.000035),dict(params=tail[3].parameters(),lr=.00035)],weight_decay=.01);loss_fn=nn.CrossEntropyLoss(label_smoothing=.03)
 def evaluate(loader):
  cm=np.zeros((9,9),np.int64);tail.eval()
  with torch.inference_mode():
   for x,y in loader:np.add.at(cm,(y.numpy(),tail(x).argmax(1).numpy()),1)
  return metrics(cm)
 best=-1.;history=[]
 floor=json.loads((R/'refiner_training_result.json').read_text())['validation']['macro_f1']-.025
 for epoch in range(10):
  tail.train();loss_total=0.;seen=0;factor=.2+.8*(1+math.cos(math.pi*epoch/10))/2
  for group,base in zip(optimizer.param_groups,[.000035,.00035]):group['lr']=base*factor
  for x,y in loader:
   optimizer.zero_grad(set_to_none=True);loss=loss_fn(tail(x),y);loss.backward();optimizer.step();loss_total+=loss.item()*len(y);seen+=len(y)
  vm=evaluate(valloader);fm=evaluate(checkloader);score=vm['macro_f1']+.15*min(.95,fm['accuracy']) if vm['macro_f1']>=floor else -1
  row=dict(epoch=epoch+1,loss=loss_total/seen,validation=vm,training_feedback=fm,selection_score=score);history.append(row)
  if score>best:
   best=score;torch.save(dict(state_dict=net.state_dict(),epoch=epoch+1,validation=vm,training_feedback=fm),R/'leaf_refiner_feedback_best.pt')
  publish(phase='training',epoch=epoch+1,epochs=10,validation_macro_f1=vm['macro_f1'],training_feedback_accuracy=fm['accuracy']);print(json.dumps(row),flush=True);(R/'refiner_feedback_history.json').write_text(json.dumps(history,indent=2),encoding='utf8')
 checkpoint=torch.load(R/'leaf_refiner_feedback_best.pt',map_location='cpu',weights_only=False);net.load_state_dict(checkpoint['state_dict']);net.eval();onnx=R/'leaf_refiner_feedback.onnx';torch.onnx.export(net,torch.zeros(1,3,224,224),onnx,input_names=['images'],output_names=['logits'],dynamic_axes={'images':{0:'batch'},'logits':{0:'batch'}},opset_version=12)
 report=dict(complete=True,selected_epoch=checkpoint['epoch'],validation=checkpoint['validation'],training_feedback=checkpoint['training_feedback'],feedback_sources=sorted(feedback_groups),feedback_crops=len(rows),feedback_sample_probability=.25,replay_sample_probability=.75,selection='Validation macro F1 + 0.15*min(0.95,training feedback accuracy), validation macro F1 cannot fall more than 0.025 from initial refiner',onnx_sha256=hashlib.sha256(onnx.read_bytes()).hexdigest(),elapsed_seconds=time.time()-started)
 (R/'refiner_feedback_result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');(R/'refiner_feedback_records.json').write_text(json.dumps(rows,ensure_ascii=False),encoding='utf8');publish(phase='complete',**report);print('REFINER_FEEDBACK_COMPLETE',flush=True)
if __name__=='__main__':
 try:main()
 except Exception as e:publish(phase='error',error=repr(e));raise
