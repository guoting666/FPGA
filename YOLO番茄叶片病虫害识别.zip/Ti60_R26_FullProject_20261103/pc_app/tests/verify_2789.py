"""Regression of 2/8 confusion and 7/9 proposals; video is training-related."""
from pathlib import Path
import sys,json
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from detector import Detector
from geometry import ShapePipeline,iou

def main():
 cv2.setNumThreads(1);d=Detector();f=ROOT/'tests/fixtures/clay_all';checks=[]
 def passed(name):checks.append(name);print('PASS',name,flush=True)
 for label in [2,7,8,9]:
  p=d.digits.classify(cv2.imread(str(f/f'foreground_{label}.png'),0));assert p.argmax()==label and p[label]>=.93,(label,p.tolist())
 passed('labelled clay 2,7,8,9 crops remain distinct at the default threshold; training fit only')
 for k in range(4):
  p=d.digits.classify(cv2.imread(str(f/f'car_{k}.png'),0));assert p.argmax()==10 and p[10]>=.93,(k,p.tolist())
 passed('four labelled toy-car foregrounds are rejected; training fit only')
 im=cv2.imread(str(f/'frame_0.png'));p,t=ShapePipeline(d).predict(im,.96,targets='both')
 truth={2:[197,77,335,250],7:[169,293,301,489],8:[294,279,430,498],9:[431,272,553,492]}
 for cls,box in truth.items():
  matches=[x for x in p if x.get('digit')==str(cls) and iou(x['xyxy'],box)>.5];assert matches,(cls,p)
 assert not any(x.get('digit')=='8' and iou(x['xyxy'],truth[2])>.5 for x in p)
 assert len([x for x in p if x.get('digit')=='6'])==1,p
 passed('complete scene simultaneously finds 2,7,8,9; actual 8 stays 8; detached 9-tail fragment does not become an extra 6')
 cv2.imwrite(str(ROOT/'reports/clay_2789_fixed.jpg'),d.annotate(im,p))
 later=cv2.imread(str(f/'frame_440.png'));later_p,_=ShapePipeline(d).predict(later,.96,targets='both')
 assert any(x.get('digit')=='9' and iou(x['xyxy'],[535,274,665,479])>.5 for x in later_p),later_p
 passed('orange 9 is also recovered from the later original video scene')
 for fid,cls,box in [(132,2,[290,100,405,247]),(264,2,[270,105,395,253]),(460,9,[535,274,665,479]),(485,9,[535,274,665,479])]:
  frame=cv2.imread(str(f/f'frame_{fid}.png'));fp,_=d.digits.predict(frame,.93)
  assert any(x.get('digit')==str(cls) and iou(x['xyxy'],box)>.5 for x in fp),(fid,fp)
  assert not any(x.get('digit')==('8' if cls==2 else '3') and iou(x['xyxy'],box)>.5 for x in fp),(fid,fp)
 passed('caption-truncated 2 and UI-overlapped 9 remain the correct digit in four labelled scenes; same-video repair regression')
 pipe=ShapePipeline(d);assert not pipe.predict(im,.96,targets='both',stable=True)[0]
 confirmed,_=pipe.predict(im,.96,targets='both',stable=True)
 assert all(any(x.get('digit')==str(k) and iou(x['xyxy'],truth[k])>.5 for x in confirmed) for k in [2,7,9])
 assert not pipe.predict(np.full_like(im,235),.96,targets='both',stable=True)[0]
 passed('2,7,9 retain two-frame confirmation and clear immediately when removed')
 report=dict(passed=True,count=len(checks),checks=checks,digit_model_sha256=d.digits.sha256,scope='User-video repair regression; labelled foreground crops from this video were used for fitting. Not independent camera accuracy.',predictions=p,timing=t)
 (ROOT/'reports/regression_2789.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
if __name__=='__main__':main()
