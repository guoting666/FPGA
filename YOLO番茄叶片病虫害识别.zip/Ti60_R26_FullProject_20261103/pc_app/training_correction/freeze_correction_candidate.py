from pathlib import Path
import sys,json,hashlib,shutil
import torch
from torch import nn
from torchvision.models import mobilenet_v3_large
R=Path(__file__).resolve().parent;A=R/'app';sys.path.insert(0,str(A))
from tomato import pipeline_identity
torch.set_num_threads(1);checkpoint=torch.load(R/'leaf_refiner_feedback_best.pt',map_location='cpu',weights_only=False)
net=mobilenet_v3_large(weights=None);net.classifier[-1]=nn.Linear(1280,9);net.load_state_dict(checkpoint['state_dict']);net.eval()
path=R/'leaf_refiner_selected.onnx';torch.onnx.export(net,torch.zeros(1,3,224,224),path,input_names=['images'],output_names=['logits'],dynamic_axes={'images':{0:'batch'},'logits':{0:'batch'}},opset_version=12)
torch.save(checkpoint,R/'leaf_refiner_selected.pt');folder=A/'model/tomato';shutil.copy2(path,folder/'leaf_refiner.onnx')
m=json.loads((folder/'metadata.json').read_text(encoding='utf8'));m.update(refiner_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),proposal_confidence=.03,classification_margin=0.,fusion_alpha=.5,default_confidence=.25,test_metrics=None,user_feedback_used_for_training=True,feedback_classes=[0,1,3,5]);m['pipeline_sha256']=pipeline_identity(m);(folder/'metadata.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf8')
report=dict(selected_correction_epoch=checkpoint['epoch'],validation=checkpoint['validation'],training_feedback=checkpoint['training_feedback'],refiner_sha256=m['refiner_sha256'],pipeline_sha256=m['pipeline_sha256'],selection='Best saved correction checkpoint observed so far; regression and full validation still required',training_examples_are_not_independent_tests=True)
(R/'selected_correction.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print('CORRECTION_CANDIDATE_FROZEN',checkpoint['epoch'],checkpoint['validation']['macro_f1'],flush=True)
